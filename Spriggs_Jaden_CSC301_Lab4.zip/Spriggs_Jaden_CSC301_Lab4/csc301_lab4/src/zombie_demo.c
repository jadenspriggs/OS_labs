#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return EXIT_FAILURE;
    }

    if (pid == 0) {
        printf("Child: PID=%ld PPID=%ld\n",
               (long)getpid(), (long)getppid());
        fflush(stdout);

        exit(EXIT_SUCCESS);
    }

    printf("Parent: PID=%ld Child PID=%ld\n",
           (long)getpid(), (long)pid);
    fflush(stdout);

    printf("Parent: waiting 5 seconds before waitpid()...\n");
    fflush(stdout);

    sleep(30);

    int status;
    pid_t result = waitpid(pid, &status, 0);

    if (result == -1) {
        perror("waitpid");
        return EXIT_FAILURE;
    }

    printf("Parent: reaped child PID=%ld\n", (long)result);

    if (WIFEXITED(status)) {
        printf("Parent: child exited normally with status %d\n",
               WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("Parent: child terminated by signal %d\n",
               WTERMSIG(status));
    }

    return EXIT_SUCCESS;
}
