#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t status_requested = 0;
static volatile sig_atomic_t terminate_requested = 0;

static void handle_signal(int signo)
{
    if (signo == SIGUSR1) {
        status_requested = 1;
    } else if (signo == SIGTERM) {
        terminate_requested = 1;
    }
}

int main(void)
{
    struct sigaction sa;

    sa.sa_handler = handle_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("sigaction SIGUSR1");
        return EXIT_FAILURE;
    }

    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("sigaction SIGTERM");
        return EXIT_FAILURE;
    }

    printf("Worker PID=%ld\n", (long)getpid());
    fflush(stdout);

    time_t start = time(NULL);

    if (start == (time_t)-1) {
        perror("time");
        return EXIT_FAILURE;
    }

    unsigned long counter = 0;

    while (!terminate_requested) {
        if (status_requested) {
            printf("Worker PID=%ld status: counter=%lu\n",
                   (long)getpid(), counter);
            fflush(stdout);

            status_requested = 0;
        }

        counter++;

        time_t now = time(NULL);

        if (now == (time_t)-1) {
            perror("time");
            return EXIT_FAILURE;
        }

        if (now - start >= 30) {
            printf("Worker PID=%ld: 30-second limit reached\n",
                   (long)getpid());
            fflush(stdout);
            break;
        }

        sleep(1);
    }

    if (terminate_requested) {
        printf("Worker PID=%ld: orderly shutdown requested\n",
               (long)getpid());
        fflush(stdout);
    }

    printf("Worker PID=%ld exiting\n", (long)getpid());
    fflush(stdout);

    return EXIT_SUCCESS;
}
