#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <1-4>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *endptr;
    errno = 0;
    long count = strtol(argv[1], &endptr, 10);

    if (errno != 0 || *endptr != '\0' || count < 1 || count > 4) {
        fprintf(stderr, "Error: argument must be an integer from 1 through 4\n");
        return EXIT_FAILURE;
    }

    pid_t children[4];

    for (int i = 0; i < count; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            return EXIT_FAILURE;
        }

        if (pid == 0) {
            int exit_code = 10 + i;

            printf("Child %d: PID=%ld PPID=%ld planned_exit=%d\n",
                   i + 1, (long)getpid(), (long)getppid(), exit_code);
            fflush(stdout);

            sleep(3);
            exit(exit_code);
        }

        children[i] = pid;
    }

    printf("Parent PID=%ld created children:", (long)getpid());

    for (int i = 0; i < count; i++) {
        printf(" %ld", (long)children[i]);
    }

    printf("\n");
    fflush(stdout);

    for (int i = 0; i < count; i++) {
        int status;
        pid_t result = waitpid(children[i], &status, 0);

        if (result == -1) {
            perror("waitpid");
            return EXIT_FAILURE;
        }

        if (WIFEXITED(status)) {
            printf("Reaped child PID=%ld with exit code %d\n",
                   (long)result, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Reaped child PID=%ld terminated by signal %d\n",
                   (long)result, WTERMSIG(status));
        }
    }

    return EXIT_SUCCESS;
}
