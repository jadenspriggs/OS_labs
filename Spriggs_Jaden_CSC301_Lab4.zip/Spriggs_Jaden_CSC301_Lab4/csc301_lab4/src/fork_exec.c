#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <command> [args...]\n", argv[0]);
        return EXIT_FAILURE;
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return EXIT_FAILURE;
    }

    if (pid == 0) {
        printf("Child PID=%ld executing:", (long)getpid());

        for (int i = 1; i < argc; i++) {
            printf(" %s", argv[i]);
        }

        printf("\n");
        fflush(stdout);

        execvp(argv[1], &argv[1]);

        perror("execvp");
        exit(127);
    }

    int status;
    pid_t result = waitpid(pid, &status, 0);

    if (result == -1) {
        perror("waitpid");
        return EXIT_FAILURE;
    }

    if (WIFEXITED(status)) {
        printf("Parent: child PID=%ld exited with status %d\n",
               (long)pid, WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("Parent: child PID=%ld terminated by signal %d\n",
               (long)pid, WTERMSIG(status));
    }

    return EXIT_SUCCESS;
}
