#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
    const int durations[3] = {2, 4, 6};
    const int exit_codes[3] = {21, 22, 23};

    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            return EXIT_FAILURE;
        }

        if (pid == 0) {
            printf("Child %d: PID=%ld sleeping %d seconds, exit=%d\n",
                   i + 1, (long)getpid(), durations[i], exit_codes[i]);
            fflush(stdout);

            sleep((unsigned int)durations[i]);
            exit(exit_codes[i]);
        }
    }

    int reaped = 0;

    while (reaped < 3) {
        int status;
        pid_t result = waitpid(-1, &status, WNOHANG);

        if (result == -1) {
            perror("waitpid");
            return EXIT_FAILURE;
        }

        if (result == 0) {
            printf("Progress: no child has changed state; waiting before next poll.\n");
            fflush(stdout);
            sleep(1);
            continue;
        }

        if (WIFEXITED(status)) {
            printf("Parent: reaped PID=%ld with exit code %d\n",
                   (long)result, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Parent: reaped PID=%ld terminated by signal %d\n",
                   (long)result, WTERMSIG(status));
        }

        reaped++;
    }

    printf("Parent: all three children have been reaped.\n");

    return EXIT_SUCCESS;
}
