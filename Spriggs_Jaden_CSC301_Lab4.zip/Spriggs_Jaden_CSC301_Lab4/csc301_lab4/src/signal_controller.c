#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

static int parse_pid(const char *text, pid_t *pid_out)
{
    char *endptr;
    errno = 0;

    long value = strtol(text, &endptr, 10);

    if (errno != 0 || *text == '\0' || *endptr != '\0') {
        return -1;
    }

    if (value <= 1) {
        return -1;
    }

    *pid_out = (pid_t)value;
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <PID>\n", argv[0]);
        return EXIT_FAILURE;
    }

    pid_t pid;

    if (parse_pid(argv[1], &pid) == -1) {
        fprintf(stderr, "Error: PID must be an integer greater than 1\n");
        return EXIT_FAILURE;
    }

    /*
     * kill(pid, 0) performs permission/existence checking
     * without sending an actual signal.
     */
    if (kill(pid, 0) == -1) {
        perror("kill PID check");
        return EXIT_FAILURE;
    }

    /*
     * A successful kill(pid, 0) confirms that the current
     * process has permission to signal the target. For this
     * lab, require the target to be owned by the current user.
     */
    char proc_path[64];
    snprintf(proc_path, sizeof(proc_path), "/proc/%ld/status", (long)pid);

    FILE *file = fopen(proc_path, "r");

    if (file == NULL) {
        perror("fopen /proc/<pid>/status");
        return EXIT_FAILURE;
    }

    uid_t target_uid = (uid_t)-1;
    char line[256];

    while (fgets(line, sizeof(line), file) != NULL) {
        unsigned int uid_value;

        if (sscanf(line, "Uid:\t%u", &uid_value) == 1) {
            target_uid = (uid_t)uid_value;
            break;
        }
    }

    fclose(file);

    if (target_uid == (uid_t)-1) {
        fprintf(stderr, "Error: could not determine target process owner\n");
        return EXIT_FAILURE;
    }

    if (target_uid != geteuid()) {
        fprintf(stderr, "Error: target PID does not belong to the current user\n");
        return EXIT_FAILURE;
    }

    printf("Controller: sending SIGUSR1 to PID=%ld\n", (long)pid);
    fflush(stdout);

    if (kill(pid, SIGUSR1) == -1) {
        perror("kill SIGUSR1");
        return EXIT_FAILURE;
    }

    sleep(2);

    printf("Controller: sending SIGTERM to PID=%ld\n", (long)pid);
    fflush(stdout);

    if (kill(pid, SIGTERM) == -1) {
        perror("kill SIGTERM");
        return EXIT_FAILURE;
    }

    printf("Controller: signals sent successfully\n");

    return EXIT_SUCCESS;
}
