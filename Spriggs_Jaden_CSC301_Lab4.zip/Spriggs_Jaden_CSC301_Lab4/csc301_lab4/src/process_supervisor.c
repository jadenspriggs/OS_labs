#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define SUPERVISOR_OK 0
#define SUPERVISOR_USAGE 64
#define SUPERVISOR_ERROR 70
#define SUPERVISOR_EXEC_FAILURE 71
#define SUPERVISOR_TIMEOUT 72
#define SUPERVISOR_SIGNALED 73

static volatile sig_atomic_t interrupt_requested = 0;

static void handle_sigint(int signo)
{
    (void)signo;
    interrupt_requested = 1;
}

static long long monotonic_seconds(void)
{
    struct timespec ts;

    if (clock_gettime(CLOCK_MONOTONIC, &ts) == -1) {
        return -1;
    }

    return (long long)ts.tv_sec;
}

static void log_message(const char *message)
{
    FILE *log = fopen("output/supervisor.log", "a");

    if (log == NULL) {
        perror("fopen supervisor.log");
        return;
    }

    fprintf(log, "%s\n", message);
    fclose(log);
}

static void log_start(pid_t pid, int limit, int argc, char *argv[])
{
    FILE *log = fopen("output/supervisor.log", "a");

    if (log == NULL) {
        perror("fopen supervisor.log");
        return;
    }

    time_t now = time(NULL);
    char *time_string = ctime(&now);

    if (time_string != NULL) {
        time_string[strcspn(time_string, "\n")] = '\0';
    }

    fprintf(log, "START time=%s pid=%ld limit=%d command=",
            time_string != NULL ? time_string : "unknown",
            (long)pid,
            limit);

    for (int i = 0; i < argc; i++) {
        fprintf(log, "%s%s", i == 0 ? "" : " ", argv[i]);
    }

    fprintf(log, "\n");
    fclose(log);
}

static void log_result(pid_t pid, const char *outcome, int value)
{
    FILE *log = fopen("output/supervisor.log", "a");

    if (log == NULL) {
        perror("fopen supervisor.log");
        return;
    }

    fprintf(log, "RESULT pid=%ld outcome=%s value=%d\n",
            (long)pid, outcome, value);

    fclose(log);
}

static int send_term(pid_t pid)
{
    if (kill(pid, SIGTERM) == -1) {
        if (errno == ESRCH) {
            return 0;
        }

        perror("kill(SIGTERM)");
        return -1;
    }

    return 0;
}

static int send_kill(pid_t pid)
{
    if (kill(pid, SIGKILL) == -1) {
        if (errno == ESRCH) {
            return 0;
        }

        perror("kill(SIGKILL)");
        return -1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 3) {
        fprintf(stderr,
                "Usage: %s <limit_seconds 2-30> <executable> [args...]\n",
                argv[0]);
        return SUPERVISOR_USAGE;
    }

    char *end = NULL;
    errno = 0;

    long limit = strtol(argv[1], &end, 10);

    if (errno != 0 || end == argv[1] || *end != '\0' ||
        limit < 2 || limit > 30) {
        fprintf(stderr, "Error: limit must be an integer from 2 through 30.\n");
        return SUPERVISOR_USAGE;
    }

    if (argv[2][0] == '\0') {
        fprintf(stderr, "Error: executable path cannot be empty.\n");
        return SUPERVISOR_USAGE;
    }

    /*
     * Install SIGINT handler so Ctrl+C causes the supervisor
     * to terminate the managed child rather than leaving it behind.
     */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_sigint;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("sigaction");
        return SUPERVISOR_ERROR;
    }

    /*
     * Pipe used to distinguish an exec() failure from successful exec().
     * The write end is close-on-exec. If exec succeeds, it disappears.
     * If exec fails, the child writes errno to the pipe.
     */
    int exec_pipe[2];

    if (pipe(exec_pipe) == -1) {
        perror("pipe");
        return SUPERVISOR_ERROR;
    }

    if (fcntl(exec_pipe[1], F_SETFD, FD_CLOEXEC) == -1) {
        perror("fcntl");
        close(exec_pipe[0]);
        close(exec_pipe[1]);
        return SUPERVISOR_ERROR;
    }

    pid_t child_pid = fork();

    if (child_pid == -1) {
        perror("fork");
        close(exec_pipe[0]);
        close(exec_pipe[1]);
        return SUPERVISOR_ERROR;
    }

    if (child_pid == 0) {
        close(exec_pipe[0]);

        execvp(argv[2], &argv[2]);

        int exec_errno = errno;

        ssize_t ignored = write(exec_pipe[1],
                                &exec_errno,
                                sizeof(exec_errno));
        (void)ignored;

        _exit(127);
    }

    close(exec_pipe[1]);

    log_start(child_pid, (int)limit, argc - 2, &argv[2]);

    /*
     * Make the pipe nonblocking so the supervisor can continue
     * monitoring the child.
     */
    int flags = fcntl(exec_pipe[0], F_GETFL);

    if (flags == -1 ||
        fcntl(exec_pipe[0], F_SETFL, flags | O_NONBLOCK) == -1) {
        perror("fcntl");
        close(exec_pipe[0]);

        /*
         * Cleanup is still mandatory.
         */
        (void)send_term(child_pid);
        (void)waitpid(child_pid, NULL, 0);

        return SUPERVISOR_ERROR;
    }

    int status = 0;
    int wait_result;
    int exec_failed = 0;
    int exec_errno = 0;

    long long start = monotonic_seconds();

    if (start == -1) {
        perror("clock_gettime");
        close(exec_pipe[0]);
        (void)send_term(child_pid);
        (void)waitpid(child_pid, NULL, 0);
        return SUPERVISOR_ERROR;
    }

    int timeout_triggered = 0;
    int interrupt_triggered = 0;
    int term_sent = 0;

    while (1) {
        ssize_t bytes = read(exec_pipe[0],
                             &exec_errno,
                             sizeof(exec_errno));

        if (bytes == (ssize_t)sizeof(exec_errno)) {
            exec_failed = 1;
            break;
        }

        if (bytes == 0) {
            /*
             * EOF means the child successfully executed the new image
             * and the close-on-exec descriptor disappeared.
             */
        } else if (bytes == -1 && errno != EAGAIN && errno != EWOULDBLOCK) {
            perror("read");
            close(exec_pipe[0]);
            (void)send_term(child_pid);
            (void)waitpid(child_pid, NULL, 0);
            return SUPERVISOR_ERROR;
        }

        wait_result = waitpid(child_pid, &status, WNOHANG);

        if (wait_result == child_pid) {
            break;
        }

        if (wait_result == -1) {
            if (errno == EINTR) {
                continue;
            }

            perror("waitpid");
            close(exec_pipe[0]);
            return SUPERVISOR_ERROR;
        }

        if (interrupt_requested && !term_sent) {
            fprintf(stderr, "Ctrl+C: forwarding SIGTERM to child %ld\n",
                    (long)child_pid);

            if (send_term(child_pid) == -1) {
                close(exec_pipe[0]);
                (void)waitpid(child_pid, &status, 0);
                return SUPERVISOR_ERROR;
            }

            term_sent = 1;
            interrupt_triggered = 1;
        }

        long long now = monotonic_seconds();

        if (now == -1) {
            perror("clock_gettime");
            close(exec_pipe[0]);
            (void)send_term(child_pid);
            (void)waitpid(child_pid, &status, 0);
            return SUPERVISOR_ERROR;
        }

        if (!term_sent && now - start >= limit) {
            timeout_triggered = 1;

            fprintf(stderr,
                    "Timeout: child %ld exceeded %ld seconds; sending SIGTERM.\n",
                    (long)child_pid, limit);

            if (send_term(child_pid) == -1) {
                close(exec_pipe[0]);
                (void)waitpid(child_pid, &status, 0);
                return SUPERVISOR_ERROR;
            }

            term_sent = 1;

            /*
             * Give the child a two-second grace period.
             */
            long long grace_start = monotonic_seconds();

            if (grace_start == -1) {
                perror("clock_gettime");
                close(exec_pipe[0]);
                (void)waitpid(child_pid, &status, 0);
                return SUPERVISOR_ERROR;
            }

            while (1) {
                wait_result = waitpid(child_pid, &status, WNOHANG);

                if (wait_result == child_pid) {
                    break;
                }

                if (wait_result == -1) {
                    if (errno == EINTR) {
                        continue;
                    }

                    perror("waitpid");
                    close(exec_pipe[0]);
                    return SUPERVISOR_ERROR;
                }

                long long grace_now = monotonic_seconds();

                if (grace_now == -1) {
                    perror("clock_gettime");
                    close(exec_pipe[0]);
                    (void)waitpid(child_pid, &status, 0);
                    return SUPERVISOR_ERROR;
                }

                if (grace_now - grace_start >= 2) {
                    fprintf(stderr,
                            "Grace period expired; sending SIGKILL to child %ld.\n",
                            (long)child_pid);

                    if (send_kill(child_pid) == -1) {
                        close(exec_pipe[0]);
                        (void)waitpid(child_pid, &status, 0);
                        return SUPERVISOR_ERROR;
                    }

                    /*
                     * Mandatory reap after SIGKILL.
                     */
                    do {
                        wait_result = waitpid(child_pid, &status, 0);
                    } while (wait_result == -1 && errno == EINTR);

                    if (wait_result == -1) {
                        perror("waitpid");
                        close(exec_pipe[0]);
                        return SUPERVISOR_ERROR;
                    }

                    break;
                }

                sleep(1);
            }

            break;
        }

        sleep(1);
    }

    close(exec_pipe[0]);

    /*
     * If exec failed, the child has already exited or is about to.
     * Reap it under this path as required.
     */
    if (exec_failed) {
        do {
            wait_result = waitpid(child_pid, &status, 0);
        } while (wait_result == -1 && errno == EINTR);

        if (wait_result == -1) {
            perror("waitpid");
            return SUPERVISOR_ERROR;
        }

        fprintf(stderr,
                "Exec failure for child %ld: %s\n",
                (long)child_pid,
                strerror(exec_errno));

        log_result(child_pid, "EXEC_FAILURE", 127);

        return SUPERVISOR_EXEC_FAILURE;
    }

    /*
     * Ctrl+C is handled as a termination request, not as a timeout.
     */
    if (interrupt_triggered) {
        if (WIFEXITED(status)) {
            printf("Child %ld exited normally with status %d after termination request.\n",
                   (long)child_pid,
                   WEXITSTATUS(status));

            log_result(child_pid,
                       "INTERRUPTED_NORMAL_EXIT",
                       WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Child %ld terminated by signal %d after termination request.\n",
                   (long)child_pid,
                   WTERMSIG(status));

            log_result(child_pid,
                       "INTERRUPTED_SIGNAL",
                       WTERMSIG(status));
        }

        return SUPERVISOR_TIMEOUT;
    }

    if (timeout_triggered) {
        if (WIFSIGNALED(status)) {
            printf("Child %ld terminated by signal %d after timeout handling.\n",
                   (long)child_pid,
                   WTERMSIG(status));

            log_result(child_pid,
                       "TIMEOUT_SIGNAL",
                       WTERMSIG(status));
        } else if (WIFEXITED(status)) {
            printf("Child %ld exited normally with status %d during timeout handling.\n",
                   (long)child_pid,
                   WEXITSTATUS(status));

            log_result(child_pid,
                       "TIMEOUT_NORMAL_EXIT",
                       WEXITSTATUS(status));
        }

        return SUPERVISOR_TIMEOUT;
    }

    if (WIFEXITED(status)) {
        int exit_code = WEXITSTATUS(status);

        printf("Child %ld exited normally with status %d.\n",
               (long)child_pid,
               exit_code);

        log_result(child_pid, "NORMAL_EXIT", exit_code);

        return SUPERVISOR_OK;
    }

    if (WIFSIGNALED(status)) {
        int signal_number = WTERMSIG(status);

        printf("Child %ld terminated by signal %d.\n",
               (long)child_pid,
               signal_number);

        log_result(child_pid, "SIGNAL_TERMINATION", signal_number);

        return SUPERVISOR_SIGNALED;
    }

    log_message("RESULT outcome=UNKNOWN_WAIT_STATUS");
    return SUPERVISOR_ERROR;
}
