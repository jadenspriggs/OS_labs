#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <unistd.h>

int main(void)
{
    struct rlimit limit;

    limit.rlim_cur = 1;
    limit.rlim_max = 1;

    if (setrlimit(RLIMIT_CPU, &limit) == -1) {
        perror("setrlimit");
        return EXIT_FAILURE;
    }

    printf("PID=%ld: RLIMIT_CPU set to 1 second\n", (long)getpid());
    fflush(stdout);

    volatile unsigned long long iterations = 0;

    /*
     * Large finite bound. The CPU limit should terminate
     * the process before this loop can finish.
     */
    for (unsigned long long i = 0;
         i < 1000000000000ULL;
         i++) {
        iterations += i;
    }

    printf("Completed normally; iterations=%llu\n",
           iterations);

    return EXIT_SUCCESS;
}
