#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
    printf("Before fork: original process PID=%ld PPID=%ld\n",
           (long)getpid(), (long)getppid());
    fflush(stdout);

    pid_t child = fork();

    if (child < 0) {
        perror("fork");
        return EXIT_FAILURE;
    }

    if (child == 0) {
        printf("Child:  PID=%ld PPID=%ld fork_return=%ld\n",
               (long)getpid(), (long)getppid(), (long)child);

        sleep(3);

        return EXIT_SUCCESS;
    }

    printf("Parent: PID=%ld PPID=%ld fork_return=%ld\n",
           (long)getpid(), (long)getppid(), (long)child);

    int status;
    pid_t waited = waitpid(child, &status, 0);

    if (waited == -1) {
        perror("waitpid");
        return EXIT_FAILURE;
    }

    printf("Parent: child PID=%ld completed\n", (long)waited);

    return EXIT_SUCCESS;
}
