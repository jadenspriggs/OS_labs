#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main(void)
{
    printf("CPU worker PID=%ld starting\n", (long)getpid());
    fflush(stdout);

    time_t start = time(NULL);

    if (start == (time_t)-1) {
        perror("time");
        return EXIT_FAILURE;
    }

    unsigned long long iterations = 0;

    while (1) {
        iterations++;

        time_t now = time(NULL);

        if (now == (time_t)-1) {
            perror("time");
            return EXIT_FAILURE;
        }

        if (now - start >= 8) {
            break;
        }
    }

    printf("CPU worker PID=%ld finished; iterations=%llu\n",
           (long)getpid(), iterations);

    return EXIT_SUCCESS;
}
