#!/usr/bin/env bash

set -u

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/bin"
OUTPUT="$ROOT/output"
RESULTS="$OUTPUT/test_results.txt"

mkdir -p "$BIN" "$OUTPUT"

# Save complete output to the required file while also showing it.
exec > >(tee "$RESULTS") 2>&1

PASS_COUNT=0
FAIL_COUNT=0

pass()
{
    PASS_COUNT=$((PASS_COUNT + 1))
    echo "PASS: $1"
    echo "  Command: $2"
    echo "  Reason: $3"
    echo
}

fail()
{
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo "FAIL: $1"
    echo "  Command: $2"
    echo "  Reason: $3"
    echo
}

echo "========================================"
echo "CSC301 LAB TEST HARNESS"
echo "========================================"
echo "Started: $(date)"
echo

cd "$ROOT" || exit 1

# ============================================================
# BUILD
# ============================================================

echo "=== BUILDING PROGRAMS ==="

BUILD_FAILED=0

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/fork_identity.c -o bin/fork_identity || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/process_tree.c -o bin/process_tree || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/fork_exec.c -o bin/fork_exec || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/wait_lab.c -o bin/wait_lab || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/signal_worker.c -o bin/signal_worker || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/signal_controller.c -o bin/signal_controller || BUILD_FAILED=1

gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -g \
    src/cpu_limit.c -o bin/cpu_limit || BUILD_FAILED=1

if [ "$BUILD_FAILED" -ne 0 ]; then
    fail "Compilation" \
        "gcc compilation commands" \
        "At least one required program failed to compile."
    exit 1
fi

pass "Compilation" \
    "gcc compilation commands" \
    "All required lab programs compiled successfully."

# ============================================================
# CLEANUP FUNCTION
# ============================================================

cleanup_processes()
{
    pkill -x signal_worker 2>/dev/null || true
    pkill -x cpu_worker 2>/dev/null || true
}

# ============================================================
# 1. FORK IDENTITY
# ============================================================

OUT=$(mktemp)

timeout 10s "$BIN/fork_identity" >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -eq 0 ] &&
   grep -q "Parent" "$OUT" &&
   grep -q "Child" "$OUT"; then

    pass "Fork identity" \
        "./bin/fork_identity" \
        "Parent and child output were observed and the program exited normally."
else
    fail "Fork identity" \
        "./bin/fork_identity" \
        "Expected parent/child output or successful completion was missing."
fi

rm -f "$OUT"

# ============================================================
# 2. ONE-CHILD TREE
# ============================================================

OUT=$(mktemp)

timeout 10s "$BIN/process_tree" 1 >"$OUT" 2>&1
STATUS=$?

CHILD_COUNT=$(grep -c "Child" "$OUT" || true)

if [ "$STATUS" -eq 0 ] && [ "$CHILD_COUNT" -ge 1 ]; then
    pass "One-child tree" \
        "./bin/process_tree 1" \
        "The program completed and produced evidence of one child."
else
    fail "One-child tree" \
        "./bin/process_tree 1" \
        "The program did not complete correctly or child evidence was missing."
fi

rm -f "$OUT"

# ============================================================
# 3. FOUR-CHILD TREE
# ============================================================

OUT=$(mktemp)

timeout 15s "$BIN/process_tree" 4 >"$OUT" 2>&1
STATUS=$?

CHILD_COUNT=$(grep -c "Child" "$OUT" || true)

if [ "$STATUS" -eq 0 ] && [ "$CHILD_COUNT" -ge 4 ]; then
    pass "Four-child tree" \
        "./bin/process_tree 4" \
        "The program completed and produced evidence of four children."
else
    fail "Four-child tree" \
        "./bin/process_tree 4" \
        "The program did not complete or four-child evidence was missing."
fi

rm -f "$OUT"

# ============================================================
# 4. SUCCESSFUL EXEC
# ============================================================

OUT=$(mktemp)

timeout 10s "$BIN/fork_exec" \
    /usr/bin/printf 'child program executed\n' >"$OUT" 2>&1

STATUS=$?

if [ "$STATUS" -eq 0 ] &&
   grep -q "child program executed" "$OUT" &&
   grep -q "status 0" "$OUT"; then

    pass "Successful exec" \
        "./bin/fork_exec /usr/bin/printf 'child program executed\n'" \
        "The child executed printf and the parent observed exit status 0."
else
    fail "Successful exec" \
        "./bin/fork_exec /usr/bin/printf 'child program executed\n'" \
        "Expected program output or successful child status was missing."
fi

rm -f "$OUT"

# ============================================================
# 5. ALL WAITS COMPLETED
# ============================================================

OUT=$(mktemp)

timeout 12s "$BIN/wait_lab" >"$OUT" 2>&1
STATUS=$?

REAP_COUNT=$(grep -c "reaped PID" "$OUT" || true)

if [ "$STATUS" -eq 0 ] &&
   [ "$REAP_COUNT" -eq 3 ] &&
   grep -q "all three children" "$OUT"; then

    pass "All waits completed" \
        "./bin/wait_lab" \
        "Three children were reaped and the final completion message was observed."
else
    fail "All waits completed" \
        "./bin/wait_lab" \
        "The output did not prove that all three children were reaped."
fi

rm -f "$OUT"

# ============================================================
# 6. MISSING ARGUMENT
# ============================================================

OUT=$(mktemp)

timeout 5s "$BIN/process_tree" >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    pass "Missing argument" \
        "./bin/process_tree" \
        "The program rejected a missing argument."
else
    fail "Missing argument" \
        "./bin/process_tree" \
        "The program unexpectedly accepted a missing argument."
fi

rm -f "$OUT"

# ============================================================
# 7. NONNUMERIC CHILD COUNT
# ============================================================

OUT=$(mktemp)

timeout 5s "$BIN/process_tree" abc >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    pass "Nonnumeric child count" \
        "./bin/process_tree abc" \
        "The program rejected a nonnumeric child count."
else
    fail "Nonnumeric child count" \
        "./bin/process_tree abc" \
        "The program accepted a nonnumeric child count."
fi

rm -f "$OUT"

# ============================================================
# 8. CHILD COUNT ZERO
# ============================================================

OUT=$(mktemp)

timeout 5s "$BIN/process_tree" 0 >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    pass "Child count zero" \
        "./bin/process_tree 0" \
        "The program rejected zero."
else
    fail "Child count zero" \
        "./bin/process_tree 0" \
        "The program accepted zero."
fi

rm -f "$OUT"

# ============================================================
# 9. CHILD COUNT FIVE
# ============================================================

OUT=$(mktemp)

timeout 5s "$BIN/process_tree" 5 >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    pass "Child count five" \
        "./bin/process_tree 5" \
        "The program rejected a count greater than four."
else
    fail "Child count five" \
        "./bin/process_tree 5" \
        "The program accepted five children."
fi

rm -f "$OUT"

# ============================================================
# 10. INVALID PID
# ============================================================

OUT=$(mktemp)

timeout 5s "$BIN/signal_controller" 0 >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    pass "Invalid PID" \
        "./bin/signal_controller 0" \
        "The controller rejected PID 0."
else
    fail "Invalid PID" \
        "./bin/signal_controller 0" \
        "The controller accepted an invalid PID."
fi

rm -f "$OUT"

# ============================================================
# 11. FAILED EXEC
# ============================================================

OUT=$(mktemp)

timeout 10s "$BIN/fork_exec" /no/such/program >"$OUT" 2>&1
STATUS=$?

if [ "$STATUS" -eq 0 ] &&
   grep -qi "execvp\|No such file" "$OUT" &&
   grep -q "127" "$OUT"; then

    pass "Failed exec" \
        "./bin/fork_exec /no/such/program" \
        "execvp failure was reported and the parent observed child status 127."
else
    fail "Failed exec" \
        "./bin/fork_exec /no/such/program" \
        "Expected exec failure and child status 127 were not observed."
fi

rm -f "$OUT"

# ============================================================
# 12. TERMINATED WORKER
# ============================================================

OUT=$(mktemp)

cleanup_processes

"$BIN/signal_worker" >"$OUT" 2>&1 &
WORKER_PID=$!

sleep 1

if kill -0 "$WORKER_PID" 2>/dev/null; then

    timeout 5s "$BIN/signal_controller" "$WORKER_PID" >>"$OUT" 2>&1
    CONTROLLER_STATUS=$?

    # Never wait forever for the worker.
    timeout 5s bash -c "wait $WORKER_PID" 2>/dev/null
    WAIT_STATUS=$?

    if [ "$CONTROLLER_STATUS" -eq 0 ] &&
       grep -q "orderly shutdown" "$OUT" &&
       grep -q "exiting" "$OUT"; then

        pass "Terminated worker" \
            "./bin/signal_worker & ./bin/signal_controller <PID>" \
            "The controller sent signals and the worker performed an orderly shutdown."
    else
        fail "Terminated worker" \
            "./bin/signal_worker & ./bin/signal_controller <PID>" \
            "Expected controller success and orderly worker shutdown were not observed."
    fi

else

    fail "Terminated worker" \
        "./bin/signal_worker & ./bin/signal_controller <PID>" \
        "Worker did not remain alive long enough for controller testing."

fi

# Force cleanup if something went wrong.
kill "$WORKER_PID" 2>/dev/null || true
kill -9 "$WORKER_PID" 2>/dev/null || true

rm -f "$OUT"

# ============================================================
# 13. RESOURCE LIMIT
# ============================================================

OUT=$(mktemp)

# Run through timeout so a broken resource-limit program
# can NEVER freeze the entire test harness.
timeout 8s "$BIN/cpu_limit" >"$OUT" 2>&1
LIMIT_STATUS=$?

if grep -q "RLIMIT_CPU" "$OUT" &&
   ! grep -q "Completed normally" "$OUT" &&
   [ "$LIMIT_STATUS" -ne 0 ]; then

    pass "Enforced resource limit" \
        "./bin/cpu_limit" \
        "The CPU limit was configured and the workload did not complete normally."
else
    fail "Enforced resource limit" \
        "./bin/cpu_limit" \
        "The expected bounded CPU-limit termination was not observed."
fi

rm -f "$OUT"

# ============================================================
# 14. LIFECYCLE CLEANUP
# ============================================================

cleanup_processes

sleep 1

if ! pgrep -x signal_worker >/dev/null 2>&1 &&
   ! pgrep -x cpu_worker >/dev/null 2>&1; then

    pass "Lifecycle cleanup" \
        "pgrep -x signal_worker; pgrep -x cpu_worker" \
        "No known long-running lab worker remained."
else
    fail "Lifecycle cleanup" \
        "pgrep -x signal_worker; pgrep -x cpu_worker" \
        "A known lab worker process remained."
fi

# ============================================================
# 15. REPEATABILITY
# ============================================================

ORDER_FILE="$OUTPUT/concurrency_orders.txt"
: >"$ORDER_FILE"

REPEAT_FAILED=0

for RUN in 1 2 3 4 5
do
    OUT=$(mktemp)

    timeout 15s "$BIN/process_tree" 4 >"$OUT" 2>&1
    STATUS=$?

    if [ "$STATUS" -eq 0 ]; then

        # Remove PIDs so the comparison is not tied to exact PIDs.
        ORDER=$(grep -E "reaped|exit code|status" "$OUT" |
            sed -E 's/[0-9]{2,}/PID/g' |
            tr '\n' ' ')

        printf "Run %d: %s\n" "$RUN" "$ORDER" >>"$ORDER_FILE"

    else
        REPEAT_FAILED=1
        printf "Run %d: FAILED\n" "$RUN" >>"$ORDER_FILE"
    fi

    rm -f "$OUT"
done

if [ "$REPEAT_FAILED" -eq 0 ]; then
    pass "Repeatability" \
        "./bin/process_tree 4 (five runs)" \
        "Five concurrency runs completed; output was normalized so exact PIDs/order were not required."
else
    fail "Repeatability" \
        "./bin/process_tree 4 (five runs)" \
        "At least one of the five concurrency runs failed."
fi

# ============================================================
# FINAL CLEANUP
# ============================================================

cleanup_processes

echo
echo "========================================"
echo "FINAL TEST SUMMARY"
echo "========================================"
echo "PASS: $PASS_COUNT"
echo "FAIL: $FAIL_COUNT"
echo "Results: $RESULTS"
echo "Finished: $(date)"
echo "========================================"

if [ "$FAIL_COUNT" -eq 0 ]; then
    exit 0
else
    exit 1
fi
