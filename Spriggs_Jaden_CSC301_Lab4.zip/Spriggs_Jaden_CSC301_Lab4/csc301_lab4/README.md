Here is compilation of all commands used to run all bin files:

./bin/cpu_limit

./bin/fork_exec

./bin/process_supervisor

./bin/signal_controller

./bin/wait_lab

./bin/cpu_worker

./bin/fork_identity

./bin/process_tree

./bin/signal_worker

./bin/zombie_demo
