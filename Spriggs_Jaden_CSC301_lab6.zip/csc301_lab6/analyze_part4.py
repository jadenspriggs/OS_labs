import pandas as pd

df = pd.read_csv("output/part4_trials.csv")

unsafe_df = df[df["mode"].str.contains("unsafe")]
unsafe_mean = unsafe_df["elapsed_sec"].mean() if not unsafe_df.empty else 0

print(f"{'Mode':<15} | {'Correct':<8} | {'Mean (s)':<9} | {'Median (s)':<10} | {'Min (s)':<8} | {'Max (s)':<8} | Overhead")
print("-" * 80)

for mode, group in df.groupby("mode"):
    correct_count = int(group["correct"].sum())
    mean_t = group["elapsed_sec"].mean()
    med_t = group["elapsed_sec"].median()
    min_t = group["elapsed_sec"].min()
    max_t = group["elapsed_sec"].max()
    overhead = f"{(mean_t / unsafe_mean):.2f}x" if unsafe_mean > 0 else "N/A"
    print(f"{mode:<15} | {correct_count}/30    | {mean_t:.6f}  | {med_t:.6f}   | {min_t:.6f} | {max_t:.6f} | {overhead}")
