#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

typedef struct {
    int id;
    int payload;
} Item;

typedef struct {
    Item *buffer;
    int capacity;
    int head;
    int tail;
    int count;
    int max_occupancy;
    pthread_mutex_t mutex;
    sem_t sem_empty;
    sem_t sem_full;
} BoundedBuffer;

typedef struct {
    int producer_id;
    int items_to_produce;
    int n_producers;
    int total_items;
    BoundedBuffer *bb;
    unsigned int seed;
} ProducerArg;

typedef struct {
    int consumer_id;
    BoundedBuffer *bb;
    unsigned int seed;
    long long consumed_count;
    long long consumed_checksum;
    int *consumed_flags;
    int total_items;
    pthread_mutex_t *flags_mutex;
} ConsumerArg;

/* Global state for audit tracking */
static BoundedBuffer g_bb;

static void buffer_init(BoundedBuffer *bb, int capacity) {
    bb->buffer = malloc(sizeof(Item) * capacity);
    bb->capacity = capacity;
    bb->head = 0;
    bb->tail = 0;
    bb->count = 0;
    bb->max_occupancy = 0;
    pthread_mutex_init(&bb->mutex, NULL);
    sem_init(&bb->sem_empty, 0, capacity);
    sem_init(&bb->sem_full, 0, 0);
}

static void buffer_destroy(BoundedBuffer *bb) {
    pthread_mutex_destroy(&bb->mutex);
    sem_destroy(&bb->sem_empty);
    sem_destroy(&bb->sem_full);
    free(bb->buffer);
}

static void buffer_put(BoundedBuffer *bb, Item item) {
    sem_wait(&bb->sem_empty);
    pthread_mutex_lock(&bb->mutex);

    bb->buffer[bb->tail] = item;
    bb->tail = (bb->tail + 1) % bb->capacity;
    bb->count++;
    if (bb->count > bb->max_occupancy) {
        bb->max_occupancy = bb->count;
    }

    pthread_mutex_unlock(&bb->mutex);
    sem_post(&bb->sem_full);
}

static Item buffer_get(BoundedBuffer *bb) {
    sem_wait(&bb->sem_full);
    pthread_mutex_lock(&bb->mutex);

    Item item = bb->buffer[bb->head];
    bb->head = (bb->head + 1) % bb->capacity;
    bb->count--;

    pthread_mutex_unlock(&bb->mutex);
    sem_post(&bb->sem_empty);

    return item;
}

void *producer_worker(void *arg) {
    ProducerArg *parg = (ProducerArg *)arg;
    
    /* Calculate unique starting ID offset for this producer */
    int base_items = parg->total_items / parg->n_producers;
    int remainder = parg->total_items % parg->n_producers;
    int start_id = parg->producer_id * base_items + 
                   (parg->producer_id < remainder ? parg->producer_id : remainder);

    for (int i = 0; i < parg->items_to_produce; i++) {
        int item_id = start_id + i; /* Guaranteed to be strictly < total_items */
        Item item = { .id = item_id, .payload = item_id * 3 };

        if (parg->seed > 0) {
            usleep(rand_r(&parg->seed) % 100);
        }

        buffer_put(parg->bb, item);
    }
    return NULL;
}

void *consumer_worker(void *arg) {
    ConsumerArg *carg = (ConsumerArg *)arg;
    while (1) {
        Item item = buffer_get(carg->bb);

        /* Sentinel item signifies shutdown */
        if (item.id == -1) {
            break;
        }

        if (carg->seed > 0) {
            usleep(rand_r(&carg->seed) % 100);
        }

        carg->consumed_count++;
        carg->consumed_checksum += item.payload;

        if (item.id >= 0 && item.id < carg->total_items) {
            pthread_mutex_lock(carg->flags_mutex);
            carg->consumed_flags[item.id]++;
            pthread_mutex_unlock(carg->flags_mutex);
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 5 || argc > 6) {
        fprintf(stderr, "Usage: %s <num_producers (1-16)> <num_consumers (1-16)> <capacity (1-64)> <total_items> [seed]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int n_producers = atoi(argv[1]);
    int n_consumers = atoi(argv[2]);
    int capacity = atoi(argv[3]);
    int total_items = atoi(argv[4]);
    unsigned int seed = (argc == 6) ? (unsigned int)atoi(argv[5]) : 0;

    /* Expand input validation to support up to 16 threads for Category 4 test cases */
    if (n_producers < 1 || n_producers > 16 || n_consumers < 1 || n_consumers > 16) {
        fprintf(stderr, "Error: Producers and consumers must be between 1 and 16.\n");
        return EXIT_FAILURE;
    }
    if (capacity < 1 || capacity > 64) {
        fprintf(stderr, "Error: Capacity must be between 1 and 64.\n");
        return EXIT_FAILURE;
    }
    if (total_items < 1) {
        fprintf(stderr, "Error: Total items must be at least 1.\n");
        return EXIT_FAILURE;
    }

    buffer_init(&g_bb, capacity);

    /* Dynamically allocate thread and argument arrays */
    pthread_t *producers = malloc(sizeof(pthread_t) * n_producers);
    pthread_t *consumers = malloc(sizeof(pthread_t) * n_consumers);
    ProducerArg *pargs = malloc(sizeof(ProducerArg) * n_producers);
    ConsumerArg *cargs = malloc(sizeof(ConsumerArg) * n_consumers);

    int *consumed_flags = calloc(total_items, sizeof(int));
    pthread_mutex_t flags_mutex = PTHREAD_MUTEX_INITIALIZER;


    /* Start Consumers */
    for (int i = 0; i < n_consumers; i++) {
        cargs[i].consumer_id = i;
        cargs[i].bb = &g_bb;
        cargs[i].seed = seed ? seed + i + 100 : 0;
        cargs[i].consumed_count = 0;
        cargs[i].consumed_checksum = 0;
        cargs[i].consumed_flags = consumed_flags;
        cargs[i].total_items = total_items;
        cargs[i].flags_mutex = &flags_mutex;
        pthread_create(&consumers[i], NULL, consumer_worker, &cargs[i]);
    }

    int base_items = total_items / n_producers;
    int remainder = total_items % n_producers;

    for (int i = 0; i < n_producers; i++) {
        pargs[i].producer_id = i;
        pargs[i].n_producers = n_producers;                       /* PASS TOTAL PRODUCERS */
        pargs[i].items_to_produce = base_items + (i < remainder ? 1 : 0);
        pargs[i].total_items = total_items;                       /* PASS TOTAL ITEMS */
        pargs[i].bb = &g_bb;
        pargs[i].seed = seed ? seed + i : 0;
        pthread_create(&producers[i], NULL, producer_worker, &pargs[i]);
    }
    /* Join Producers */
    for (int i = 0; i < n_producers; i++) {
        pthread_join(producers[i], NULL);
    }

    /* Send Sentinel shutdown items (-1) to terminate Consumers */
    for (int i = 0; i < n_consumers; i++) {
        Item sentinel = { .id = -1, .payload = 0 };
        buffer_put(&g_bb, sentinel);
    }

    /* Join Consumers */
    long long total_consumed = 0;
    long long actual_checksum = 0;
    for (int i = 0; i < n_consumers; i++) {
        pthread_join(consumers[i], NULL);
        total_consumed += cargs[i].consumed_count;
        actual_checksum += cargs[i].consumed_checksum;
    }

    /* Verification and Audit checks */
    int duplicates = 0;
    int missing = 0;
    for (int i = 0; i < total_items; i++) {
        if (consumed_flags[i] == 0) missing++;
        else if (consumed_flags[i] > 1) duplicates += (consumed_flags[i] - 1);
    }

    printf("Producers: %d | Consumers: %d | Capacity: %d | Total Items: %d | Seed: %u\n",
           n_producers, n_consumers, capacity, total_items, seed);
    printf("Max Occupancy: %d/%d | Consumed: %lld/%d | Duplicates: %d | Missing: %d\n",
           g_bb.max_occupancy, capacity, total_consumed, total_items, duplicates, missing);
    printf("Checksum Verification: %s (Actual: %lld)\n",
           (total_consumed == total_items && duplicates == 0 && missing == 0) ? "PASSED" : "FAILED",
           actual_checksum);

    /* Free dynamically allocated heap memory */
    free(consumed_flags);
    free(producers);
    free(consumers);
    free(pargs);
    free(cargs);

    buffer_destroy(&g_bb);
    pthread_mutex_destroy(&flags_mutex);

    return (duplicates == 0 && missing == 0 && total_consumed == total_items) ? EXIT_SUCCESS : EXIT_FAILURE;
}
