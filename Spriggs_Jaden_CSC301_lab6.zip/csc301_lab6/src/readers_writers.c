#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <stdatomic.h>
#include <getopt.h>

typedef struct {
    long long version;
    long long value_a;
    long long value_b;
    long long checksum; /* Invariant: checksum == value_a + value_b + version */
} SharedData;

typedef struct {
    int id;
    int duration_sec;
    unsigned int seed;
    long long reads_completed;
    long long invariant_violations;
    double total_wait_time_sec;
} ReaderArg;

typedef struct {
    int id;
    int duration_sec;
    unsigned int seed;
    long long writes_completed;
    double total_wait_time_sec;
} WriterArg;

/* Global synchronization objects & shared state */
static SharedData g_data = { .version = 0, .value_a = 100, .value_b = 200, .checksum = 300 };
static pthread_rwlock_t g_rwlock = PTHREAD_RWLOCK_INITIALIZER;
static _Atomic int g_active_readers = 0;
static _Atomic int g_active_writers = 0;
static _Atomic int g_max_concurrent_readers = 0;
static volatile bool g_running = true;

static double get_time_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

void *reader_worker(void *arg) {
    ReaderArg *rarg = (ReaderArg *)arg;
    unsigned int seed = rarg->seed;

    while (g_running) {
        double start_wait = get_time_sec();
        pthread_rwlock_rdlock(&g_rwlock);
        double end_wait = get_time_sec();
        rarg->total_wait_time_sec += (end_wait - start_wait);

        /* Track reader concurrency and verify writer exclusivity */
        int current_readers = atomic_fetch_add(&g_active_readers, 1) + 1;
        int current_writers = atomic_load(&g_active_writers);

        int max_r = atomic_load(&g_max_concurrent_readers);
        while (current_readers > max_r && 
               !atomic_compare_exchange_weak(&g_max_concurrent_readers, &max_r, current_readers)) {
            /* Retry atomic CAS if max updated concurrently */
        }

        /* Verify invariant inside read lock */
        SharedData local_copy = g_data;
        long long expected_checksum = local_copy.value_a + local_copy.value_b + local_copy.version;

        if (local_copy.checksum != expected_checksum || current_writers > 0) {
            rarg->invariant_violations++;
        }

        rarg->reads_completed++;
        
        /* Optional simulated work */
        if (seed > 0 && rand_r(&seed) % 10 == 0) {
            usleep(10);
        }

        atomic_fetch_sub(&g_active_readers, 1);
        pthread_rwlock_unlock(&g_rwlock);

        usleep(50); /* Prevent reader starvation of writers */
    }
    return NULL;
}

void *writer_worker(void *arg) {
    WriterArg *warg = (WriterArg *)arg;
    unsigned int seed = warg->seed;

    while (g_running) {
        double start_wait = get_time_sec();
        pthread_rwlock_wrlock(&g_rwlock);
        double end_wait = get_time_sec();
        warg->total_wait_time_sec += (end_wait - start_wait);

        atomic_fetch_add(&g_active_writers, 1);

        /* Mutate shared state ensuring checksum invariant remains intact */
        g_data.version++;
        g_data.value_a += 5;
        g_data.value_b += 10;
        g_data.checksum = g_data.value_a + g_data.value_b + g_data.version;

        warg->writes_completed++;

        /* Simulated write duration */
        if (seed > 0) {
            usleep(rand_r(&seed) % 200);
        }

        atomic_fetch_sub(&g_active_writers, 1);
        pthread_rwlock_unlock(&g_rwlock);

        usleep(100);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    int num_readers = 8;
    int num_writers = 1;
    int duration_sec = 5;
    unsigned int seed = 301;

    static struct option long_options[] = {
        {"readers", required_argument, 0, 'r'},
        {"writers", required_argument, 0, 'w'},
        {"seconds", required_argument, 0, 's'},
        {"seed",    required_argument, 0, 'e'},
        {0, 0, 0, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "r:w:s:e:", long_options, NULL)) != -1) {
        switch (opt) {
            case 'r': num_readers = atoi(optarg); break;
            case 'w': num_writers = atoi(optarg); break;
            case 's': duration_sec = atoi(optarg); break;
            case 'e': seed = atoi(optarg); break;
            default:
                fprintf(stderr, "Usage: %s --readers <2-12> --writers <1-3> --seconds <sec> --seed <seed>\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    if (num_readers < 2 || num_readers > 12 || num_writers < 1 || num_writers > 3) {
        fprintf(stderr, "Error: Readers must be 2-12, Writers must be 1-3.\n");
        return EXIT_FAILURE;
    }

    pthread_t reader_threads[12], writer_threads[3];
    ReaderArg rargs[12];
    WriterArg wargs[3];

    g_running = true;

    /* Start Reader Threads */
    for (int i = 0; i < num_readers; i++) {
        rargs[i].id = i;
        rargs[i].duration_sec = duration_sec;
        rargs[i].seed = seed + i;
        rargs[i].reads_completed = 0;
        rargs[i].invariant_violations = 0;
        rargs[i].total_wait_time_sec = 0.0;
        pthread_create(&reader_threads[i], NULL, reader_worker, &rargs[i]);
    }

    /* Start Writer Threads */
    for (int i = 0; i < num_writers; i++) {
        wargs[i].id = i;
        wargs[i].duration_sec = duration_sec;
        wargs[i].seed = seed + 100 + i;
        wargs[i].writes_completed = 0;
        wargs[i].total_wait_time_sec = 0.0;
        pthread_create(&writer_threads[i], NULL, writer_worker, &wargs[i]);
    }

    /* Run workload for fixed duration */
    sleep(duration_sec);
    g_running = false;

    /* Join Threads */
    long long total_reads = 0, total_violations = 0;
    double total_reader_wait = 0.0;
    for (int i = 0; i < num_readers; i++) {
        pthread_join(reader_threads[i], NULL);
        total_reads += rargs[i].reads_completed;
        total_violations += rargs[i].invariant_violations;
        total_reader_wait += rargs[i].total_wait_time_sec;
    }

    long long total_writes = 0;
    double total_writer_wait = 0.0;
    for (int i = 0; i < num_writers; i++) {
        pthread_join(writer_threads[i], NULL);
        total_writes += wargs[i].writes_completed;
        total_writer_wait += wargs[i].total_wait_time_sec;
    }

    double avg_reader_wait = total_reads > 0 ? (total_reader_wait / total_reads) * 1e6 : 0.0;
    double avg_writer_wait = total_writes > 0 ? (total_writer_wait / total_writes) * 1e6 : 0.0;

    printf("=== Readers-Writers Results (R: %d | W: %d | Sec: %d | Seed: %u) ===\n",
           num_readers, num_writers, duration_sec, seed);
    printf("Completed Reads: %lld | Completed Writes: %lld\n", total_reads, total_writes);
    printf("Max Concurrent Readers: %d (Max Allowed: %d)\n", atomic_load(&g_max_concurrent_readers), num_readers);
    printf("Invariant Violations: %lld | Verification: %s\n", 
           total_violations, total_violations == 0 ? "PASSED" : "FAILED");
    printf("Avg Reader Wait: %.2fus | Avg Writer Wait: %.2fus\n\n", avg_reader_wait, avg_writer_wait);

    pthread_rwlock_destroy(&g_rwlock);
    return (total_violations == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
