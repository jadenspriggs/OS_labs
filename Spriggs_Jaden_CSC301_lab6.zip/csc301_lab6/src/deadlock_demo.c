#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <getopt.h>

typedef enum {
    MODE_UNSAFE,
    MODE_ORDERED,
    MODE_TRYLOCK
} DemoMode;

typedef struct {
    int thread_id;
    DemoMode mode;
} ThreadArg;

/* Global Mutexes and Phase Synchronization Barrier */
static pthread_mutex_t mutex_A = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t mutex_B = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t barrier;

void *worker_thread_0(void *arg) {
    ThreadArg *targ = (ThreadArg *)arg;

    printf("[Thread 0] Starting in mode: %d\n", targ->mode);
    pthread_barrier_wait(&barrier); /* Ensure both threads start acquisition concurrently */

    if (targ->mode == MODE_UNSAFE) {
        /* Unsafe Acquisition Order: Mutex A -> Mutex B */
        pthread_mutex_lock(&mutex_A);
        printf("[Thread 0] Acquired Mutex A. Waiting for Mutex B...\n");
        usleep(1000); /* Force context switch window */
        pthread_mutex_lock(&mutex_B);
        printf("[Thread 0] Acquired Mutex B!\n");

        pthread_mutex_unlock(&mutex_B);
        pthread_mutex_unlock(&mutex_A);
    } 
    else if (targ->mode == MODE_ORDERED) {
        /* Lock Ordering Prevention Strategy: Mutex A -> Mutex B */
        pthread_mutex_lock(&mutex_A);
        printf("[Thread 0] Acquired Mutex A. Requesting Mutex B...\n");
        pthread_mutex_lock(&mutex_B);
        printf("[Thread 0] Acquired Mutex B successfully.\n");

        pthread_mutex_unlock(&mutex_B);
        pthread_mutex_unlock(&mutex_A);
    } 
    else if (targ->mode == MODE_TRYLOCK) {
        /* Non-blocking Trylock with Backoff Recovery Strategy */
        while (1) {
            pthread_mutex_lock(&mutex_A);
            printf("[Thread 0] Acquired Mutex A. Trying Mutex B...\n");

            if (pthread_mutex_trylock(&mutex_B) == 0) {
                printf("[Thread 0] Acquired Mutex B via trylock!\n");
                pthread_mutex_unlock(&mutex_B);
                pthread_mutex_unlock(&mutex_A);
                break;
            }

            printf("[Thread 0] Mutex B busy. Backing off and releasing Mutex A...\n");
            pthread_mutex_unlock(&mutex_A);
            usleep(rand() % 1000 + 500); /* Random backoff delay */
        }
    }

    printf("[Thread 0] Exiting cleanly.\n");
    return NULL;
}

void *worker_thread_1(void *arg) {
    ThreadArg *targ = (ThreadArg *)arg;

    printf("[Thread 1] Starting in mode: %d\n", targ->mode);
    pthread_barrier_wait(&barrier); /* Ensure both threads start acquisition concurrently */

    if (targ->mode == MODE_UNSAFE) {
        /* Unsafe Acquisition Order: Mutex B -> Mutex A (Creates Circular Wait) */
        pthread_mutex_lock(&mutex_B);
        printf("[Thread 1] Acquired Mutex B. Waiting for Mutex A...\n");
        usleep(1000); /* Force context switch window */
        pthread_mutex_lock(&mutex_A);
        printf("[Thread 1] Acquired Mutex A!\n");

        pthread_mutex_unlock(&mutex_A);
        pthread_mutex_unlock(&mutex_B);
    } 
    else if (targ->mode == MODE_ORDERED) {
        /* Lock Ordering Prevention Strategy: Always Acquire Mutex A BEFORE Mutex B */
        pthread_mutex_lock(&mutex_A);
        printf("[Thread 1] Acquired Mutex A. Requesting Mutex B...\n");
        pthread_mutex_lock(&mutex_B);
        printf("[Thread 1] Acquired Mutex B successfully.\n");

        pthread_mutex_unlock(&mutex_B);
        pthread_mutex_unlock(&mutex_A);
    } 
    else if (targ->mode == MODE_TRYLOCK) {
        /* Non-blocking Trylock with Backoff Recovery Strategy */
        while (1) {
            pthread_mutex_lock(&mutex_B);
            printf("[Thread 1] Acquired Mutex B. Trying Mutex A...\n");

            if (pthread_mutex_trylock(&mutex_A) == 0) {
                printf("[Thread 1] Acquired Mutex A via trylock!\n");
                pthread_mutex_unlock(&mutex_A);
                pthread_mutex_unlock(&mutex_B);
                break;
            }

            printf("[Thread 1] Mutex A busy. Backing off and releasing Mutex B...\n");
            pthread_mutex_unlock(&mutex_B);
            usleep(rand() % 1000 + 500); /* Random backoff delay */
        }
    }

    printf("[Thread 1] Exiting cleanly.\n");
    return NULL;
}

int main(int argc, char *argv[]) {
    DemoMode mode = MODE_UNSAFE;

    static struct option long_options[] = {
        {"mode", required_argument, 0, 'm'},
        {0, 0, 0, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "m:", long_options, NULL)) != -1) {
        switch (opt) {
            case 'm':
                if (strcmp(optarg, "unsafe") == 0) mode = MODE_UNSAFE;
                else if (strcmp(optarg, "ordered") == 0) mode = MODE_ORDERED;
                else if (strcmp(optarg, "trylock") == 0) mode = MODE_TRYLOCK;
                else {
                    fprintf(stderr, "Unknown mode: %s\n", optarg);
                    return EXIT_FAILURE;
                }
                break;
            default:
                fprintf(stderr, "Usage: %s --mode <unsafe|ordered|trylock>\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    srand(time(NULL));
    pthread_barrier_init(&barrier, NULL, 2);

    pthread_t t0, t1;
    ThreadArg arg0 = { .thread_id = 0, .mode = mode };
    ThreadArg arg1 = { .thread_id = 1, .mode = mode };

    pthread_create(&t0, NULL, worker_thread_0, &arg0);
    pthread_create(&t1, NULL, worker_thread_1, &arg1);

    pthread_join(t0, NULL);
    pthread_join(t1, NULL);

    pthread_barrier_destroy(&barrier);
    pthread_mutex_destroy(&mutex_A);
    pthread_mutex_destroy(&mutex_B);

    printf("Program completed successfully without deadlock.\n");
    return EXIT_SUCCESS;
}
