#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include <getopt.h>

typedef struct {
    int thread_id;
    int num_threads;
    double *data;
    long long start_idx;
    long long end_idx;
    
    /* Phase 1 Local Results */
    long long local_count;
    double local_sum;
    double local_min;
    double local_max;

    /* Phase 2 Verification Status */
    int verification_passed;
} WorkerArg;

/* Global Synchronization and Aggregated Results */
static pthread_barrier_t g_barrier;
static WorkerArg *g_worker_args;
static long long g_total_elements = 0;
static double g_global_sum = 0.0;
static double g_global_mean = 0.0;
static double g_global_min = INFINITY;
static double g_global_max = -INFINITY;

static double get_time_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

void *worker_entry(void *arg) {
    WorkerArg *warg = (WorkerArg *)arg;

    /* -------------------------------------------------------------
     * PHASE 1: Local Partition Processing
     * ------------------------------------------------------------- */
    warg->local_count = warg->end_idx - warg->start_idx;
    warg->local_sum = 0.0;
    warg->local_min = INFINITY;
    warg->local_max = -INFINITY;

    for (long long i = warg->start_idx; i < warg->end_idx; i++) {
        double val = warg->data[i];
        warg->local_sum += val;
        if (val < warg->local_min) warg->local_min = val;
        if (val > warg->local_max) warg->local_max = val;
    }

    /* -------------------------------------------------------------
     * SYNCHRONIZATION POINT: POSIX Phase Barrier
     * All workers wait here until Phase 1 reduction is complete.
     * ------------------------------------------------------------- */
    int barrier_rc = pthread_barrier_wait(&g_barrier);

    /* Designated serial aggregator thread updates global statistics */
    if (barrier_rc == PTHREAD_BARRIER_SERIAL_THREAD) {
        g_global_sum = 0.0;
        g_global_min = INFINITY;
        g_global_max = -INFINITY;

        for (int i = 0; i < warg->num_threads; i++) {
            g_global_sum += g_worker_args[i].local_sum;
            if (g_worker_args[i].local_min < g_global_min) g_global_min = g_worker_args[i].local_min;
            if (g_worker_args[i].local_max > g_global_max) g_global_max = g_worker_args[i].local_max;
        }
        g_global_mean = g_global_sum / g_total_elements;
    }

    /* Second barrier synchronization ensures global variables are updated before Phase 2 */
    pthread_barrier_wait(&g_barrier);

    /* -------------------------------------------------------------
     * PHASE 2: Parallel Verification
     * Workers verify partition bounds against global mean/min/max
     * ------------------------------------------------------------- */
    warg->verification_passed = 1;
    for (long long i = warg->start_idx; i < warg->end_idx; i++) {
        double val = warg->data[i];
        if (val < g_global_min || val > g_global_max) {
            warg->verification_passed = 0;
            break;
        }
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    int num_threads = 4;
    long long total_elements = 1000000;
    unsigned int seed = 301;

    static struct option long_options[] = {
        {"threads",  required_argument, 0, 't'},
        {"elements", required_argument, 0, 'n'},
        {"seed",     required_argument, 0, 's'},
        {0, 0, 0, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "t:n:s:", long_options, NULL)) != -1) {
        switch (opt) {
            case 't': num_threads = atoi(optarg); break;
            case 'n': total_elements = atoll(optarg); break;
            case 's': seed = atoi(optarg); break;
            default:
                fprintf(stderr, "Usage: %s --threads <1-16> --elements <N> --seed <S>\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    if (num_threads < 1 || num_threads > 16) {
        fprintf(stderr, "Error: Threads must be between 1 and 16.\n");
        return EXIT_FAILURE;
    }

    g_total_elements = total_elements;
    double *data = malloc(sizeof(double) * total_elements);

    /* Generate deterministic random input data */
    unsigned int rand_state = seed;
    for (long long i = 0; i < total_elements; i++) {
        data[i] = (rand_r(&rand_state) % 10000) / 10.0;
    }

    /* Sequential reference computation for correctness comparison */
    double seq_start = get_time_sec();
    double seq_sum = 0.0, seq_min = INFINITY, seq_max = -INFINITY;
    for (long long i = 0; i < total_elements; i++) {
        seq_sum += data[i];
        if (data[i] < seq_min) seq_min = data[i];
        if (data[i] > seq_max) seq_max = data[i];
    }
    double seq_mean = seq_sum / total_elements;
    double seq_time = get_time_sec() - seq_start;

    /* Initialize barrier and thread state */
    pthread_barrier_init(&g_barrier, NULL, num_threads);
    pthread_t threads[16];
    g_worker_args = malloc(sizeof(WorkerArg) * num_threads);

    long long base_chunk = total_elements / num_threads;
    long long remainder = total_elements % num_threads;

    double par_start = get_time_sec();

    /* Partition elements across workers (Exact distribution handling remainders) */
    long long current_idx = 0;
    for (int i = 0; i < num_threads; i++) {
        long long chunk = base_chunk + (i < remainder ? 1 : 0);
        g_worker_args[i].thread_id = i;
        g_worker_args[i].num_threads = num_threads;
        g_worker_args[i].data = data;
        g_worker_args[i].start_idx = current_idx;
        g_worker_args[i].end_idx = current_idx + chunk;
        current_idx += chunk;

        pthread_create(&threads[i], NULL, worker_entry, &g_worker_args[i]);
    }

    /* Join all workers */
    int all_passed = 1;
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
        if (!g_worker_args[i].verification_passed) all_passed = 0;
    }

    double par_time = get_time_sec() - par_start;

    /* Verify parallel results against trusted sequential baseline */
    bool match = (fabs(g_global_sum - seq_sum) < 1e-4) &&
                 (fabs(g_global_min - seq_min) < 1e-4) &&
                 (fabs(g_global_max - seq_max) < 1e-4);

    printf("=== Parallel Statistics Results (Threads: %d | N: %lld | Seed: %u) ===\n",
           num_threads, total_elements, seed);
    printf("Parallel Mean: %.4f | Min: %.1f | Max: %.1f\n", g_global_mean, g_global_min, g_global_max);
    printf("Sequential Mean: %.4f | Min: %.1f | Max: %.1f\n", seq_mean, seq_min, seq_max);
    printf("Verification against Sequential: %s\n", match ? "PASSED" : "FAILED");
    printf("Phase 2 Partition Verification: %s\n", all_passed ? "PASSED" : "FAILED");
    printf("Execution Times: Sequential = %.6fs | Parallel = %.6fs (Speedup: %.2fx)\n\n",
           seq_time, par_time, seq_time / par_time);

    pthread_barrier_destroy(&g_barrier);
    free(g_worker_args);
    free(data);

    return (match && all_passed) ? EXIT_SUCCESS : EXIT_FAILURE;
}
