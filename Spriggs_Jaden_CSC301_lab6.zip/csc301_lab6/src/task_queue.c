#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>

#define MAX_WORKERS 16
#define MAX_TASKS 10000
#define DEFAULT_QUEUE_CAPACITY 64

/* Task Structure */
typedef struct {
    int task_id;
    uint32_t workload_seed;
    int injected_delay_ms;
    uint64_t expected_result;
} Task;

/* Bounded Queue Structure with Synchronization */
typedef struct {
    Task *buffer;
    int capacity;
    int head;
    int tail;
    int count;
    bool shutdown;
    bool cancelled;
    pthread_mutex_t mutex;
    pthread_cond_t not_full;
    pthread_cond_t not_empty;
} BoundedQueue;

/* Per-Worker Context and Audit Log */
typedef struct {
    int worker_id;
    int tasks_completed;
    int tasks_failed;
    double total_busy_time_sec;
    BoundedQueue *queue;
    pthread_t thread;
} WorkerContext;

/* Synchronized Counters */
static pthread_mutex_t stats_mutex = PTHREAD_MUTEX_INITIALIZER;
static int g_submitted = 0;
static int g_started = 0;
static int g_completed = 0;
static int g_failed = 0;
static int g_active = 0;

/* Oracle Deterministic CPU Workload Calculation */
static uint64_t compute_oracle_hash(uint32_t seed) {
    uint64_t hash = seed;
    for (int i = 0; i < 50000; i++) {
        hash = hash * 6364136223846793005ULL + 1442695040888963407ULL;
    }
    return hash;
}

static void queue_init(BoundedQueue *q, int capacity) {
    q->buffer = malloc(sizeof(Task) * capacity);
    q->capacity = capacity;
    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->shutdown = false;
    q->cancelled = false;
    pthread_mutex_init(&q->mutex, NULL);
    pthread_cond_init(&q->not_full, NULL);
    pthread_cond_init(&q->not_empty, NULL);
}

static void queue_destroy(BoundedQueue *q) {
    pthread_mutex_destroy(&q->mutex);
    pthread_cond_destroy(&q->not_full);
    pthread_cond_destroy(&q->not_empty);
    free(q->buffer);
}

/* Blocking Queue Push (Blocks submitters when full) */
static bool queue_push(BoundedQueue *q, Task task) {
    pthread_mutex_lock(&q->mutex);
    while (q->count == q->capacity && !q->shutdown && !q->cancelled) {
        pthread_cond_wait(&q->not_full, &q->mutex);
    }

    if (q->shutdown || q->cancelled) {
        pthread_mutex_unlock(&q->mutex);
        return false;
    }

    q->buffer[q->tail] = task;
    q->tail = (q->tail + 1) % q->capacity;
    q->count++;

    pthread_mutex_lock(&stats_mutex);
    g_submitted++;
    pthread_mutex_unlock(&stats_mutex);

    pthread_cond_signal(&q->not_empty);
    pthread_mutex_unlock(&q->mutex);
    return true;
}

/* Blocking Queue Pop (Blocks workers when empty) */
static bool queue_pop(BoundedQueue *q, Task *out_task) {
    pthread_mutex_lock(&q->mutex);
    while (q->count == 0 && !q->shutdown && !q->cancelled) {
        pthread_cond_wait(&q->not_empty, &q->mutex);
    }

    if (q->count == 0 || q->cancelled) {
        pthread_mutex_unlock(&q->mutex);
        return false;
    }

    *out_task = q->buffer[q->head];
    q->head = (q->head + 1) % q->capacity;
    q->count--;

    pthread_mutex_lock(&stats_mutex);
    g_started++;
    g_active++;
    pthread_mutex_unlock(&stats_mutex);

    pthread_cond_signal(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
    return true;
}

static void queue_shutdown_orderly(BoundedQueue *q) {
    pthread_mutex_lock(&q->mutex);
    q->shutdown = true;
    pthread_cond_broadcast(&q->not_empty);
    pthread_cond_broadcast(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
}

static void queue_cancel_fatal(BoundedQueue *q) {
    pthread_mutex_lock(&q->mutex);
    q->cancelled = true;
    pthread_cond_broadcast(&q->not_empty);
    pthread_cond_broadcast(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
}

void *worker_routine(void *arg) {
    WorkerContext *ctx = (WorkerContext *)arg;
    Task task;

    while (queue_pop(ctx->queue, &task)) {
        struct timespec start_t, end_t;
        clock_gettime(CLOCK_MONOTONIC, &start_t);

        /* Handle injected worker delay for stress testing */
        if (task.injected_delay_ms > 0) {
            usleep(task.injected_delay_ms * 1000);
        }

        /* Execute task workload */
        uint64_t actual_result = compute_oracle_hash(task.workload_seed);

        clock_gettime(CLOCK_MONOTONIC, &end_t);
        double duration = (end_t.tv_sec - start_t.tv_sec) + 
                          (end_t.tv_nsec - start_t.tv_nsec) / 1e9;

        ctx->total_busy_time_sec += duration;

        /* Verify against sequential oracle */
        bool match = (actual_result == task.expected_result);

        pthread_mutex_lock(&stats_mutex);
        g_active--;
        if (match) {
            ctx->tasks_completed++;
            g_completed++;
        } else {
            ctx->tasks_failed++;
            g_failed++;
        }
        pthread_mutex_unlock(&stats_mutex);

        /* Trigger fatal cancellation on mismatch error */
        if (!match) {
            fprintf(stderr, "FATAL ERROR: Task ID %d result mismatch!\n", task.task_id);
            queue_cancel_fatal(ctx->queue);
            break;
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <num_workers (1-16)> <num_tasks (1-10000)> [capacity] [delay_ms]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num_workers = atoi(argv[1]);
    int num_tasks = atoi(argv[2]);
    int capacity = (argc >= 4) ? atoi(argv[3]) : DEFAULT_QUEUE_CAPACITY;
    int injected_delay_ms = (argc >= 5) ? atoi(argv[4]) : 0;

    if (num_workers < 1 || num_workers > MAX_WORKERS || num_tasks < 1 || num_tasks > MAX_TASKS) {
        fprintf(stderr, "Error: Invalid bounds. Workers: 1-16, Tasks: 1-10000.\n");
        return EXIT_FAILURE;
    }

    BoundedQueue queue;
    queue_init(&queue, capacity);

    WorkerContext workers[MAX_WORKERS];
    for (int i = 0; i < num_workers; i++) {
        workers[i].worker_id = i;
        workers[i].tasks_completed = 0;
        workers[i].tasks_failed = 0;
        workers[i].total_busy_time_sec = 0.0;
        workers[i].queue = &queue;
        pthread_create(&workers[i].thread, NULL, worker_routine, &workers[i]);
    }

    struct timespec global_start, global_end;
    clock_gettime(CLOCK_MONOTONIC, &global_start);

    /* Submit tasks stream */
    for (int i = 0; i < num_tasks; i++) {
        uint32_t seed = (uint32_t)(i + 100);
        Task task = {
            .task_id = i,
            .workload_seed = seed,
            .injected_delay_ms = injected_delay_ms,
            .expected_result = compute_oracle_hash(seed)
        };

        if (!queue_push(&queue, task)) {
            break; /* Submit interrupted by fatal cancellation */
        }
    }

    /* Signal orderly shutdown and join worker pool */
    queue_shutdown_orderly(&queue);

    for (int i = 0; i < num_workers; i++) {
        pthread_join(workers[i].thread, NULL);
    }

    clock_gettime(CLOCK_MONOTONIC, &global_end);
    double total_elapsed = (global_end.tv_sec - global_start.tv_sec) + 
                          (global_end.tv_nsec - global_start.tv_nsec) / 1e9;

    /* Compute Workload Imbalance Statistics */
    int min_tasks = workers[0].tasks_completed;
    int max_tasks = workers[0].tasks_completed;
    double sum_tasks = 0.0;

    for (int i = 0; i < num_workers; i++) {
        int count = workers[i].tasks_completed;
        if (count < min_tasks) min_tasks = count;
        if (count > max_tasks) max_tasks = count;
        sum_tasks += count;
    }

    double mean_tasks = sum_tasks / num_workers;
    double var_sum = 0.0;
    for (int i = 0; i < num_workers; i++) {
        double diff = workers[i].tasks_completed - mean_tasks;
        var_sum += diff * diff;
    }
    double stddev_tasks = sqrt(var_sum / num_workers);
    double imbalance_ratio = (min_tasks > 0) ? ((double)max_tasks / min_tasks) : 0.0;

    /* Generate output/task_summary.csv */
    mkdir("output", 0777);
    FILE *f = fopen("output/task_summary.csv", "w");
    if (f) {
        fprintf(f, "# Task Queue Summary Metrics\n");
        fprintf(f, "# Workers: %d, Total Tasks: %d, Capacity: %d, Elapsed Sec: %.6f\n",
                num_workers, num_tasks, capacity, total_elapsed);
        fprintf(f, "# Synchronized Counters - Submitted: %d, Started: %d, Completed: %d, Failed: %d, QueuedRemaining: %d, Active: %d\n",
                g_submitted, g_started, g_completed, g_failed, queue.count, g_active);
        fprintf(f, "# Imbalance Stats - Min: %d, Max: %d, Mean: %.2f, StdDev: %.2f, Ratio: %.2f\n",
                min_tasks, max_tasks, mean_tasks, stddev_tasks, imbalance_ratio);
        fprintf(f, "WorkerID,TasksCompleted,TasksFailed,BusyTimeSec\n");

        for (int i = 0; i < num_workers; i++) {
            fprintf(f, "%d,%d,%d,%.6f\n", 
                    workers[i].worker_id, workers[i].tasks_completed, 
                    workers[i].tasks_failed, workers[i].total_busy_time_sec);
        }
        fclose(f);
    }

    printf("Task Pool Completed | Workers: %d | Tasks: %d | Completed: %d | Elapsed: %.4fs\n",
           num_workers, num_tasks, g_completed, total_elapsed);

    queue_destroy(&queue);
    return (g_failed == 0 && g_completed == num_tasks) ? EXIT_SUCCESS : EXIT_FAILURE;
}
