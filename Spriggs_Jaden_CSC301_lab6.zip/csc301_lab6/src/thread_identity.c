#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sched.h>
#include <sys/types.h>

typedef struct {
    int logical_index;
    int result_code;
} ThreadArg;

void *worker_entry(void *arg) {
    ThreadArg *targ = (ThreadArg *)arg;

    pid_t pid = getpid();
    pid_t tid = (pid_t)syscall(SYS_gettid);
    pthread_t ptid = pthread_self();
    int cpu = sched_getcpu();

    printf("[Worker %2d] PID: %d | Linux TID (LWP): %d | pthread_t: %lu | CPU: %d\n",
           targ->logical_index, pid, tid, (unsigned long)ptid, cpu);

    /* Return unique index + 100 as worker return code for verification */
    targ->result_code = targ->logical_index + 100;
    return (void *)(intptr_t)targ->result_code;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <num_threads (1-16)>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num_threads = atoi(argv[1]);
    if (num_threads < 1 || num_threads > 16) {
        fprintf(stderr, "Error: Number of threads must be between 1 and 16.\n");
        return EXIT_FAILURE;
    }

    printf("[Main Thread] PID: %d | Linux TID (LWP): %d | pthread_t: %lu | CPU: %d\n",
           getpid(), (pid_t)syscall(SYS_gettid), (unsigned long)pthread_self(), sched_getcpu());

    pthread_t threads[16];
    ThreadArg args[16];
    int threads_created = 0;

    /* 1. Create worker threads */
    for (int i = 0; i < num_threads; i++) {
        args[i].logical_index = i;
        args[i].result_code = 0;

        int rc = pthread_create(&threads[i], NULL, worker_entry, &args[i]);
        if (rc != 0) {
            fprintf(stderr, "Error: pthread_create failed for thread %d with code %d\n", i, rc);
            break;
        }
        threads_created++;
    }

    /* 2. Join every created worker thread (Handles partial failures safely) */
    printf("[Main Thread] Joining %d worker thread(s)...\n", threads_created);
    for (int i = 0; i < threads_created; i++) {
        void *retval;
        int rc = pthread_join(threads[i], &retval);
        if (rc != 0) {
            fprintf(stderr, "Error: pthread_join failed for thread %d\n", i);
        } else {
            int result = (int)(intptr_t)retval;
            printf("[Main Thread] Joined Worker %2d (Returned: %d)\n", i, result);
        }
    }

    if (threads_created != num_threads) {
        fprintf(stderr, "Warning: Only %d of %d requested threads were created and joined.\n",
                threads_created, num_threads);
        return EXIT_FAILURE;
    }

    printf("[Main Thread] All %d threads verified and joined successfully.\n", threads_created);
    return EXIT_SUCCESS;
}
