#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *thread_entry(void *arg) {
    int id = *(int *)arg;
    printf("[Thread %d] Execution started (POSIX Thread ID: %lu)\n", id, (unsigned long)pthread_self());
    return NULL;
}

int main(void) {
    pthread_t thread;
    int thread_id = 1;

    printf("[Main] Creating thread...\n");
    if (pthread_create(&thread, NULL, thread_entry, &thread_id) != 0) {
        perror("pthread_create failed");
        return EXIT_FAILURE;
    }

    if (pthread_join(thread, NULL) != 0) {
        perror("pthread_join failed");
        return EXIT_FAILURE;
    }

    printf("[Main] Thread joined successfully.\n");
    return EXIT_SUCCESS;
}
