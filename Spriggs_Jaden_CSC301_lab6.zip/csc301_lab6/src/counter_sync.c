#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>

typedef enum {
    MODE_UNSAFE,
    MODE_MUTEX,
    MODE_ATOMIC,
    MODE_LOCAL_REDUCE
} SyncMode;

typedef struct {
    long long K;
    SyncMode mode;
    int thread_id;
    long long local_count;
} ThreadArg;

/* Global state */
static long long global_counter = 0;
static _Atomic long long atomic_counter = 0;
static pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;

void *worker_entry(void *arg) {
    ThreadArg *targ = (ThreadArg *)arg;
    long long k = targ->K;

    switch (targ->mode) {
        case MODE_UNSAFE:
            for (long long i = 0; i < k; i++) {
                global_counter++;
            }
            break;

        case MODE_MUTEX:
            for (long long i = 0; i < k; i++) {
                pthread_mutex_lock(&counter_mutex);
                global_counter++;
                pthread_mutex_unlock(&counter_mutex);
            }
            break;

        case MODE_ATOMIC:
            for (long long i = 0; i < k; i++) {
                atomic_fetch_add_explicit(&atomic_counter, 1, memory_order_relaxed);
            }
            break;

        case MODE_LOCAL_REDUCE:
            for (long long i = 0; i < k; i++) {
                targ->local_count++;
            }
            break;
    }
    return NULL;
}

static double get_time_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        fprintf(stderr, "Usage: %s <N_threads> <K_increments> <mode|--mode=mode>\n", argv[0]);
        return EXIT_FAILURE;
    }

    /* Validate Thread Count N */
    char *endptr;
    long N_long = strtol(argv[1], &endptr, 10);
    if (*endptr != '\0' || N_long <= 0 || N_long > 16) {
        fprintf(stderr, "Error: Invalid thread count '%s'. Must be an integer between 1 and 16.\n", argv[1]);
        return EXIT_FAILURE;
    }
    int N = (int)N_long;

    /* Validate Increments K */
    long long K = atoll(argv[2]);
    if (K <= 0) {
        fprintf(stderr, "Error: Invalid increment count '%s'. Must be > 0.\n", argv[2]);
        return EXIT_FAILURE;
    }

    /* Parse Mode String (supports positional or --mode= flag) */
    char *mode_str = argv[3];
    if (strncmp(mode_str, "--mode=", 7) == 0) {
        mode_str += 7;
    } else if (strcmp(mode_str, "--mode") == 0 && argc >= 5) {
        mode_str = argv[4];
    }

    SyncMode mode;
    if (strcmp(mode_str, "unsafe") == 0) {
        mode = MODE_UNSAFE;
    } else if (strcmp(mode_str, "mutex") == 0) {
        mode = MODE_MUTEX;
    } else if (strcmp(mode_str, "atomic") == 0) {
        mode = MODE_ATOMIC;
    } else if (strcmp(mode_str, "local") == 0 || strcmp(mode_str, "local-reduce") == 0) {
        mode = MODE_LOCAL_REDUCE;
    } else {
        fprintf(stderr, "Error: Invalid synchronization mode '%s'\n", mode_str);
        return EXIT_FAILURE;
    }

    /* Reset global counters */
    global_counter = 0;
    atomic_store(&atomic_counter, 0);

    pthread_t threads[16];
    ThreadArg args[16];

    double start_time = get_time_sec();

    for (int i = 0; i < N; i++) {
        args[i].K = K;
        args[i].mode = mode;
        args[i].thread_id = i;
        args[i].local_count = 0;
        pthread_create(&threads[i], NULL, worker_entry, &args[i]);
    }

    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }

    /* Combine results for local reduction strategy */
    if (mode == MODE_LOCAL_REDUCE) {
        for (int i = 0; i < N; i++) {
            global_counter += args[i].local_count;
        }
    }

    double end_time = get_time_sec();
    double elapsed_sec = end_time - start_time;

    long long expected = (long long)N * K;
    long long actual = (mode == MODE_ATOMIC) ? atomic_load(&atomic_counter) : global_counter;

    printf("%s,%d,%lld,%lld,%lld,%d,%.6f\n",
           mode_str, N, K, expected, actual, (expected == actual) ? 1 : 0, elapsed_sec);

    return EXIT_SUCCESS;
}
