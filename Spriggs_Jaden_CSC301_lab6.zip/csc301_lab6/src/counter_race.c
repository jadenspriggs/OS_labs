#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>

static int64_t global_counter = 0;
static bool g_use_yield = false;

typedef struct {
    int iterations;
} ThreadArg;

void *worker_routine(void *arg) {
    ThreadArg *targ = (ThreadArg *)arg;
    for (int i = 0; i < targ->iterations; i++) {
        int64_t temp = global_counter;
        if (g_use_yield) {
            sched_yield();
        }
        global_counter = temp + 1;
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <threads (2-16)> <iters (1000-10000000)> [--yield]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num_threads = atoi(argv[1]);
    int iters_per_thread = atoi(argv[2]);

    if (num_threads < 2 || num_threads > 16 || iters_per_thread < 1000 || iters_per_thread > 10000000) {
        fprintf(stderr, "Error: Invalid bounds. Threads: 2-16, Iters: 1000-10000000.\n");
        return EXIT_FAILURE;
    }

    if (argc >= 4 && strcmp(argv[3], "--yield") == 0) {
        g_use_yield = true;
    }

    int64_t expected = (int64_t)num_threads * iters_per_thread;
    global_counter = 0;

    pthread_t threads[16];
    ThreadArg targ = { .iterations = iters_per_thread };

    struct timespec start_t, end_t;
    clock_gettime(CLOCK_MONOTONIC, &start_t);

    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, worker_routine, &targ);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    clock_gettime(CLOCK_MONOTONIC, &end_t);
    double elapsed_sec = (end_t.tv_sec - start_t.tv_sec) + 
                         (end_t.tv_nsec - start_t.tv_nsec) / 1e9;

    int64_t actual = global_counter;
    int64_t lost = expected - actual;
    double pct_err = ((double)lost / expected) * 100.0;

    /* Ensure directory exists */
    mkdir("output", 0777);

    /* Open file in append mode */
    FILE *f = fopen("output/race_trials.csv", "a");
    if (!f) {
        perror("Error opening output/race_trials.csv");
        return EXIT_FAILURE;
    }

    /* Print CSV header if empty */
    fseek(f, 0, SEEK_END);
    if (ftell(f) == 0) {
        fprintf(f, "N,K,expected,actual,lost,pct_err,elapsed_sec,yield\n");
    }

    /* Write CSV row */
    fprintf(f, "%d,%d,%lld,%lld,%lld,%.2f,%.6f,%d\n",
            num_threads, iters_per_thread, (long long)expected, (long long)actual,
            (long long)lost, pct_err, elapsed_sec, g_use_yield ? 1 : 0);

    /* Explicitly flush and close file buffer */
    fflush(f);
    fclose(f);

    printf("Trial logged | Expected: %lld | Actual: %lld | Lost: %lld (%.2f%%)\n",
           (long long)expected, (long long)actual, (long long)lost, pct_err);

    return EXIT_SUCCESS;
}
