#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

typedef struct {
    int id;
    int payload;
} Item;

typedef struct {
    Item *buffer;
    int capacity;
    int head;
    int tail;
    int count;
    int max_occupancy;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} BoundedBufferCV;

typedef struct {
    int producer_id;
    int n_producers;
    int items_to_produce;
    int total_items;
    BoundedBufferCV *bb;
    unsigned int seed;
} ProducerArg;

typedef struct {
    int consumer_id;
    BoundedBufferCV *bb;
    unsigned int seed;
    long long consumed_count;
    long long consumed_checksum;
    int *consumed_flags;
    int total_items;
    pthread_mutex_t *flags_mutex;
} ConsumerArg;

static BoundedBufferCV g_bb;

static void buffer_init(BoundedBufferCV *bb, int capacity) {
    bb->buffer = malloc(sizeof(Item) * capacity);
    bb->capacity = capacity;
    bb->head = 0;
    bb->tail = 0;
    bb->count = 0;
    bb->max_occupancy = 0;
    pthread_mutex_init(&bb->mutex, NULL);
    pthread_cond_init(&bb->not_empty, NULL);
    pthread_cond_init(&bb->not_full, NULL);
}

static void buffer_destroy(BoundedBufferCV *bb) {
    pthread_mutex_destroy(&bb->mutex);
    pthread_cond_destroy(&bb->not_empty);
    pthread_cond_destroy(&bb->not_full);
    free(bb->buffer);
}

static void buffer_put(BoundedBufferCV *bb, Item item) {
    pthread_mutex_lock(&bb->mutex);

    /* Guard against spurious wakeups using while loop */
    while (bb->count == bb->capacity) {
        pthread_cond_wait(&bb->not_full, &bb->mutex);
    }

    bb->buffer[bb->tail] = item;
    bb->tail = (bb->tail + 1) % bb->capacity;
    bb->count++;
    if (bb->count > bb->max_occupancy) {
        bb->max_occupancy = bb->count;
    }

    /* Signal at least one waiting consumer that buffer is not empty */
    pthread_cond_signal(&bb->not_empty);

    pthread_mutex_unlock(&bb->mutex);
}

static Item buffer_get(BoundedBufferCV *bb) {
    pthread_mutex_lock(&bb->mutex);

    /* Guard against spurious wakeups using while loop */
    while (bb->count == 0) {
        pthread_cond_wait(&bb->not_empty, &bb->mutex);
    }

    Item item = bb->buffer[bb->head];
    bb->head = (bb->head + 1) % bb->capacity;
    bb->count--;

    /* Signal at least one waiting producer that buffer is not full */
    pthread_cond_signal(&bb->not_full);

    pthread_mutex_unlock(&bb->mutex);

    return item;
}

void *producer_worker(void *arg) {
    ProducerArg *parg = (ProducerArg *)arg;
    
    /* Calculate unique starting ID offset for this producer */
    int base_items = parg->total_items / parg->n_producers;
    int remainder = parg->total_items % parg->n_producers;
    int start_id = parg->producer_id * base_items + 
                   (parg->producer_id < remainder ? parg->producer_id : remainder);

    for (int i = 0; i < parg->items_to_produce; i++) {
        int item_id = start_id + i; /* Guaranteed to be strictly < total_items */
        Item item = { .id = item_id, .payload = item_id * 3 };

        if (parg->seed > 0) {
            usleep(rand_r(&parg->seed) % 100);
        }

        buffer_put(parg->bb, item);
    }
    return NULL;
}

void *consumer_worker(void *arg) {
    ConsumerArg *carg = (ConsumerArg *)arg;
    while (1) {
        Item item = buffer_get(carg->bb);

        if (item.id == -1) {
            break;
        }

        if (carg->seed > 0) {
            usleep(rand_r(&carg->seed) % 100);
        }

        carg->consumed_count++;
        carg->consumed_checksum += item.payload;

        if (item.id >= 0 && item.id < carg->total_items) {
            pthread_mutex_lock(carg->flags_mutex);
            carg->consumed_flags[item.id]++;
            pthread_mutex_unlock(carg->flags_mutex);
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 5 || argc > 6) {
        fprintf(stderr, "Usage: %s <num_producers> <num_consumers> <capacity> <total_items> [seed]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int n_producers = atoi(argv[1]);
    int n_consumers = atoi(argv[2]);
    int capacity = atoi(argv[3]);
    int total_items = atoi(argv[4]);
    unsigned int seed = (argc == 6) ? (unsigned int)atoi(argv[5]) : 0;

    /* Validate argument bounds */
    if (n_producers < 1 || n_producers > 16 || n_consumers < 1 || n_consumers > 16 || capacity < 1 || total_items < 1) {
        fprintf(stderr, "Error: Invalid argument ranges.\n");
        return EXIT_FAILURE;
    }

    buffer_init(&g_bb, capacity);

    /* Dynamically allocate arrays to handle any thread counts */
    pthread_t *producers = malloc(sizeof(pthread_t) * n_producers);
    pthread_t *consumers = malloc(sizeof(pthread_t) * n_consumers);
    ProducerArg *pargs = malloc(sizeof(ProducerArg) * n_producers);
    ConsumerArg *cargs = malloc(sizeof(ConsumerArg) * n_consumers);

    int *consumed_flags = calloc(total_items, sizeof(int));
    pthread_mutex_t flags_mutex = PTHREAD_MUTEX_INITIALIZER;


    struct timespec start_t, end_t;
    clock_gettime(CLOCK_MONOTONIC, &start_t);

    for (int i = 0; i < n_consumers; i++) {
        cargs[i].consumer_id = i;
        cargs[i].bb = &g_bb;
        cargs[i].seed = seed ? seed + i + 100 : 0;
        cargs[i].consumed_count = 0;
        cargs[i].consumed_checksum = 0;
        cargs[i].consumed_flags = consumed_flags;
        cargs[i].total_items = total_items;
        cargs[i].flags_mutex = &flags_mutex;
        pthread_create(&consumers[i], NULL, consumer_worker, &cargs[i]);
    }

    int base_items = total_items / n_producers;
    int remainder = total_items % n_producers;

    for (int i = 0; i < n_producers; i++) {
        pargs[i].producer_id = i;
        pargs[i].n_producers = n_producers;                       /* PASS TOTAL PRODUCERS */
        pargs[i].items_to_produce = base_items + (i < remainder ? 1 : 0);
        pargs[i].total_items = total_items;                       /* PASS TOTAL ITEMS */
        pargs[i].bb = &g_bb;
        pargs[i].seed = seed ? seed + i : 0;
        pthread_create(&producers[i], NULL, producer_worker, &pargs[i]);
    }
    for (int i = 0; i < n_producers; i++) {
        pthread_join(producers[i], NULL);
    }

    /* Send termination sentinel item to every consumer */
    for (int i = 0; i < n_consumers; i++) {
        Item sentinel = { .id = -1, .payload = 0 };
        buffer_put(&g_bb, sentinel);
    }

    long long total_consumed = 0;
    long long actual_checksum = 0;
    for (int i = 0; i < n_consumers; i++) {
        pthread_join(consumers[i], NULL);
        total_consumed += cargs[i].consumed_count;
        actual_checksum += cargs[i].consumed_checksum;
    }

    clock_gettime(CLOCK_MONOTONIC, &end_t);
    double elapsed = (end_t.tv_sec - start_t.tv_sec) + (end_t.tv_nsec - start_t.tv_nsec) / 1e9;

    int duplicates = 0, missing = 0;
    for (int i = 0; i < total_items; i++) {
        if (consumed_flags[i] == 0) missing++;
        else if (consumed_flags[i] > 1) duplicates += (consumed_flags[i] - 1);
    }

    printf("CV | P: %d | C: %d | Cap: %d | Consumed: %lld | Dup: %d | Miss: %d | MaxOcc: %d | Time: %.6fs\n",
           n_producers, n_consumers, capacity, total_consumed, duplicates, missing, g_bb.max_occupancy, elapsed);

    /* Free heap memory */
    free(consumed_flags);
    free(producers);
    free(consumers);
    free(pargs);
    free(cargs);

    buffer_destroy(&g_bb);
    pthread_mutex_destroy(&flags_mutex);

    return (duplicates == 0 && missing == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
