#!/usr/bin/env python3
"""
Summarizes results from the Shared Counter Race Experiment (Part 3).
Parses output/race_trials.csv and computes statistical aggregates:
  - Mean/Max/Min actual counter values
  - Mean and Max lost updates (Expected - Actual)
  - Mean percent error
  - Total elapsed execution time and throughput
  - Sched_yield impact analysis (if present)
"""

import os
import sys
import csv
import math
from pathlib import Path

# Paths
PROJECT_ROOT = Path(__file__).parent.parent.resolve()
CSV_PATH = PROJECT_ROOT / "output" / "race_trials.csv"
SUMMARY_PATH = PROJECT_ROOT / "output" / "race_summary.txt"

def analyze_race_trials(csv_file):
    if not csv_file.exists():
        print(f"Error: Output file '{csv_file}' not found.")
        print("Please run your 30 trials first to generate output/race_trials.csv.")
        sys.exit(1)

    trials = []
    with open(csv_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                # Handle flexible header names
                threads = int(row.get("N") or row.get("threads") or row.get("Threads"))
                iters = int(row.get("K") or row.get("iters") or row.get("Iterations"))
                expected = int(row.get("expected") or row.get("Expected"))
                actual = int(row.get("actual") or row.get("Actual"))
                
                lost = expected - actual
                pct_err = (lost / expected) * 100.0 if expected > 0 else 0.0
                
                elapsed = float(row.get("elapsed_sec") or row.get("time_sec") or row.get("Elapsed") or 0.0)
                yield_flag = int(row.get("yield") or row.get("sched_yield") or 0)

                trials.append({
                    "threads": threads,
                    "iters": iters,
                    "expected": expected,
                    "actual": actual,
                    "lost": lost,
                    "pct_err": pct_err,
                    "elapsed": elapsed,
                    "yield": yield_flag
                })
            except (ValueError, KeyError) as e:
                continue

    if not trials:
        print(f"Error: No valid data rows found in '{csv_file}'.")
        sys.exit(1)

    total_trials = len(trials)
    expected_val = trials[0]["expected"]
    threads = trials[0]["threads"]
    iters = trials[0]["iters"]

    actual_vals = [t["actual"] for t in trials]
    lost_vals = [t["lost"] for t in trials]
    pct_errors = [t["pct_err"] for t in trials]
    elapsed_times = [t["elapsed"] for t in trials]

    mean_actual = sum(actual_vals) / total_trials
    min_actual = min(actual_vals)
    max_actual = max(actual_vals)

    mean_lost = sum(lost_vals) / total_trials
    max_lost = max(lost_vals)
    min_lost = min(lost_vals)

    mean_pct_err = sum(pct_errors) / total_trials
    max_pct_err = max(pct_errors)

    mean_elapsed = sum(elapsed_times) / total_trials if elapsed_times else 0.0

    # Yield comparison breakdown (if mix of yield=0 and yield=1 exist)
    no_yield_lost = [t["lost"] for t in trials if t["yield"] == 0]
    yield_lost = [t["lost"] for t in trials if t["yield"] == 1]

    # Generate Terminal & File Output
    summary_lines = []
    summary_lines.append("====================================================")
    summary_lines.append("   SHARED COUNTER RACE EXPERIMENT SUMMARY (PART 3)   ")
    summary_lines.append("====================================================")
    summary_lines.append(f" Configuration       : N = {threads} Threads, K = {iters:,} Iters/Thread")
    summary_lines.append(f" Total Trials Run    : {total_trials}")
    summary_lines.append(f" Expected Count      : {expected_val:,}")
    summary_lines.append("----------------------------------------------------")
    summary_lines.append(f" Actual Count (Mean) : {mean_actual:,.2f}")
    summary_lines.append(f" Actual Count (Range): [{min_actual:,} - {max_actual:,}]")
    summary_lines.append("----------------------------------------------------")
    summary_lines.append(f" Lost Updates (Mean) : {mean_lost:,.2f}")
    summary_lines.append(f" Lost Updates (Max)  : {max_lost:,}")
    summary_lines.append(f" Mean Percent Error  : {mean_pct_err:.2f}% (Max: {max_pct_err:.2f}%)")
    summary_lines.append(f" Mean Time Per Trial : {mean_elapsed:.6f}s")
    summary_lines.append("----------------------------------------------------")

    if no_yield_lost and yield_lost:
        avg_no_yield = sum(no_yield_lost) / len(no_yield_lost)
        avg_yield = sum(yield_lost) / len(yield_lost)
        summary_lines.append(" SCHED_YIELD IMPACT ANALYSIS:")
        summary_lines.append(f"   - Standard Mean Lost Updates : {avg_no_yield:,.2f}")
        summary_lines.append(f"   - Yield Mode Mean Lost Updates: {avg_yield:,.2f}")
        summary_lines.append(f"   - Interleaving Increase Factor: {avg_yield / avg_no_yield:.2f}x")
        summary_lines.append("----------------------------------------------------")

    # Race Evidence Verdict
    if mean_lost > 0:
        summary_lines.append(" VERDICT: RACE EVIDENCE CONFIRMED")
        summary_lines.append(f"   Overwhelming lost updates observed across all {total_trials} trials.")
        summary_lines.append("   Demonstrates non-atomic read-modify-write interleaving.")
    else:
        summary_lines.append(" VERDICT: NO RACE DETECTED (CHECK IMPLEMENTATION)")

    summary_lines.append("====================================================\n")

    full_summary = "\n".join(summary_lines)
    print(full_summary)

    # Save summary report to output/race_summary.txt
    SUMMARY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(SUMMARY_PATH, "w") as f:
        f.write(full_summary)
    
    print(f"Summary saved to {SUMMARY_PATH}")

if __name__ == "__main__":
    analyze_race_trials(CSV_PATH)
