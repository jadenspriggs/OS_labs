#!/usr/bin/env python3
"""
Comprehensive Automated Test Suite for POSIX Threads & Synchronization
Covers:
  - Input Validation (missing, nonnumeric, zero, negative, out-of-bound args)
  - Thread Lifecycle (1, 2, 8, 16 threads & join verification)
  - Race Evidence (Unsafe vs Mutex vs Atomic vs Thread-Local)
  - Bounded Buffer Invariants (capacities 1 & 64, unequal prod/cons)
  - Readers-Writers (read-heavy, write-heavy, invariant integrity)
  - POSIX Barriers (array smaller than threads, uneven division)
  - Deadlock & Prevention (unsafe timeout verification, ordered & trylock safety)
  - AddressSanitizer/UBSan & ThreadSanitizer / Helgrind integration
  - 50 Bounded Randomized Stress Tests with recorded seeds
"""

import os
import sys
import subprocess
import shutil
import random
import time
from pathlib import Path

# Base Directories
PROJECT_ROOT = Path(__file__).parent.parent.resolve()
SRC_DIR = PROJECT_ROOT / "src"
BIN_DIR = PROJECT_ROOT / "bin"
OUTPUT_DIR = PROJECT_ROOT / "output"

RESULTS_FILE = OUTPUT_DIR / "test_results.txt"
LOG_FILE = OUTPUT_DIR / "test_diagnostics.log"

# Test Tracker Stats
tests_run = 0
tests_passed = 0
tests_failed = 0

def setup_environment():
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(RESULTS_FILE, "w") as f:
        f.write("=== LAB 6 AUTOMATED TEST RESULTS ===\n\n")
    with open(LOG_FILE, "w") as f:
        f.write("=== DETAILED DIAGNOSTIC LOGS ===\n\n")

def log(msg, console=True):
    with open(RESULTS_FILE, "a") as f:
        f.write(msg + "\n")
    if console:
        print(msg)

def log_diag(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

def run_command(cmd, timeout_sec=10, check_returncode=True, capture_output=True):
    log_diag(f"EXEC: {' '.join(cmd)}")
    try:
        res = subprocess.run(
            cmd,
            stdout=subprocess.PIPE if capture_output else None,
            stderr=subprocess.PIPE if capture_output else None,
            text=True,
            timeout=timeout_sec
        )
        log_diag(f"EXIT CODE: {res.returncode}")
        if capture_output:
            if res.stdout: log_diag(f"STDOUT:\n{res.stdout}")
            if res.stderr: log_diag(f"STDERR:\n{res.stderr}")
        if check_returncode and res.returncode != 0:
            return False, res.stdout or "", res.stderr or "", res.returncode
        return True, res.stdout or "", res.stderr or "", res.returncode
    except subprocess.TimeoutExpired:
        log_diag(f"TIMEOUT EXPIRED after {timeout_sec}s")
        return False, "", "TIMEOUT", 124

def record_test_result(name, passed, detail=""):
    global tests_run, tests_passed, tests_failed
    tests_run += 1
    if passed:
        tests_passed += 1
        log(f"  [PASS] {name}")
    else:
        tests_failed += 1
        log(f"  [FAIL] {name} - {detail}")

def check_compiler_sanitizers():
    has_asan = False
    has_tsan = False

    cmd = ["gcc", "-fsanitize=address,undefined", "-x", "c", "-", "-o", "/dev/null"]
    try:
        p = subprocess.run(cmd, input="int main(){return 0;}", text=True, capture_output=True)
        if p.returncode == 0:
            has_asan = True
    except Exception:
        pass

    cmd = ["gcc", "-fsanitize=thread", "-x", "c", "-", "-o", "/dev/null"]
    try:
        p = subprocess.run(cmd, input="int main(){return 0;}", text=True, capture_output=True)
        if p.returncode == 0:
            has_tsan = True
    except Exception:
        pass

    has_helgrind = shutil.which("valgrind") is not None
    return has_asan, has_tsan, has_helgrind

def compile_binaries(flags=None, bin_suffix=""):
    log_diag(f"Building binaries with flags: {flags} (suffix: '{bin_suffix}')")
    compile_cmd = ["make", "clean"]
    run_command(compile_cmd, check_returncode=False)
    
    make_cmd = ["make", "all"]
    if flags:
        make_cmd.append(f"CFLAGS=-std=c11 -Wall -Wextra -pthread {flags}")
    
    ok, stdout, stderr, code = run_command(make_cmd, timeout_sec=30, check_returncode=False)
    if not ok:
        log(f"Build Failed! Error output:\n{stderr}")
        return False
    
    if bin_suffix:
        for b in BIN_DIR.glob("*"):
            if not b.name.endswith(bin_suffix):
                shutil.copy(b, BIN_DIR / f"{b.name}{bin_suffix}")
    return True

# --- TEST SUITES ---

def test_input_validation():
    log("\n--- Category 1: Input Validation ---")
    
    bin_path = BIN_DIR / "counter_sync"
    if not bin_path.exists():
        record_test_result("Input Validation - Binary presence", False, "counter_sync binary missing")
        return

    invalid_cases = [
        ("Missing arguments", []),
        ("Non-numeric threads", ["abc", "1000", "unsafe"]),
        ("Zero threads", ["0", "1000", "unsafe"]),
        ("Negative threads", ["-4", "1000", "unsafe"]),
        ("Above limit threads", ["128", "1000", "unsafe"]),
        ("Invalid strategy", ["4", "1000", "unknown_mode"])
    ]

    for name, args in invalid_cases:
        ok, stdout, stderr, code = run_command([str(bin_path)] + args, check_returncode=False)
        passed = (code != 0)
        record_test_result(f"Input Validation: {name}", passed, f"Expected non-zero exit, got {code}")

def test_thread_lifecycle():
    log("\n--- Category 2: Thread Lifecycle ---")
    bin_path = BIN_DIR / "counter_sync"

    for threads in [1, 2, 8, 16]:
        cmd = [str(bin_path), str(threads), "50000", "mutex"]
        ok, stdout, stderr, code = run_command(cmd)
        # Check that return code is 0 and output contains CSV metrics or successful execution logs
        passed = ok and (code == 0) and ("mutex" in stdout or "Final" in stdout)
        record_test_result(f"Lifecycle ({threads} threads)", passed, stderr)

def test_race_evidence():
    log("\n--- Category 3: Race Evidence & Verification ---")
    bin_path = BIN_DIR / "counter_sync"

    ok, stdout, stderr, code = run_command([str(bin_path), "4", "200000", "unsafe"])
    passed_unsafe = ok and (code == 0)
    record_test_result("Race Evidence (Unsafe trial completion)", passed_unsafe, stderr)

    for strat in ["mutex", "atomic", "local"]:
        ok, stdout, stderr, code = run_command([str(bin_path), "4", "200000", strat])
        correct = False
        if ok and code == 0:
            for line in stdout.splitlines():
                if "800000" in line or ",1," in line or line.endswith(",1"):
                    correct = True
                    break
        record_test_result(f"Race Evidence Correctness ({strat})", correct, "Counter total mismatched")

def test_buffer_invariants():
    log("\n--- Category 4: Bounded Buffer Invariants ---")
    bin_path = BIN_DIR / "producer_consumer_cv"
    if not bin_path.exists():
        record_test_result("Bounded Buffer", False, "producer_consumer_cv missing")
        return

    cases = [
        ("Capacity 1 (1 Prod, 1 Cons)", ["1", "1", "1", "10000", "42"]),
        ("Capacity 64 (4 Prod, 2 Cons)", ["4", "2", "64", "20000", "101"]),
        ("Capacity 64 (2 Prod, 8 Cons)", ["2", "8", "64", "20000", "202"]),
    ]

    for name, args in cases:
        ok, stdout, stderr, code = run_command([str(bin_path)] + args)
        # Accept "Dup: 0 | Miss: 0" or exit status 0
        passed = ok and (code == 0) and ("Dup: 0 | Miss: 0" in stdout or "PASSED" in stdout or "Verification PASSED" in stdout)
        record_test_result(f"Buffer Invariants: {name}", passed, stderr)

def test_readers_writers():
    log("\n--- Category 5: Readers-Writers Lock Invariants ---")
    bin_path = BIN_DIR / "rwlock_benchmark"
    if not bin_path.exists():
        record_test_result("Readers-Writers", False, "rwlock_benchmark missing")
        return

    cases = [
        ("Read-heavy workload", ["--readers", "8", "--writers", "1", "--seconds", "1", "--seed", "42"]),
        ("Write-heavy workload", ["--readers", "2", "--writers", "3", "--seconds", "1", "--seed", "42"])
    ]

    for name, args in cases:
        ok, stdout, stderr, code = run_command([str(bin_path)] + args, check_returncode=False)
        passed = ok and (code == 0)
        record_test_result(f"Readers-Writers: {name}", passed, stderr)

def test_barriers():
    log("\n--- Category 6: POSIX Barrier Synchronizations ---")
    bin_path = BIN_DIR / "parallel_stats"
    if not bin_path.exists():
        record_test_result("Barriers", False, "parallel_stats missing")
        return

    cases = [
        ("Array smaller than threads (N=2, T=8)", ["--threads", "8", "--elements", "2", "--seed", "50"]),
        ("Uneven partition division (N=1000001, T=3)", ["--threads", "3", "--elements", "1000001", "--seed", "50"])
    ]

    for name, args in cases:
        ok, stdout, stderr, code = run_command([str(bin_path)] + args)
        passed = ok and (code == 0)
        record_test_result(f"Barrier: {name}", passed, stderr)

def test_deadlock_and_prevention():
    log("\n--- Category 7: Controlled Deadlock & Prevention ---")
    bin_path = BIN_DIR / "deadlock_demo"
    if not bin_path.exists():
        record_test_result("Deadlock", False, "deadlock_demo missing")
        return

    ok, stdout, stderr, code = run_command([str(bin_path), "--mode", "unsafe"], timeout_sec=3, check_returncode=False)
    timeout_passed = (code == 124)
    record_test_result("Deadlock: Unsafe mode times out (Code 124)", timeout_passed, f"Got exit code {code}")

    ok, stdout, stderr, code = run_command([str(bin_path), "--mode", "ordered"], timeout_sec=5)
    record_test_result("Deadlock Prevention: Ordered mode completes", ok, stderr)

    ok, stdout, stderr, code = run_command([str(bin_path), "--mode", "trylock"], timeout_sec=5)
    record_test_result("Deadlock Prevention: Trylock mode completes", ok, stderr)

def test_randomized_stress_suite(num_trials=50):
    log(f"\n--- Category 8: Bounded Randomized Stress Suite ({num_trials} Trials) ---")
    
    bins = {
        "counter": BIN_DIR / "counter_sync",
        "buffer": BIN_DIR / "producer_consumer_cv",
        "stats": BIN_DIR / "parallel_stats"
    }

    master_seed = 30102026
    random.seed(master_seed)
    log_diag(f"Starting Stress Suite with Master Seed: {master_seed}")

    stress_passed = 0
    for i in range(1, num_trials + 1):
        case_seed = random.randint(1, 1000000)
        target = random.choice(["counter", "buffer", "stats"])

        if target == "counter":
            threads = random.choice([1, 2, 4, 8, 12])
            iters = random.randint(10000, 100000)
            strat = random.choice(["mutex", "atomic", "local"])
            cmd = [str(bins["counter"]), str(threads), str(iters), strat]
        elif target == "buffer":
            p = random.randint(1, 4)
            c = random.randint(1, 4)
            cap = random.choice([1, 8, 32, 64])
            items = random.randint(5000, 20000)
            cmd = [str(bins["buffer"]), str(p), str(c), str(cap), str(items), str(case_seed)]
        else:
            t = random.randint(1, 8)
            n = random.randint(100, 500000)
            cmd = [str(bins["stats"]), "--threads", str(t), "--elements", str(n), "--seed", str(case_seed)]

        ok, stdout, stderr, code = run_command(cmd, timeout_sec=8)
        if ok and (code == 0):
            stress_passed += 1
        else:
            log_diag(f"Stress Trial #{i} FAILED. Cmd: {' '.join(cmd)}")

    record_test_result(f"Randomized Stress Suite ({stress_passed}/{num_trials} passed)", stress_passed == num_trials)

# --- MAIN RUNNER ---

def main():
    setup_environment()
    log("====================================================")
    log("  LAB 6: POSIX THREADS & SYNCHRONIZATION TEST RUNNER")
    log("====================================================\n")

    has_asan, has_tsan, has_helgrind = check_compiler_sanitizers()
    log(f"Sanitizer Capability Detection:")
    log(f"  - AddressSanitizer/UBSan: {'AVAILABLE' if has_asan else 'NOT SUPPORTED'}")
    log(f"  - ThreadSanitizer:        {'AVAILABLE' if has_tsan else 'NOT SUPPORTED'}")
    log(f"  - Valgrind Helgrind:      {'AVAILABLE' if has_helgrind else 'NOT SUPPORTED'}\n")

    log(">>> Stage 1: Building with Address/UndefinedSanitizer...")
    asan_flags = "-fsanitize=address,undefined" if has_asan else ""
    if not compile_binaries(flags=asan_flags):
        sys.exit(1)

    log("\n>>> Executing Standard and Memory Safety Test Suites...")
    test_input_validation()
    test_thread_lifecycle()
    test_race_evidence()
    test_buffer_invariants()
    test_readers_writers()
    test_barriers()
    test_deadlock_and_prevention()

    log("\n>>> Stage 2: Race Detection Build & Execution...")
    if has_tsan:
        log("Compiling dedicated ThreadSanitizer build (-fsanitize=thread)...")
        if compile_binaries(flags="-fsanitize=thread"):
            log("Running race-sensitive tests under ThreadSanitizer...")
            test_buffer_invariants()
            test_barriers()
    elif has_helgrind:
        log("ThreadSanitizer unavailable. Running binaries under Valgrind Helgrind...")
        bin_path = BIN_DIR / "parallel_stats"
        if bin_path.exists():
            cmd = ["valgrind", "--tool=helgrind", str(bin_path), "--threads", "4", "--elements", "10000"]
            ok, stdout, stderr, code = run_command(cmd, timeout_sec=20)
            record_test_result("Valgrind Helgrind Analysis", ok, stderr)
    else:
        log("DOCUMENTED LIMITATION: Neither ThreadSanitizer nor Helgrind available.")
        log("Executing reinforced repeated invariant tests to ensure correctness...")
        test_race_evidence()

    log("\n>>> Stage 3: Executing 50-Case Randomized Stress Suite...")
    compile_binaries()
    test_randomized_stress_suite(num_trials=50)

    log("\n====================================================")
    log(f"FINAL SUMMARY: {tests_passed}/{tests_run} TESTS PASSED")
    log("====================================================")
    
    if tests_failed > 0:
        log(f"\nTEST SUITE FAILED with {tests_failed} failures. See {LOG_FILE} for details.")
        sys.exit(1)
    else:
        log("\nALL TEST SUITES COMPLETED SUCCESSFULLY!")
        sys.exit(0)

if __name__ == "__main__":
    main()
