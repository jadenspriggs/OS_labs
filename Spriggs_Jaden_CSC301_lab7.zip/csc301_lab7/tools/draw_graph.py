#!/usr/bin/env python3
import sys
import csv
from pathlib import Path

def draw_native_svg(csv_path, output_svg_path):
    if not Path(csv_path).exists():
        print(f"Error: {csv_path} not found.")
        sys.exit(1)

    nodes = {}
    edges = []

    with open(csv_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or row[0].startswith('#'):
                continue
            src, src_type, tgt, tgt_type, edge_type, label = [x.strip() for x in row]
            nodes[src] = src_type
            nodes[tgt] = tgt_type
            edges.append((src, tgt, edge_type, label))

    # Calculate layout positions
    pos = {}
    p_idx, r_idx = 0, 0
    for node, ntype in nodes.items():
        if ntype == "Process":
            pos[node] = (120, 100 + p_idx * 120)
            p_idx += 1
        else:
            pos[node] = (380, 100 + r_idx * 120)
            r_idx += 1

    svg_width = 550
    svg_height = max(300, max(p_idx, r_idx) * 140)

    svg = [
        f'<svg width="{svg_width}" height="{svg_height}" xmlns="http://www.w3.org/2000/svg">',
        '  <defs>',
        '    <marker id="arrow" viewBox="0 0 10 10" refX="22" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">',
        '      <path d="M 0 0 L 10 5 L 0 10 z" fill="#333" />',
        '    </marker>',
        '  </defs>',
        '  <rect width="100%" height="100%" fill="#fafafa" />'
    ]

    # Draw edges
    for src, tgt, edge_type, label in edges:
        x1, y1 = pos[src]
        x2, y2 = pos[tgt]
        dash = 'stroke-dasharray="5,5"' if edge_type == "Request" else ''
        svg.append(f'  <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#333" stroke-width="2" {dash} marker-end="url(#arrow)" />')

    # Draw nodes
    for node, ntype in nodes.items():
        x, y = pos[node]
        if ntype == "Process":
            svg.append(f'  <circle cx="{x}" cy="{y}" r="30" fill="#add8e6" stroke="#333" stroke-width="2" />')
        else:
            svg.append(f'  <rect x="{x-30}" y="{y-25}" width="60" height="50" fill="#d3d3d3" stroke="#333" stroke-width="2" rx="4" />')
        svg.append(f'  <text x="{x}" y="{y+5}" font-family="sans-serif" font-size="14" font-weight="bold" text-anchor="middle">{node}</text>')

    svg.append('</svg>')

    Path(output_svg_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_svg_path, 'w') as f:
        f.write('\n'.join(svg))

    print(f"Native SVG generated at '{output_svg_path}'.")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 tools/draw_graph.py <input_csv> <output_svg>")
        sys.exit(1)
    draw_native_svg(sys.argv[1], sys.argv[2])
