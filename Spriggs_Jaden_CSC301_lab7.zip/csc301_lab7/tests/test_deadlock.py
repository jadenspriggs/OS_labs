#!/usr/bin/env python3
"""
Lab 7 - Part 10: Comprehensive Test Suite & Fault Injection Harness
Verifies parser edge cases, safety, request evaluation, detection, graph export,
recovery policies, live timeout behavior, and includes a stress oracle generator.
"""

import os
import sys
import subprocess
import random
import time
import glob
import re

BINARY = "./bin/deadlock_tool"
SCENARIO_DIR = "tests/temp_scenarios"
REPLAY_FILE = "tests/failed_stress_scenario.txt"
FIXED_SEED = 42

os.makedirs(SCENARIO_DIR, exist_ok=True)

# Test Tracker
pass_count = 0
fail_count = 0

def run_cmd(cmd_args, timeout_sec=5):
    """Executes C binary with timeout, returns stdout, stderr, returncode."""
    try:
        res = subprocess.run(
            cmd_args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_sec
        )
        return res.stdout, res.stderr, res.returncode
    except subprocess.TimeoutExpired:
        return "", "TIMEOUT EXPIRED", -1

def assert_test(test_name, expected_desc, actual_desc, condition):
    """Prints uniform test status and updates counters."""
    global pass_count, fail_count
    if condition:
        print(f"[PASS] {test_name}")
        print(f"       Expected: {expected_desc}")
        print(f"       Actual  : {actual_desc}\n")
        pass_count += 1
        return True
    else:
        print(f"[FAIL] {test_name}")
        print(f"       Expected: {expected_desc}")
        print(f"       Actual  : {actual_desc}\n")
        fail_count += 1
        return False

def create_temp_file(filename, content):
    path = os.path.join(SCENARIO_DIR, filename)
    with open(path, "w") as f:
        f.write(content.strip())
    return path

# ==============================================================================
# TEST CLASSES
# ==============================================================================

def test_parser():
    print("--- 1. Parser Error Validation Tests ---")
    
    # Missing Dimension
    p1 = create_temp_file("p_missing_dim.txt", "AVAILABLE 3 3\nPROCESS P0 ALLOC 1 0 0 MAX 2 2 2")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p1])
    assert_test("Parser: Dimension Mismatch", "Rejection or Error Code", f"Exit {code}", code != 0 or "Error" in err or "Error" in out)

    # Negative Value
    p2 = create_temp_file("p_negative.txt", "AVAILABLE 3 3 2\nPROCESS P0 ALLOC -1 0 0 MAX 2 2 2")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p2])
    assert_test("Parser: Negative Value Handling", "Error on negative values", f"Exit {code}", code != 0 or "Error" in err or "Error" in out)

    # Allocation > Maximum
    p3 = create_temp_file("p_alloc_gt_max.txt", "AVAILABLE 3 3 2\nPROCESS P0 ALLOC 5 5 5 MAX 2 2 2")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p3])
    assert_test("Parser: Allocation > Maximum Validation", "Parser failure or validation error", f"Exit {code}", code != 0 or "Error" in err or "Error" in out)

def test_safety():
    print("--- 2. Banker's Safety Algorithm Tests ---")

    # Safe State
    p_safe = create_temp_file("s_safe.txt", """
AVAILABLE 3 3 2
PROCESS P0 ALLOC 0 1 0 MAX 7 5 3
PROCESS P1 ALLOC 2 0 0 MAX 3 2 2
PROCESS P2 ALLOC 3 0 2 MAX 9 0 2
PROCESS P3 ALLOC 2 1 1 MAX 2 2 2
PROCESS P4 ALLOC 0 0 2 MAX 4 3 3
""")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p_safe])
    assert_test("Safety: Safe State Detection", "SAFE STATE result", f"Exit {code}", code == 0 and "SAFE STATE" in out)

    # Unsafe State
    p_unsafe = create_temp_file("s_unsafe.txt", """
AVAILABLE 0 2 0
PROCESS P0 ALLOC 0 1 0 MAX 7 5 3
PROCESS P1 ALLOC 2 0 0 MAX 3 2 2
PROCESS P2 ALLOC 3 0 2 MAX 9 0 2
""")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p_unsafe])
    assert_test("Safety: Unsafe State Detection", "UNSAFE STATE DETECTED", f"Exit {code}", code == 0 and "UNSAFE STATE DETECTED" in out)

    # Zero Allocation Process
    p_zero = create_temp_file("s_zero_alloc.txt", """
AVAILABLE 1 1 1
PROCESS P0 ALLOC 0 0 0 MAX 1 1 1
""")
    out, err, code = run_cmd([BINARY, "bankers", "--input", p_zero])
    assert_test("Safety: Zero-Allocation Process", "SAFE STATE execution", f"Exit {code}", code == 0 and "SAFE STATE" in out)

def test_request():
    print("--- 3. Banker's Resource-Request Tests ---")

    # Base scenario where P1's request is valid and safe
    p_base = create_temp_file("r_base.txt", """
AVAILABLE 3 3 2
PROCESS P0 ALLOC 0 1 0 MAX 4 3 2
PROCESS P1 ALLOC 2 0 0 MAX 3 2 2
""")
    # 1. Grant (Valid & Safe)
    out, err, code = run_cmd([BINARY, "request", "--input", p_base, "--process", "P1", "--request", "1,0,2"])
    assert_test("Request: Valid & Safe Grant", "REQUEST GRANTED", f"Exit {code}", code == 0 and "REQUEST GRANTED" in out)

    # 2. Exceeds Need
    out, err, code = run_cmd([BINARY, "request", "--input", p_base, "--process", "P1", "--request", "2,2,2"])
    assert_test("Request: Exceeds Need Rejection", "REJECTED (INVALID CLAIM)", f"Exit {code}", code == 0 and "INVALID CLAIM" in out)

    # Base scenario for Exceeds Available (P0 MAX must be at least ALLOC + REQUEST = 0 + 5 = 5)
    p_wait = create_temp_file("r_wait.txt", """
AVAILABLE 3 3 2
PROCESS P0 ALLOC 0 1 0 MAX 7 5 3
PROCESS P1 ALLOC 2 0 0 MAX 3 2 2
""")
    # 3. Exceeds Available (Wait)
    out, err, code = run_cmd([BINARY, "request", "--input", p_wait, "--process", "P0", "--request", "5,0,0"])
    assert_test("Request: Exceeds Available (Wait)", "RESOURCES UNAVAILABLE", f"Exit {code}", code == 0 and "UNAVAILABLE" in out)

def test_detection():
    print("--- 4. Multi-Instance Deadlock Detection Tests ---")

    p_det = create_temp_file("d_detected.txt", """
AVAILABLE 0 0 0
PROCESS P0 ALLOC 0 1 0 REQUEST 0 0 0
PROCESS P1 ALLOC 2 0 0 REQUEST 2 0 2
PROCESS P2 ALLOC 3 0 3 REQUEST 0 0 1
PROCESS P3 ALLOC 2 1 1 REQUEST 1 0 0
PROCESS P4 ALLOC 0 0 2 REQUEST 0 0 2
""")
    out, err, code = run_cmd([BINARY, "detect", "--input", p_det])
    has_deadlock = "DEADLOCK DETECTED" in out
    has_exact_set = all(proc in out for proc in ["P1", "P2", "P3", "P4"])
    assert_test("Detection: Exact Deadlocked Set Match", "DEADLOCK DETECTED {P1, P2, P3, P4}", f"Exit {code}", code == 0 and has_deadlock and has_exact_set)

def test_graphs():
    print("--- 5. RAG / WFG Graph Projections ---")
    p_graph = create_temp_file("g_test.txt", """
RESOURCE R1 1
RESOURCE R2 1
PROCESS P1
PROCESS P2
REQUEST P1 R1
ASSIGN R1 P2
REQUEST P2 R2
ASSIGN R2 P1
""")
    csv_out = os.path.join(SCENARIO_DIR, "out.csv")
    out, err, code = run_cmd([BINARY, "graph", "--input", p_graph, "--output", csv_out])
    assert_test("Graphs: RAG Export with Cycle Detection", "CSV Exported with Cycle: TRUE", f"Exit {code}", code == 0 and os.path.exists(csv_out))

def test_recovery():
    print("--- 6. Recovery Simulator Policy Tests ---")
    p_rec = create_temp_file("rec_test.txt", """
AVAILABLE 0 0 0
PROCESS P0 ALLOC 1 0 0 REQUEST 0 1 0 PRIORITY 1 COST 10
PROCESS P1 ALLOC 0 1 0 REQUEST 1 0 0 PRIORITY 3 COST 50
""")
    policies = ["terminate-one", "terminate-all", "cost-aware"]
    for pol in policies:
        out, err, code = run_cmd([BINARY, "recover", "--input", p_rec, "--policy", pol])
        success = "RECOVERY COMPLETE" in out and "Total Recovery Cost Metric:" in out
        assert_test(f"Recovery: Policy '{pol}' Progress & Completion", "RECOVERY COMPLETE with cost metric", f"Exit {code}", code == 0 and success)

def test_live_timeout():
    print("--- 7. Live Deadlock Execution & Timeout Test ---")
    # Execute cycle mode with a 2 second timeout using OS timeout tool
    out, err, code = run_cmd(["timeout", "2", BINARY, "cycle"], timeout_sec=4)
    # Timeout exit code from coreutils is 124
    assert_test("Live Execution: Cycle Times Out Safely", "Killed by timeout (Exit 124)", f"Exit code {code}", code == 124 or code == -1)

# ==============================================================================
# STRESS ORACLE GENERATOR (100 BOUNDED RANDOM STATES)
# ==============================================================================

def python_bankers_oracle(alloc, max_m, avail, num_p, num_r):
    """Independent Python implementation of Banker's Safety Algorithm."""
    need = [[max_m[i][j] - alloc[i][j] for j in range(num_r)] for i in range(num_p)]
    work = list(avail)
    finish = [False] * num_p

    while True:
        found = False
        for i in range(num_p):
            if not finish[i]:
                if all(need[i][j] <= work[j] for j in range(num_r)):
                    for j in range(num_r):
                        work[j] += alloc[i][j]
                    finish[i] = True
                    found = True
                    break
        if not found:
            break

    return all(finish)

def run_stress_test(count=100):
    print(f"--- 8. Stress Oracle Generator ({count} Bounded Random States) ---")
    random.seed(FIXED_SEED)
    stress_passed = 0

    for idx in range(count):
        num_p = random.randint(2, 6)
        num_r = random.randint(2, 5)
        avail = [random.randint(0, 5) for _ in range(num_r)]
        
        alloc = []
        max_m = []
        for i in range(num_p):
            a_row = [random.randint(0, 3) for _ in range(num_r)]
            m_row = [a_row[j] + random.randint(0, 4) for j in range(num_r)]
            alloc.append(a_row)
            max_m.append(m_row)

        # Build Scenario File
        file_lines = [f"AVAILABLE {' '.join(map(str, avail))}"]
        for i in range(num_p):
            a_str = ' '.join(map(str, alloc[i]))
            m_str = ' '.join(map(str, max_m[i]))
            file_lines.append(f"PROCESS P{i} ALLOC {a_str} MAX {m_str}")
        
        scenario_path = create_temp_file(f"stress_{idx}.txt", '\n'.join(file_lines))

        # Expected Oracle Result
        expected_safe = python_bankers_oracle(alloc, max_m, avail, num_p, num_r)

        # C Executable Output
        out, err, code = run_cmd([BINARY, "bankers", "--input", scenario_path])
        c_safe = ("SYSTEM RESULT: SAFE STATE" in out)

        if expected_safe == c_safe and code == 0:
            stress_passed += 1
        else:
            print(f"STRESS FAILURE at Iteration {idx}!")
            print(f"Oracle Safe: {expected_safe} | C Executable Safe: {c_safe}")
            # Save for replay
            with open(REPLAY_FILE, "w") as rf:
                rf.write('\n'.join(file_lines))
            print(f"Failed scenario saved to '{REPLAY_FILE}'.")
            assert_test("Stress Oracle Test", "Oracle and C Executable Match", "Mismatch detected", False)
            return

    assert_test(f"Stress Oracle Verification ({count} runs)", f"100% match with independent oracle", f"{stress_passed}/{count} matched", stress_passed == count)

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

if __name__ == "__main__":
    print("======================================================================")
    print("=== STARTING LAB 7 AUTOMATED TEST SUITE & FAULT INJECTION HARNESS ===")
    print("======================================================================\n")

    # Check binary existence
    if not os.path.exists(BINARY):
        print(f"Error: Binary '{BINARY}' not found. Please compile the project first.")
        sys.exit(1)

    test_parser()
    test_safety()
    test_request()
    test_detection()
    test_graphs()
    test_recovery()
    test_live_timeout()
    run_stress_test(100)

    print("======================================================================")
    print(f"FINAL SUMMARY: {pass_count} PASSED | {fail_count} FAILED")
    print("======================================================================")

    sys.exit(0 if fail_count == 0 else 1)
