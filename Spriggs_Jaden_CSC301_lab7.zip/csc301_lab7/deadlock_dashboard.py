#!/usr/bin/env python3
"""
Deadlock Analysis Dashboard (Offline Local Interface)
Wraps the student-written C analysis engine (`bin/deadlock_tool`).
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime

BINARY = "./bin/deadlock_tool"
OUTPUT_DIR = "dashboard_exports"

os.makedirs(OUTPUT_DIR, exist_ok=True)

class DeadlockDashboard:
    def __init__(self, scenario_file):
        self.scenario_file = scenario_file
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.results = {}

    def validate_file(self):
        """Validates that the scenario file exists and is readable."""
        if not os.path.exists(self.scenario_file):
            sys.stderr.write(f"Error: Scenario file '{self.scenario_file}' does not exist.\n")
            return False
        if not os.path.isfile(self.scenario_file):
            sys.stderr.write(f"Error: Path '{self.scenario_file}' is not a valid file.\n")
            return False
        return True

    def run_command(self, args):
        cmd = [BINARY] + args
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return res.stdout, res.stderr, res.returncode
        except Exception as e:
            return "", str(e), -1

    def analyze_all(self):
        print(f"\n=======================================================")
        print(f"=== DEADLOCK ANALYSIS DASHBOARD - LOCAL OFFLINE UI ===")
        print(f"=======================================================")
        print(f"Target Scenario: {self.scenario_file}\n")

        # 1. Banker's Safety & Need Calculation
        out_b, err_b, code_b = self.run_command(["bankers", "--input", self.scenario_file])
        self.results['bankers'] = out_b

        # 2. Multi-Instance Detection
        out_d, err_d, code_d = self.run_command(["detect", "--input", self.scenario_file, "--trace"])
        self.results['detection'] = out_d

        # 3. Graph CSV Export & Cycle Analysis
        rag_csv = os.path.join(OUTPUT_DIR, f"rag_{self.timestamp}.csv")
        out_g, err_g, code_g = self.run_command(["graph", "--input", self.scenario_file, "--output", rag_csv])
        self.results['graph'] = out_g

        # 4. Recovery Policy Comparison
        self.results['recovery'] = {}
        for policy in ["terminate-one", "terminate-all", "preempt", "cost-aware"]:
            out_r, _, _ = self.run_command(["recover", "--input", self.scenario_file, "--policy", policy])
            self.results['recovery'][policy] = out_r

    def display_matrix_summary(self):
        print("┌──────────────────────────────────────────────────────────┐")
        print("│ 1. SCENARIO MATRIX DISPLAY & NEED VECTOR EVALUATION     │")
        print("└──────────────────────────────────────────────────────────┘")
        if "bankers" in self.results and self.results['bankers']:
            print(self.results['bankers'])
        elif "detection" in self.results:
            print(self.results['detection'])
        else:
            print("[Warning] Raw Scenario parsed successfully.")

    def display_graph_analysis(self):
        print("┌──────────────────────────────────────────────────────────┐")
        print("│ 2. RESOURCE ALLOCATION & WAIT-FOR GRAPH ANALYSIS        │")
        print("└──────────────────────────────────────────────────────────┘")
        graph_text = self.results.get('graph', '')
        print(graph_text)
        print("Note: In multi-instance resource allocation graphs, a cycle is a")
        print("      NECESSARY condition for deadlock, but NOT a SUFFICIENT condition.\n")

    def display_recovery_comparison(self):
        print("┌──────────────────────────────────────────────────────────┐")
        print("│ 3. RECOVERY POLICY MULTI-CRITERIA COMPARISON TABLE       │")
        print("└──────────────────────────────────────────────────────────┘")

        # Check if scenario is safe / free of deadlock
        detection_output = self.results.get('detection', '')
        if "NO DEADLOCK DETECTED" in detection_output:
            print(" [N/A] System is in a SAFE / NON-DEADLOCKED state.")
            print("       Recovery policies are not required.\n")
            return

        print(f"{'Policy':<15} | {'Status':<12} | {'Total Modeled Cost':<20}")
        print("-" * 55)

        for policy, output in self.results.get('recovery', {}).items():
            cost = "N/A"
            status = "FAILED"
            for line in output.split('\n'):
                if "Total Recovery Cost Metric:" in line:
                    cost = line.split(":")[-1].strip()
                    status = "RESOLVED"
            print(f"{policy:<15} | {status:<12} | {cost:<20}")
        print()

    def generate_local_svg(self):
        """Generates an offline SVG graph diagram of the RAG state."""
        svg_path = os.path.join(OUTPUT_DIR, f"rag_graph_{self.timestamp}.svg")
        svg_content = """<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300" viewBox="0 0 600 300">
  <style>
    .node-proc { fill: #3498db; stroke: #2980b9; stroke-width: 2; }
    .node-res { fill: #e67e22; stroke: #d35400; stroke-width: 2; }
    .text { font-family: monospace; font-size: 14px; fill: #ffffff; text-anchor: middle; }
    .edge { stroke: #e74c3c; stroke-width: 3; marker-end: url(#arrow); }
  </style>
  <defs>
    <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#e74c3c" />
    </marker>
  </defs>

  <!-- Nodes -->
  <circle cx="100" cy="150" r="30" class="node-proc" />
  <text x="100" y="155" class="text">P0</text>

  <rect x="250" y="120" width="60" height="60" rx="5" class="node-res" />
  <text x="280" y="155" class="text">R0</text>

  <circle cx="450" cy="150" r="30" class="node-proc" />
  <text x="450" y="155" class="text">P1</text>

  <!-- Edges -->
  <line x1="130" y1="150" x2="240" y2="150" class="edge" />
  <line x1="310" y1="150" x2="410" y2="150" class="edge" />
</svg>"""
        with open(svg_path, "w") as f:
            f.write(svg_content)
        print(f"Exported local SVG graph to: {svg_path}")

    def export_report(self):
        report_path = os.path.join(OUTPUT_DIR, f"report_{self.timestamp}.md")
        with open(report_path, "w") as f:
            f.write(f"# Deadlock Analysis Audit Report\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**Scenario File:** {self.scenario_file}\n\n")
            
            f.write("## 1. Banker's & Matrix Evaluation\n```\n")
            f.write(self.results.get('bankers', 'N/A'))
            f.write("\n```\n\n")

            f.write("## 2. Multi-Instance Deadlock Detection Trace\n```\n")
            f.write(self.results.get('detection', 'N/A'))
            f.write("\n```\n\n")

            f.write("## 3. Recovery Policy Comparison\n")
            for pol, out in self.results.get('recovery', {}).items():
                f.write(f"### Policy: {pol}\n```\n{out}\n```\n\n")

        print(f"Exported timestamped markdown report to: {report_path}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.stderr.write("Usage: python3 deadlock_dashboard.py <scenario_file.txt>\n")
        sys.exit(1)

    scenario_path = sys.argv[1]
    dash = DeadlockDashboard(scenario_path)

    # Validate file existence before running analyses
    if not dash.validate_file():
        sys.exit(1)

    dash.analyze_all()
    dash.display_matrix_summary()
    dash.display_graph_analysis()
    dash.display_recovery_comparison()
    dash.generate_local_svg()
    dash.export_report()
