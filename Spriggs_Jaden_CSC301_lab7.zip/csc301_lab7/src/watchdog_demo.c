#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

#define NUM_WORKERS 4
#define WATCHDOG_THRESHOLD_SEC 3.0
#define COOPERATIVE_TIMEOUT_SEC 2

typedef enum {
    STATE_RUNNING,
    STATE_CONTENDED,
    STATE_STALLED,
    STATE_COMPLETED
} ThreadStatus;

typedef struct {
    int id;
    pthread_t thread;
    uint64_t progress_counter;      /* Incremented ONLY after completing work */
    struct timespec last_progress;  /* Monotonic timestamp of last progress */
    uint64_t lock_contention_count; /* Tracking lock contention events */
    bool stop_requested;            /* Flag for cooperative shutdown */
    bool force_killed;              /* Flag if hard escalation was required */
    ThreadStatus status;
} WorkerContext;

typedef struct {
    pthread_mutex_t lock;
    int shared_data;
} SharedResource;

static WorkerContext workers[NUM_WORKERS];
static SharedResource resource = { PTHREAD_MUTEX_INITIALIZER, 0 };
static bool global_running = true;

/* Helper: Read CLOCK_MONOTONIC time in seconds */
static double get_monotonic_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + (ts.tv_nsec / 1e9);
}

/* Worker Thread Function */
static void *worker_thread(void *arg) {
    WorkerContext *ctx = (WorkerContext *)arg;

    while (!ctx->stop_requested && global_running) {
        /* Workers 0 & 1 operate normally */
        if (ctx->id <= 1) {
            usleep(200000); /* Simulate work (200ms) */
            
            ctx->status = STATE_CONTENDED;
            pthread_mutex_lock(&resource.lock);
            resource.shared_data++;
            pthread_mutex_unlock(&resource.lock);

            /* Work completed: Update progress and monotonic timestamp */
            ctx->progress_counter++;
            clock_gettime(CLOCK_MONOTONIC, &ctx->last_progress);
            ctx->status = STATE_RUNNING;
        }
        /* Worker 2: Healthy Slow Work (Doesn't stall, but takes longer) */
        else if (ctx->id == 2) {
            usleep(1500000); /* 1.5s per work unit */
            
            pthread_mutex_lock(&resource.lock);
            resource.shared_data++;
            pthread_mutex_unlock(&resource.lock);

            ctx->progress_counter++;
            clock_gettime(CLOCK_MONOTONIC, &ctx->last_progress);
            ctx->status = STATE_RUNNING;
        }
        /* Worker 3: Simulates Permanent Stalled/Deadlocked State */
        else if (ctx->id == 3) {
            if (ctx->progress_counter == 0) {
                /* Simulate initial work */
                ctx->progress_counter++;
                clock_gettime(CLOCK_MONOTONIC, &ctx->last_progress);
            }
            ctx->status = STATE_STALLED;
            /* Indefinite sleep simulating a blocked lock or deadlock */
            while (!ctx->stop_requested) {
                usleep(100000);
            }
            break;
        }
    }

    ctx->status = STATE_COMPLETED;
    return NULL;
}

/* Watchdog Coordinator Task */
static void *watchdog_coordinator(void *arg) {
    (void)arg;
    printf("=== Watchdog Coordinator Started (Threshold: %.1fs) ===\n\n", WATCHDOG_THRESHOLD_SEC);

    for (int check = 0; check < 5; check++) {
        sleep(2);
        double now = get_monotonic_sec();

        printf("--- Watchdog Health Check #%d (T=%.2fs) ---\n", check + 1, now);
        for (int i = 0; i < NUM_WORKERS; i++) {
            WorkerContext *w = &workers[i];
            double last_time = w->last_progress.tv_sec + (w->last_progress.tv_nsec / 1e9);
            double elapsed = now - last_time;

            const char *status_str = "UNKNOWN";
            switch (w->status) {
                case STATE_RUNNING:   status_str = "RUNNING"; break;
                case STATE_CONTENDED: status_str = "CONTENDED"; break;
                case STATE_STALLED:   status_str = "STALLED"; break;
                case STATE_COMPLETED: status_str = "COMPLETED"; break;
            }

            printf("Thread %d | Status: %-10s | Progress: %-5lu | Last Progress: %5.2fs ago",
                   w->id, status_str, w->progress_counter, elapsed);

            /* Warning trigger without auto-termination */
            if (elapsed > WATCHDOG_THRESHOLD_SEC && w->status != STATE_COMPLETED) {
                printf("  <-- [WARNING: SUSPECTED STALL]");
            }
            printf("\n");
        }
        printf("\n");
    }

    /* Bounded Recovery Initiation */
    printf("=== Initiating Bounded Cooperative Recovery ===\n");
    for (int i = 0; i < NUM_WORKERS; i++) {
        WorkerContext *w = &workers[i];
        double now = get_monotonic_sec();
        double last_time = w->last_progress.tv_sec + (w->last_progress.tv_nsec / 1e9);

        if ((now - last_time) > WATCHDOG_THRESHOLD_SEC && w->status != STATE_COMPLETED) {
            printf("Requesting cooperative shutdown for Thread %d...\n", w->id);
            w->stop_requested = true;
        }
    }

    /* Wait for cooperative exit */
    sleep(COOPERATIVE_TIMEOUT_SEC);

    /* Escalation Check */
    for (int i = 0; i < NUM_WORKERS; i++) {
        WorkerContext *w = &workers[i];
        if (w->stop_requested && w->status != STATE_COMPLETED) {
            printf("Thread %d failed to exit cooperatively! Escalating to forced cancellation...\n", w->id);
            pthread_cancel(w->thread);
            w->force_killed = true;
            w->status = STATE_COMPLETED;
        }
    }

    global_running = false;
    return NULL;
}

int main(void) {
    pthread_t watchdog_thread;

    /* Initialize worker contexts */
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);

    for (int i = 0; i < NUM_WORKERS; i++) {
        workers[i].id = i;
        workers[i].progress_counter = 0;
        workers[i].last_progress = now;
        workers[i].lock_contention_count = 0;
        workers[i].stop_requested = false;
        workers[i].force_killed = false;
        workers[i].status = STATE_RUNNING;

        pthread_create(&workers[i].thread, NULL, worker_thread, &workers[i]);
    }

    pthread_create(&watchdog_thread, NULL, watchdog_coordinator, NULL);

    /* Join threads */
    pthread_join(watchdog_thread, NULL);
    for (int i = 0; i < NUM_WORKERS; i++) {
        pthread_join(workers[i].thread, NULL);
    }

    printf("\n=== Execution Summary ===\n");
    for (int i = 0; i < NUM_WORKERS; i++) {
        printf("Thread %d: Progress = %lu | Force Killed = %s\n",
               workers[i].id, workers[i].progress_counter,
               workers[i].force_killed ? "YES" : "NO");
    }

    return 0;
}
