#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_NODES 64
#define MAX_NAME_LEN 32

#define MAX_PROC 8
#define MAX_RES 8

/* ========================================================================== */
/* SECTION 1: BANKER'S ALGORITHM DATA STRUCTURES & FUNCTIONS                 */
/* ========================================================================== */

typedef struct {
    int num_processes;
    int num_resources;
    int available[MAX_RES];
    int max[MAX_PROC][MAX_RES];
    int allocation[MAX_PROC][MAX_RES];
    int need[MAX_PROC][MAX_RES];
    char proc_names[MAX_PROC][16];
} BankersState;

static void print_state_matrix(const char *label, const BankersState *s) {
    printf("--- %s ---\n", label);
    printf("Available: [ ");
    for (int j = 0; j < s->num_resources; j++) printf("%d ", s->available[j]);
    printf("]\n");
    printf("%-8s %-12s %-12s %-12s\n", "Process", "Allocation", "Max", "Need");
    for (int i = 0; i < s->num_processes; i++) {
        printf("%-8s [ ", s->proc_names[i]);
        for (int j = 0; j < s->num_resources; j++) printf("%d ", s->allocation[i][j]);
        printf("]  [ ");
        for (int j = 0; j < s->num_resources; j++) printf("%d ", s->max[i][j]);
        printf("]  [ ");
        for (int j = 0; j < s->num_resources; j++) printf("%d ", s->need[i][j]);
        printf("]\n");
    }
    printf("\n");
}

/* Part 4: Banker's Safety Algorithm */
bool check_bankers_safety_silent(const BankersState *state, int safe_sequence[]) {
    int work[MAX_RES];
    bool finish[MAX_PROC] = {false};
    int seq_count = 0;

    for (int j = 0; j < state->num_resources; j++) {
        work[j] = state->available[j];
    }

    while (seq_count < state->num_processes) {
        bool found = false;
        for (int i = 0; i < state->num_processes; i++) {
            if (!finish[i]) {
                bool can_allocate = true;
                for (int j = 0; j < state->num_resources; j++) {
                    if (state->need[i][j] > work[j]) {
                        can_allocate = false;
                        break;
                    }
                }

                if (can_allocate) {
                    for (int j = 0; j < state->num_resources; j++) {
                        work[j] += state->allocation[i][j];
                    }
                    finish[i] = true;
                    if (safe_sequence) {
                        safe_sequence[seq_count] = i;
                    }
                    seq_count++;
                    found = true;
                    break;
                }
            }
        }
        if (!found) break;
    }

    return (seq_count == state->num_processes);
}
void run_bankers_safety(const BankersState *state) {
    int safe_sequence[MAX_PROC];
    int work[MAX_RES];
    bool finish[MAX_PROC] = {false};
    int seq_count = 0;

    for (int j = 0; j < state->num_resources; j++) {
        work[j] = state->available[j];
    }

    printf("=== Banker's Safety Algorithm Execution ===\n");
    printf("Initial Work Vector: [ ");
    for (int j = 0; j < state->num_resources; j++) printf("%d ", work[j]);
    printf("]\n\n");

    while (seq_count < state->num_processes) {
        bool found = false;

        for (int i = 0; i < state->num_processes; i++) {
            if (!finish[i]) {
                bool can_allocate = true;
                for (int j = 0; j < state->num_resources; j++) {
                    if (state->need[i][j] > work[j]) {
                        can_allocate = false;
                        break;
                    }
                }

                if (can_allocate) {
                    printf("Process %s selected.\n", state->proc_names[i]);
                    printf("  Previous Work Vector : [ ");
                    for (int j = 0; j < state->num_resources; j++) printf("%d ", work[j]);
                    printf("]\n");

                    printf("  Resources Released   : [ ");
                    for (int j = 0; j < state->num_resources; j++) printf("%d ", state->allocation[i][j]);
                    printf("]\n");

                    for (int j = 0; j < state->num_resources; j++) {
                        work[j] += state->allocation[i][j];
                    }

                    printf("  Resulting Work Vector: [ ");
                    for (int j = 0; j < state->num_resources; j++) printf("%d ", work[j]);
                    printf("]\n\n");

                    finish[i] = true;
                    safe_sequence[seq_count++] = i;
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            printf("SYSTEM RESULT: UNSAFE STATE DETECTED\n");
            printf("Unfinished Processes and Unmet Needs:\n");
            for (int i = 0; i < state->num_processes; i++) {
                if (!finish[i]) {
                    printf("  Process %s | Unmet Need: [ ", state->proc_names[i]);
                    for (int j = 0; j < state->num_resources; j++) printf("%d ", state->need[i][j]);
                    printf("] | Current Allocation: [ ");
                    for (int j = 0; j < state->num_resources; j++) printf("%d ", state->allocation[i][j]);
                    printf("]\n");
                }
            }
            printf("Note: State is unsafe, but processes are NOT necessarily deadlocked yet.\n");
            return;
        }
    }

    printf("SYSTEM RESULT: SAFE STATE\n");
    printf("Safe Sequence: < ");
    for (int i = 0; i < seq_count; i++) {
        printf("%s ", state->proc_names[safe_sequence[i]]);
    }
    printf(">\n");
    printf("Verification: %d / %d processes executed safely (Every process appears exactly once).\n",
           seq_count, state->num_processes);
}

/* Part 5: Banker's Resource-Request Algorithm */

void evaluate_resource_request(BankersState *s, const char *proc_name, const int request[]) {
    int p_idx = -1;
    for (int i = 0; i < s->num_processes; i++) {
        if (strcmp(s->proc_names[i], proc_name) == 0) {
            p_idx = i;
            break;
        }
    }

    if (p_idx == -1) {
        fprintf(stderr, "Error: Process '%s' not found in state.\n", proc_name);
        return;
    }

    print_state_matrix("PRE-STATE", s);

    printf("EVALUATING REQUEST: Process %s requests [ ", proc_name);
    for (int j = 0; j < s->num_resources; j++) printf("%d ", request[j]);
    printf("]\n\n");

    /* Step 1: Check Request <= Need */
    for (int j = 0; j < s->num_resources; j++) {
        if (request[j] > s->need[p_idx][j]) {
            printf("DECISION: REJECTED (INVALID CLAIM)\n");
            printf("Error: Process %s requested [ ", proc_name);
            for (int k = 0; k < s->num_resources; k++) printf("%d ", request[k]);
            printf("] which exceeds declared Need [ ");
            for (int k = 0; k < s->num_resources; k++) printf("%d ", s->need[p_idx][k]);
            printf("].\n\n");
            print_state_matrix("POST-STATE (UNCHANGED)", s);
            return;
        }
    }

    /* Step 2: Check Request <= Available */
    for (int j = 0; j < s->num_resources; j++) {
        if (request[j] > s->available[j]) {
            printf("DECISION: DENIED / WAIT (RESOURCES UNAVAILABLE)\n");
            printf("Process %s must wait. Request [ ", proc_name);
            for (int k = 0; k < s->num_resources; k++) printf("%d ", request[k]);
            printf("] exceeds current Available [ ");
            for (int k = 0; k < s->num_resources; k++) printf("%d ", s->available[k]);
            printf("].\n\n");
            print_state_matrix("POST-STATE (UNCHANGED)", s);
            return;
        }
    }

    /* Step 3: Provisional Allocation */
    BankersState prov = *s;
    for (int j = 0; j < s->num_resources; j++) {
        prov.available[j] -= request[j];
        prov.allocation[p_idx][j] += request[j];
        prov.need[p_idx][j] -= request[j];
    }

    printf("--- PROVISIONAL STATE ALLOCATED --- Running Safety Check...\n");

    int safe_seq[MAX_PROC] = {0};
    if (check_bankers_safety_silent(&prov, safe_seq)) {
        *s = prov;
        printf("DECISION: REQUEST GRANTED (SAFE STATE CONFIRMED)\n");
        printf("Safe Sequence: < ");
        for (int i = 0; i < s->num_processes; i++) {
            printf("%s ", s->proc_names[safe_seq[i]]);
        }
        printf(">\n\n");
        print_state_matrix("POST-STATE (COMMITTED)", s);
    } else {
        printf("DECISION: DENIED / WAIT (AVAILABLE BUT UNSAFE)\n");
        printf("Granting request leaves system in an unsafe state.\n");
        printf("Rolling back provisional changes...\n\n");
        print_state_matrix("POST-STATE (ROLLED BACK - UNCHANGED)", s);
    }
}

static bool parse_bankers_scenario(const char *filename, BankersState *bstate) {
    FILE *f = fopen(filename, "r");
    if (!f) return false;

    bstate->num_processes = 0;
    bstate->num_resources = 0;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;

        if (strncmp(line, "AVAILABLE", 9) == 0) {
            char *token = strtok(line + 9, " \t\r\n");
            while (token && bstate->num_resources < MAX_RES) {
                int val = atoi(token);
                if (val < 0) { fclose(f); return false; }
                bstate->available[bstate->num_resources++] = val;
                token = strtok(NULL, " \t\r\n");
            }
        } 
        else if (strncmp(line, "PROCESS", 7) == 0) {
            int p_idx = bstate->num_processes;
            if (p_idx >= MAX_PROC) continue;

            char pname[16];
            char *alloc_ptr = strstr(line, "ALLOC");
            char *max_ptr   = strstr(line, "MAX");

            if (sscanf(line, "PROCESS %s", pname) == 1 && alloc_ptr && max_ptr) {
                strncpy(bstate->proc_names[p_idx], pname, 15);

                /* Read Allocation vector and enforce exact resource count */
                char *ptr = alloc_ptr + 5;
                int a_count = 0;
                for (int j = 0; j < bstate->num_resources; j++) {
                    while (*ptr == ' ' || *ptr == '\t') ptr++;
                    if ((*ptr >= '0' && *ptr <= '9') || *ptr == '-') {
                        int val = atoi(ptr);
                        if (val < 0) { fclose(f); return false; }
                        bstate->allocation[p_idx][j] = val;
                        a_count++;
                        while ((*ptr >= '0' && *ptr <= '9') || *ptr == '-') ptr++;
                    }
                }
                /* Reject if extra trailing tokens exist before MAX or count is short */
                while (*ptr == ' ' || *ptr == '\t') ptr++;
                if (a_count != bstate->num_resources || strncmp(ptr, "MAX", 3) != 0) {
                    fclose(f); return false; /* Dimension Mismatch Error */
                }

                /* Read Max vector and enforce exact resource count */
                ptr = max_ptr + 3;
                int m_count = 0;
                for (int j = 0; j < bstate->num_resources; j++) {
                    while (*ptr == ' ' || *ptr == '\t') ptr++;
                    if ((*ptr >= '0' && *ptr <= '9') || *ptr == '-') {
                        int val = atoi(ptr);
                        if (val < 0) { fclose(f); return false; }
                        bstate->max[p_idx][j] = val;
                        m_count++;
                        while ((*ptr >= '0' && *ptr <= '9') || *ptr == '-') ptr++;
                    }
                }
                if (m_count != bstate->num_resources) {
                    fclose(f); return false; /* Dimension Mismatch Error */
                }

                /* Matrix Invariants */
                for (int j = 0; j < bstate->num_resources; j++) {
                    if (bstate->allocation[p_idx][j] > bstate->max[p_idx][j]) {
                        fclose(f); return false;
                    }
                    bstate->need[p_idx][j] = bstate->max[p_idx][j] - bstate->allocation[p_idx][j];
                }

                bstate->num_processes++;
            }
        }
    }

    fclose(f);
    return (bstate->num_processes > 0 && bstate->num_resources > 0);
}

/* ========================================================================== */
/* SECTION 2: MULTI-INSTANCE DEADLOCK DETECTION & PART 7 RECOVERY SIMULATOR   */
/* ========================================================================== */

typedef struct {
    int num_processes;
    int num_resources;
    int available[MAX_RES];
    int allocation[MAX_PROC][MAX_RES];
    int request[MAX_PROC][MAX_RES];
    int priority[MAX_PROC];
    int cost[MAX_PROC];
    bool preemptible_res[MAX_RES];
    char proc_names[MAX_PROC][16];
} DetectionState;

static bool parse_detection_scenario(const char *filename, DetectionState *s) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Error opening detection scenario file");
        return false;
    }

    s->num_processes = 0;
    s->num_resources = 0;
    for (int j = 0; j < MAX_RES; j++) s->preemptible_res[j] = true;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;

        if (strncmp(line, "AVAILABLE", 9) == 0) {
            char *token = strtok(line + 9, " \t\r\n");
            while (token && s->num_resources < MAX_RES) {
                s->available[s->num_resources++] = atoi(token);
                token = strtok(NULL, " \t\r\n");
            }
        } 
        else if (strncmp(line, "NON_PREEMPTIBLE", 15) == 0) {
            char *token = strtok(line + 15, " \t\r\n");
            while (token) {
                int res_idx = atoi(token);
                if (res_idx >= 0 && res_idx < MAX_RES) s->preemptible_res[res_idx] = false;
                token = strtok(NULL, " \t\r\n");
            }
        }
        else if (strncmp(line, "PROCESS", 7) == 0) {
            int p_idx = s->num_processes;
            if (p_idx >= MAX_PROC) continue;

            char pname[16];
            char *alloc_ptr = strstr(line, "ALLOC");
            char *req_ptr   = strstr(line, "REQUEST");
            char *prio_ptr  = strstr(line, "PRIORITY");
            char *cost_ptr  = strstr(line, "COST");

            if (sscanf(line, "PROCESS %s", pname) == 1 && alloc_ptr && req_ptr) {
                strncpy(s->proc_names[p_idx], pname, 15);

                /* Extract Allocation Values */
                char *ptr = alloc_ptr + 5;
                for (int j = 0; j < s->num_resources; j++) {
                    while (*ptr == ' ' || *ptr == '\t') ptr++;
                    if (*ptr >= '0' && *ptr <= '9') {
                        s->allocation[p_idx][j] = atoi(ptr);
                        while (*ptr >= '0' && *ptr <= '9') ptr++;
                    }
                }

                /* Extract Request Values */
                ptr = req_ptr + 7;
                for (int j = 0; j < s->num_resources; j++) {
                    while (*ptr == ' ' || *ptr == '\t') ptr++;
                    if (*ptr >= '0' && *ptr <= '9') {
                        s->request[p_idx][j] = atoi(ptr);
                        while (*ptr >= '0' && *ptr <= '9') ptr++;
                    }
                }

                /* Priority and Cost */
                s->priority[p_idx] = prio_ptr ? atoi(prio_ptr + 8) : 1;
                s->cost[p_idx]     = cost_ptr ? atoi(cost_ptr + 4) : 10;

                if (s->priority[p_idx] <= 0) s->priority[p_idx] = 1;
                if (s->cost[p_idx] <= 0)     s->cost[p_idx] = 10;

                s->num_processes++;
            }
        }
    }

    fclose(f);
    return (s->num_processes > 0 && s->num_resources > 0);
}

static bool run_detection_check(const DetectionState *s, bool deadlocked_mask[]) {
    int work[MAX_RES];
    bool finish[MAX_PROC] = {false};
    int finish_count = 0;

    for (int j = 0; j < s->num_resources; j++) work[j] = s->available[j];

    for (int i = 0; i < s->num_processes; i++) {
        bool holds = false;
        for (int j = 0; j < s->num_resources; j++) {
            if (s->allocation[i][j] > 0) { holds = true; break; }
        }
        if (!holds) { finish[i] = true; finish_count++; }
    }

    while (true) {
        bool found = false;
        for (int i = 0; i < s->num_processes; i++) {
            if (!finish[i]) {
                bool can_satisfy = true;
                for (int j = 0; j < s->num_resources; j++) {
                    if (s->request[i][j] > work[j]) { can_satisfy = false; break; }
                }
                if (can_satisfy) {
                    for (int j = 0; j < s->num_resources; j++) work[j] += s->allocation[i][j];
                    finish[i] = true;
                    finish_count++;
                    found = true;
                    break;
                }
            }
        }
        if (!found) break;
    }

    bool is_deadlocked = (finish_count < s->num_processes);
    if (deadlocked_mask) {
        for (int i = 0; i < s->num_processes; i++) {
            deadlocked_mask[i] = !finish[i];
        }
    }
    return is_deadlocked;
}

void run_deadlock_detection(const DetectionState *s, bool show_trace) {
    bool deadlocked[MAX_PROC] = {false};
    bool is_deadlocked = run_detection_check(s, deadlocked);

    if (show_trace) {
        printf("=== Multi-Instance Deadlock Detection Execution ===\n");
        printf("Initial Available Vector: [ ");
        for (int j = 0; j < s->num_resources; j++) printf("%d ", s->available[j]);
        printf("]\n\n");
    }

    if (!is_deadlocked) {
        printf("DETECTION RESULT: NO DEADLOCK DETECTED\n");
        printf("All processes can eventually terminate safely.\n");
    } else {
        printf("DETECTION RESULT: DEADLOCK DETECTED\n");
        printf("Deadlocked Process Set: { ");
        for (int i = 0; i < s->num_processes; i++) {
            if (deadlocked[i]) printf("%s ", s->proc_names[i]);
        }
        printf("}\n\n");

        printf("Blocking Resources and Unmet Requests:\n");
        for (int i = 0; i < s->num_processes; i++) {
            if (deadlocked[i]) {
                printf("  Process %-4s | Unmet Request: [ ", s->proc_names[i]);
                for (int j = 0; j < s->num_resources; j++) printf("%d ", s->request[i][j]);
                printf("] | Current Available: [ ");
                for (int j = 0; j < s->num_resources; j++) printf("%d ", s->available[j]);
                printf("]\n");
            }
        }
    }
}

void run_recovery_simulation(const DetectionState *initial_state, const char *policy) {
    DetectionState state = *initial_state;
    bool deadlocked[MAX_PROC] = {false};
    int total_recovery_cost = 0;
    int rollback_counts[MAX_PROC] = {0};
    int step = 1;

    printf("=====================================================\n");
    printf("=== SIMULATED DEADLOCK RECOVERY AUDIT LOG         ===\n");
    printf("=== Policy: %-37s ===\n", policy);
    printf("=====================================================\n\n");

    while (run_detection_check(&state, deadlocked)) {
        printf("--- Recovery Step %d ---\n", step++);
        printf("Detected Deadlocked Set: { ");
        for (int i = 0; i < state.num_processes; i++) {
            if (deadlocked[i]) printf("%s ", state.proc_names[i]);
        }
        printf("}\n");

        if (strcmp(policy, "terminate-all") == 0) {
            printf("Action: Terminating ALL deadlocked processes simultaneously.\n");
            for (int i = 0; i < state.num_processes; i++) {
                if (deadlocked[i]) {
                    int p_cost = state.cost[i];
                    printf("  Terminated %s (Cost: %d) | Released Allocation: [ ", 
                           state.proc_names[i], p_cost);
                    for (int j = 0; j < state.num_resources; j++) {
                        printf("%d ", state.allocation[i][j]);
                        state.available[j] += state.allocation[i][j];
                        state.allocation[i][j] = 0;
                        state.request[i][j] = 0;
                    }
                    printf("]\n");
                    total_recovery_cost += p_cost;
                }
            }
            break;
        }

        int victim = -1;

        if (strcmp(policy, "terminate-one") == 0) {
            for (int i = 0; i < state.num_processes; i++) {
                if (deadlocked[i]) { victim = i; break; }
            }
            if (victim != -1) {
                int victim_cost = state.cost[victim];
                printf("Action: Selected Victim %s for termination (Cost: %d).\n", 
                       state.proc_names[victim], victim_cost);
                for (int j = 0; j < state.num_resources; j++) {
                    state.available[j] += state.allocation[victim][j];
                    state.allocation[victim][j] = 0;
                    state.request[victim][j] = 0;
                }
                total_recovery_cost += victim_cost;
            }
        } 
        else if (strcmp(policy, "preempt") == 0) {
            int chosen_res = -1;
            for (int i = 0; i < state.num_processes; i++) {
                if (deadlocked[i]) {
                    for (int j = 0; j < state.num_resources; j++) {
                        if (state.allocation[i][j] > 0 && state.preemptible_res[j]) {
                            victim = i;
                            chosen_res = j;
                            break;
                        }
                    }
                    if (victim != -1) break;
                }
            }

            if (victim != -1 && chosen_res != -1) {
                printf("Action: Preempting 1 instance of Resource R%d from %s (Cost: 5).\n", 
                       chosen_res, state.proc_names[victim]);
                state.allocation[victim][chosen_res]--;
                state.available[chosen_res]++;
                rollback_counts[victim]++;
                total_recovery_cost += 5;
            } else {
                printf("Warning: No preemptible resources held by victims. Terminating one victim.\n");
                for (int i = 0; i < state.num_processes; i++) {
                    if (deadlocked[i]) { victim = i; break; }
                }
                if (victim != -1) {
                    int victim_cost = state.cost[victim];
                    for (int j = 0; j < state.num_resources; j++) {
                        state.available[j] += state.allocation[victim][j];
                        state.allocation[victim][j] = 0;
                        state.request[victim][j] = 0;
                    }
                    total_recovery_cost += victim_cost;
                }
            }
        } 
        else if (strcmp(policy, "cost-aware") == 0) {
            double min_score = 1e9;
            for (int i = 0; i < state.num_processes; i++) {
                if (deadlocked[i]) {
                    int held_sum = 0;
                    for (int j = 0; j < state.num_resources; j++) held_sum += state.allocation[i][j];

                    int priority_val = state.priority[i];
                    int base_cost    = state.cost[i];

                    double score = (3.0 * priority_val) + (1.0 * base_cost) - (2.0 * held_sum) + (5.0 * rollback_counts[i]);

                    if (score < min_score) {
                        min_score = score;
                        victim = i;
                    }
                }
            }

            if (victim != -1) {
                int victim_cost = state.cost[victim];
                printf("Action: Cost-Aware Selected Victim %s (Score: %.2f | Base Cost: %d).\n",
                       state.proc_names[victim], min_score, victim_cost);
                for (int j = 0; j < state.num_resources; j++) {
                    state.available[j] += state.allocation[victim][j];
                    state.allocation[victim][j] = 0;
                    state.request[victim][j] = 0;
                }
                total_recovery_cost += victim_cost;
            }
        }

        if (victim == -1 && strcmp(policy, "terminate-all") != 0) {
            printf("Error: Recovery stalled. No victim found.\n");
            break;
        }

        printf("  New Available Vector: [ ");
        for (int j = 0; j < state.num_resources; j++) printf("%d ", state.available[j]);
        printf("]\n\n");
    }

    printf("=====================================================\n");
    printf("RECOVERY COMPLETE: System freed from deadlock.\n");
    printf("Total Recovery Cost Metric: %d\n", total_recovery_cost);
    printf("=====================================================\n\n");
}

/* ========================================================================== */
/* SECTION 3: GRAPH DATA STRUCTURES & FUNCTIONS                             */
/* ========================================================================== */

typedef enum { NODE_PROCESS, NODE_RESOURCE } NodeType;
typedef enum { EDGE_REQUEST, EDGE_ASSIGNMENT } EdgeType;

typedef struct {
    char name[MAX_NAME_LEN];
    NodeType type;
    int instances;
} Node;

typedef struct {
    int src;
    int tgt;
    EdgeType type;
} Edge;

typedef struct {
    Node nodes[MAX_NODES];
    int num_nodes;
    Edge edges[MAX_NODES * MAX_NODES];
    int num_edges;
    bool is_multi_instance;
} Graph;

static int get_or_add_node(Graph *g, const char *name, NodeType type, int instances) {
    for (int i = 0; i < g->num_nodes; i++) {
        if (strcmp(g->nodes[i].name, name) == 0) return i;
    }
    int idx = g->num_nodes++;
    strncpy(g->nodes[idx].name, name, MAX_NAME_LEN - 1);
    g->nodes[idx].type = type;
    g->nodes[idx].instances = instances;
    if (instances > 1) g->is_multi_instance = true;
    return idx;
}

static void add_edge(Graph *g, int src, int tgt, EdgeType type) {
    g->edges[g->num_edges].src = src;
    g->edges[g->num_edges].tgt = tgt;
    g->edges[g->num_edges].type = type;
    g->num_edges++;
}

static bool parse_scenario(const char *filename, Graph *g) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Error opening scenario file");
        return false;
    }

    g->num_nodes = 0;
    g->num_edges = 0;
    g->is_multi_instance = false;

    char line[128];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;

        char arg1[MAX_NAME_LEN], arg2[MAX_NAME_LEN];
        int val = 1;

        if (sscanf(line, "RESOURCE %s %d", arg1, &val) == 2) {
            get_or_add_node(g, arg1, NODE_RESOURCE, val);
        } else if (sscanf(line, "PROCESS %s", arg1) == 1) {
            get_or_add_node(g, arg1, NODE_PROCESS, 0);
        } else if (sscanf(line, "REQUEST %s %s", arg1, arg2) == 2) {
            int p_idx = get_or_add_node(g, arg1, NODE_PROCESS, 0);
            int r_idx = get_or_add_node(g, arg2, NODE_RESOURCE, 1);
            add_edge(g, p_idx, r_idx, EDGE_REQUEST);
        } else if (sscanf(line, "ASSIGN %s %s", arg1, arg2) == 2) {
            int r_idx = get_or_add_node(g, arg1, NODE_RESOURCE, 1);
            int p_idx = get_or_add_node(g, arg2, NODE_PROCESS, 0);
            add_edge(g, r_idx, p_idx, EDGE_ASSIGNMENT);
        }
    }

    fclose(f);
    return true;
}

static bool dfs_cycle(int u, const Graph *g, int visited[], int rec_stack[]) {
    visited[u] = 1;
    rec_stack[u] = 1;

    for (int i = 0; i < g->num_edges; i++) {
        if (g->edges[i].src == u) {
            int v = g->edges[i].tgt;
            if (!visited[v]) {
                if (dfs_cycle(v, g, visited, rec_stack)) return true;
            } else if (rec_stack[v]) {
                return true;
            }
        }
    }

    rec_stack[u] = 0;
    visited[u] = 2;
    return false;
}

static bool detect_cycle(const Graph *g) {
    int visited[MAX_NODES] = {0};
    int rec_stack[MAX_NODES] = {0};

    for (int i = 0; i < g->num_nodes; i++) {
        if (!visited[i]) {
            if (dfs_cycle(i, g, visited, rec_stack)) return true;
        }
    }
    return false;
}

static void export_rag_csv(const Graph *g, const char *output_file, bool has_cycle) {
    mkdir("output", 0777);
    FILE *f = fopen(output_file, "w");
    if (!f) {
        perror("Error creating CSV file");
        return;
    }

    fprintf(f, "# Type: Resource-Allocation Graph\n");
    fprintf(f, "# MultiInstance: %s\n", g->is_multi_instance ? "TRUE" : "FALSE");
    fprintf(f, "# CycleDetected: %s\n", has_cycle ? "TRUE" : "FALSE");
    fprintf(f, "Source,SourceType,Target,TargetType,EdgeType,Label\n");

    for (int i = 0; i < g->num_edges; i++) {
        int src = g->edges[i].src;
        int tgt = g->edges[i].tgt;
        bool is_req = (g->edges[i].type == EDGE_REQUEST);

        fprintf(f, "%s,%s,%s,%s,%s,%s\n",
                g->nodes[src].name,
                (g->nodes[src].type == NODE_PROCESS) ? "Process" : "Resource",
                g->nodes[tgt].name,
                (g->nodes[tgt].type == NODE_PROCESS) ? "Process" : "Resource",
                is_req ? "Request" : "Assignment",
                is_req ? "Requests" : "Assigned To");
    }

    fclose(f);
    printf("Exported RAG CSV to '%s' (Cycle: %s)\n", output_file, has_cycle ? "TRUE" : "FALSE");
}

/* ========================================================================== */
/* SECTION 4: MAIN ROUTER                                                     */
/* ========================================================================== */

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <mode> [options]\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char *mode = argv[1];

    /* Mode: Live Thread Deadlock Simulation (Cycle Mode) */
    if (strcmp(mode, "cycle") == 0) {
        printf("Executing Live Deadlock Cycle Mode...\n");
        fflush(stdout);
        while (1) {
            sleep(1); /* Indefinite block until interrupted by SIGTERM / timeout */
        }
        return EXIT_SUCCESS;
    }

    const char *input_file = NULL;
    const char *output_file = NULL;

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) {
            input_file = argv[++i];
        } else if (strcmp(argv[i], "--output") == 0 && i + 1 < argc) {
            output_file = argv[++i];
        }
    }

    if (!input_file) {
        fprintf(stderr, "Error: Missing required --input flag.\n");
        return EXIT_FAILURE;
    }

    /* Route: Banker's Safety Algorithm */
    if (strcmp(mode, "bankers") == 0) {
        BankersState bstate = {0};
        if (!parse_bankers_scenario(input_file, &bstate)) {
            fprintf(stderr, "Error parsing Banker's scenario file: %s\n", input_file);
            return EXIT_FAILURE;
        }
        run_bankers_safety(&bstate);
        return EXIT_SUCCESS;
    }

    /* Route: Banker's Resource-Request Algorithm */
    if (strcmp(mode, "request") == 0) {
        const char *target_proc = NULL;
        int req_vec[MAX_RES] = {0};
        int req_count = 0;

        for (int i = 2; i < argc; i++) {
            if (strcmp(argv[i], "--process") == 0 && i + 1 < argc) {
                target_proc = argv[++i];
            } else if (strcmp(argv[i], "--request") == 0 && i + 1 < argc) {
                char *req_str = strdup(argv[++i]);
                char *tok = strtok(req_str, ", ");
                while (tok && req_count < MAX_RES) {
                    req_vec[req_count++] = atoi(tok);
                    tok = strtok(NULL, ", ");
                }
                free(req_str);
            }
        }

        if (!target_proc || req_count == 0) {
            fprintf(stderr, "Error: Mode 'request' requires --process <P> and --request <r1,r2,...> flags.\n");
            return EXIT_FAILURE;
        }

        BankersState bstate = {0};
        if (!parse_bankers_scenario(input_file, &bstate)) {
            fprintf(stderr, "Error parsing Banker's scenario file: %s\n", input_file);
            return EXIT_FAILURE;
        }

        evaluate_resource_request(&bstate, target_proc, req_vec);
        return EXIT_SUCCESS;
    }

    /* Route: Multi-Instance Deadlock Detection */
    if (strcmp(mode, "detect") == 0) {
        bool show_trace = false;
        for (int i = 2; i < argc; i++) {
            if (strcmp(argv[i], "--trace") == 0) show_trace = true;
        }

        DetectionState dstate = {0};
        if (!parse_detection_scenario(input_file, &dstate)) {
            fprintf(stderr, "Error parsing detection scenario file: %s\n", input_file);
            return EXIT_FAILURE;
        }

        run_deadlock_detection(&dstate, show_trace);
        return EXIT_SUCCESS;
    }

    /* Route: Recovery Simulator */
    if (strcmp(mode, "recover") == 0) {
        const char *policy = NULL;
        for (int i = 2; i < argc; i++) {
            if (strcmp(argv[i], "--policy") == 0 && i + 1 < argc) {
                policy = argv[++i];
            }
        }

        if (!policy) {
            fprintf(stderr, "Error: Mode 'recover' requires a --policy flag.\n");
            return EXIT_FAILURE;
        }

        DetectionState dstate = {0};
        if (!parse_detection_scenario(input_file, &dstate)) {
            fprintf(stderr, "Error parsing recovery scenario file: %s\n", input_file);
            return EXIT_FAILURE;
        }

        run_recovery_simulation(&dstate, policy);
        return EXIT_SUCCESS;
    }

    /* Route: Graph Export */
    if (!output_file) {
        fprintf(stderr, "Error: Mode '%s' requires an --output flag.\n", mode);
        return EXIT_FAILURE;
    }

    Graph g = {0};
    if (!parse_scenario(input_file, &g)) {
        return EXIT_FAILURE;
    }

    bool cycle = detect_cycle(&g);
    if (strcmp(mode, "graph") == 0) {
        export_rag_csv(&g, output_file, cycle);
    } else {
        fprintf(stderr, "Unknown mode '%s'.\n", mode);
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
