#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

/* Global Synchronization Primitives */
static pthread_mutex_t mutex_a = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t mutex_b = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t barrier;

typedef enum {
    MODE_CYCLE,
    MODE_ORDERED,
    MODE_RELEASE,
    MODE_TRYLOCK
} Mode;

static Mode g_mode = MODE_CYCLE;

/* Monotonic Audit Logging Helper */
static void log_event(const char *action, const char *resource, int retries) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    double timestamp_sec = ts.tv_sec + (ts.tv_nsec / 1e9);

    if (retries >= 0) {
        printf("[%.6f] [TID:%lu] %s %s (retry: %d)\n",
               timestamp_sec, (unsigned long)pthread_self(), action, resource, retries);
    } else {
        printf("[%.6f] [TID:%lu] %s %s\n",
               timestamp_sec, (unsigned long)pthread_self(), action, resource);
    }
    fflush(stdout);
}

void *thread_1_routine(void *arg) {
    (void)arg;

    if (g_mode == MODE_CYCLE) {
        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        /* Barrier forces simultaneous hold before requesting second resource */
        pthread_barrier_wait(&barrier);

        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);
        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);
    } 
    else if (g_mode == MODE_ORDERED) {
        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        pthread_barrier_wait(&barrier);

        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);
        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);
    } 
    else if (g_mode == MODE_RELEASE) {
        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        pthread_barrier_wait(&barrier);

        /* Release first lock to break Hold-and-Wait */
        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);

        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);
    } 
    else if (g_mode == MODE_TRYLOCK) {
        int retries = 0;
        int max_retries = 50;

        while (retries < max_retries) {
            log_event("REQUEST", "Mutex A", retries);
            pthread_mutex_lock(&mutex_a);
            log_event("ACQUIRE", "Mutex A", retries);

            log_event("TRYLOCK", "Mutex B", retries);
            if (pthread_mutex_trylock(&mutex_b) == 0) {
                log_event("ACQUIRE", "Mutex B", retries);
                log_event("RELEASE", "Mutex B", retries);
                pthread_mutex_unlock(&mutex_b);
                log_event("RELEASE", "Mutex A", retries);
                pthread_mutex_unlock(&mutex_a);
                break;
            }

            /* Contention occurred: release A, sleep, back off */
            log_event("RELEASE (BACKOFF)", "Mutex A", retries);
            pthread_mutex_unlock(&mutex_a);
            log_event("RETRY", "Mutex A & B", retries);
            retries++;
            usleep((rand() % 1000) + 100);
        }
    }

    log_event("COMPLETE", "Thread 1", -1);
    return NULL;
}

void *thread_2_routine(void *arg) {
    (void)arg;

    if (g_mode == MODE_CYCLE) {
        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        /* Barrier forces simultaneous hold before requesting second resource */
        pthread_barrier_wait(&barrier);

        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);
        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);
    } 
    else if (g_mode == MODE_ORDERED) {
        /* Acquire in identical global order (Mutex A then Mutex B) */
        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        pthread_barrier_wait(&barrier);

        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);
        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);
    } 
    else if (g_mode == MODE_RELEASE) {
        log_event("REQUEST", "Mutex B", -1);
        pthread_mutex_lock(&mutex_b);
        log_event("ACQUIRE", "Mutex B", -1);

        pthread_barrier_wait(&barrier);

        /* Release first lock to break Hold-and-Wait */
        log_event("RELEASE", "Mutex B", -1);
        pthread_mutex_unlock(&mutex_b);

        log_event("REQUEST", "Mutex A", -1);
        pthread_mutex_lock(&mutex_a);
        log_event("ACQUIRE", "Mutex A", -1);

        log_event("RELEASE", "Mutex A", -1);
        pthread_mutex_unlock(&mutex_a);
    } 
    else if (g_mode == MODE_TRYLOCK) {
        int retries = 0;
        int max_retries = 50;

        while (retries < max_retries) {
            log_event("REQUEST", "Mutex B", retries);
            pthread_mutex_lock(&mutex_b);
            log_event("ACQUIRE", "Mutex B", retries);

            log_event("TRYLOCK", "Mutex A", retries);
            if (pthread_mutex_trylock(&mutex_a) == 0) {
                log_event("ACQUIRE", "Mutex A", retries);
                log_event("RELEASE", "Mutex A", retries);
                pthread_mutex_unlock(&mutex_a);
                log_event("RELEASE", "Mutex B", retries);
                pthread_mutex_unlock(&mutex_b);
                break;
            }

            /* Contention occurred: release B, sleep, back off */
            log_event("RELEASE (BACKOFF)", "Mutex B", retries);
            pthread_mutex_unlock(&mutex_b);
            log_event("RETRY", "Mutex B & A", retries);
            retries++;
            usleep((rand() % 1000) + 100);
        }
    }

    log_event("COMPLETE", "Thread 2", -1);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <cycle | ordered | release | trylock>\n", argv[0]);
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "cycle") == 0) {
        g_mode = MODE_CYCLE;
    } else if (strcmp(argv[1], "ordered") == 0) {
        g_mode = MODE_ORDERED;
    } else if (strcmp(argv[1], "release") == 0) {
        g_mode = MODE_RELEASE;
    } else if (strcmp(argv[1], "trylock") == 0) {
        g_mode = MODE_TRYLOCK;
    } else {
        fprintf(stderr, "Invalid mode '%s'. Choose from: cycle, ordered, release, trylock.\n", argv[1]);
        return EXIT_FAILURE;
    }

    srand((unsigned int)time(NULL));
    pthread_barrier_init(&barrier, NULL, 2);

    pthread_t t1, t2;
    pthread_create(&t1, NULL, thread_1_routine, NULL);
    pthread_create(&t2, NULL, thread_2_routine, NULL);

    /* Explicit thread join */
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    /* Clean destruction of synchronization objects */
    pthread_barrier_destroy(&barrier);
    pthread_mutex_destroy(&mutex_a);
    pthread_mutex_destroy(&mutex_b);

    printf("Coffman demo mode '%s' completed successfully.\n", argv[1]);
    return EXIT_SUCCESS;
}
