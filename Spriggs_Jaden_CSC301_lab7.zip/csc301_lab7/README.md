# Once downloaded you can run these commans to to test each src file + test file + dashboard.

./bin/deadlock_tool bankers --input scenarios/safe.txt

./bin/deadlock_tool request --input scenarios/safe.txt --process P1 --request 1,0,2

./bin/deadlock_tool detect --input scenarios/student_deadlocked.txt --trace

./bin/deadlock_tool graph --input scenarios/student_deadlocked.txt --output output/rag_export.csv

./bin/deadlock_tool recover --input scenarios/student_deadlocked.txt --policy terminate-one

./bin/deadlock_tool recover --input scenarios/student_deadlocked.txt --policy terminate-all

./bin/deadlock_tool recover --input scenarios/student_deadlocked.txt --policy preempt

./bin/deadlock_tool recover --input scenarios/student_deadlocked.txt --policy cost-aware

timeout 10 ./bin/deadlock_tool cycle

./bin/watchdog_demo

python3 deadlock_dashboard.py scenarios/safe.txt

python3 deadlock_dashboard.py scenarios/student_deadlocked.txt

python3 tests/test_deadlock.py

python3 tests/test_dashboard.py
