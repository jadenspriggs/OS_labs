#!/usr/bin/env python3
import os
import sys
import subprocess
import tempfile
import csv
import math
import shutil

# --- CONFIGURATION ---
SCHEDULER_BIN = "./bin/scheduler"
OUTPUT_CSV = "output/output.csv"
TIMELINE_CSV = "output/timeline.csv"
TIMEOUT_SECONDS = 5.0

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

class TestRunner:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.has_valgrind = shutil.which("valgrind") is not None

    def log_result(self, category, test_name, passed, expected, actual, details=""):
        if passed:
            self.passed += 1
            print(f"[{Colors.GREEN}PASS{Colors.RESET}] {category} :: {test_name}")
        else:
            self.failed += 1
            print(f"[{Colors.RED}FAIL{Colors.RESET}] {category} :: {test_name}")
            print(f"       Expected: {expected}")
            print(f"       Actual:   {actual}")
            if details:
                print(f"       Details:  {details}")

    def run_command(self, algo, input_file, quantum=2, cs_cost=1):
        """Runs the binary under Valgrind (if available) with timeout enforcement."""
        cmd = []
        if self.has_valgrind:
            cmd = ["valgrind", "--error-exitcode=42", "--leak-check=full", "-q"]
        
        cmd.extend([SCHEDULER_BIN, "--algorithm", algo, "--input", input_file, 
                    "--quantum", str(quantum), "--cs", str(cs_cost)])

        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT_SECONDS)
            if res.returncode == 42:
                return False, "Memory error detected by Valgrind", res.stdout
            return True, res.returncode, res.stdout
        except subprocess.TimeoutExpired:
            return False, "TIMEOUT", ""
        except Exception as e:
            return False, str(e), ""

    def read_output_csv(self, path=OUTPUT_CSV):
        if not os.path.exists(path):
            return None
        data = []
        with open(path, 'r') as f:
            reader = csv.DictReader(f)
            for r in reader:
                cleaned = {k.strip().lower(): v.strip() for k, v in r.items()}
                data.append({
                    'pid': cleaned['pid'],
                    'arrival': int(cleaned['arrival']),
                    'burst': int(cleaned['burst']),
                    'firststart': int(cleaned['firststart']),
                    'completion': int(cleaned['completion']),
                    'turnaround': int(cleaned['turnaround']),
                    'waiting': int(cleaned['waiting']),
                    'response': int(cleaned['response'])
                })
        return data

# --- TEST UTILITIES ---
def create_temp_workload(content):
    f = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.csv')
    f.write(content)
    f.close()
    return f.name

# --- TEST CATEGORIES ---

def test_parser_validation(runner):
    category = "Parser Validation"
    cases = [
        ("Empty File", "", False),
        ("Duplicate PID", "pid,arrival,burst,priority\nP1,0,5,1\nP1,1,3,2\n", False),
        ("Missing Field", "pid,arrival,burst\nP1,0,4\n", False),
        ("Extra Field", "pid,arrival,burst,extra\nP1,0,5,99\n", False),
        ("Noninteger Value", "pid,arrival,burst,priority\nP1,zero,5,1\n", False),
        ("Out-of-range Value", "pid,arrival,burst,priority\nP1,-5,5,4\n", False),
    ]

    for name, content, should_succeed in cases:
        path = create_temp_workload(content)
        ok, code, stdout = runner.run_command("fcfs", path)
        os.remove(path)
        
        passed = (code != 0) if not should_succeed else (code == 0)
        expected = "Nonzero exit status (Error handled)" if not should_succeed else "Zero exit status"
        actual = f"Exit code {code}"
        runner.log_result(category, name, passed, expected, actual)

def test_boundary_conditions(runner):
    category = "Boundary"
    
    # 1. One Process
    path = create_temp_workload("pid,arrival,burst,priority\nP1,0,5,1\n")
    ok, code, _ = runner.run_command("fcfs", path)
    data = runner.read_output_csv()
    passed = ok and code == 0 and len(data) == 1 and data[0]['completion'] == 5
    runner.log_result(category, "One process", passed, "Completion = 5", f"Data: {data}")
    os.remove(path)

    # 2. Simultaneous Arrivals
    path = create_temp_workload("pid,arrival,burst,priority\nP1,0,3,1\nP2,0,3,2\n")
    ok, code, _ = runner.run_command("fcfs", path)
    data = runner.read_output_csv()
    passed = ok and code == 0 and len(data) == 2
    runner.log_result(category, "Simultaneous arrivals", passed, "2 processes finished", f"Code {code}")
    os.remove(path)

    # 3. Long Idle Start
    path = create_temp_workload("pid,arrival,burst,priority\nP1,10,3,1\n")
    ok, code, _ = runner.run_command("fcfs", path)
    data = runner.read_output_csv()
    passed = ok and code == 0 and data[0]['firststart'] == 10 and data[0]['completion'] == 13
    runner.log_result(category, "Long idle start", passed, "Start=10, Completion=13", f"Start={data[0]['firststart'] if data else None}")
    os.remove(path)

    # 4. Maximum Accepted Quantum
    path = create_temp_workload("pid,arrival,burst,priority\nP1,0,10,1\n")
    ok, code, _ = runner.run_command("rr", path, quantum=1000)
    data = runner.read_output_csv()
    passed = ok and code == 0 and data[0]['completion'] == 10
    runner.log_result(category, "Maximum accepted quantum", passed, "Completion = 10", f"Code {code}")
    os.remove(path)

def test_algorithm_oracle(runner):
    category = "Algorithm Oracle"
    workload = "pid,arrival,burst,priority\nP1,0,4,2\nP2,1,2,1\n"
    
    # FCFS Oracle: P1 (0-4), CS (4-5), P2 (5-7) -> P1 comp 4, P2 comp 7
    path = create_temp_workload(workload)
    runner.run_command("fcfs", path, cs_cost=1)
    data = runner.read_output_csv()
    p1 = next(p for p in data if p['pid'] == 'P1')
    p2 = next(p for p in data if p['pid'] == 'P2')
    passed = (p1['completion'] == 4 and p2['completion'] == 7)
    runner.log_result(category, "FCFS baseline oracle", passed, "P1=4, P2=7", f"P1={p1['completion']}, P2={p2['completion']}")

    # RR Oracle (q=2, cs=1): P1(0-2), CS(2-3), P2(3-5), CS(5-6), P1(6-8) -> P2 comp 5, P1 comp 8
    runner.run_command("rr", path, quantum=2, cs_cost=1)
    data = runner.read_output_csv()
    p1 = next(p for p in data if p['pid'] == 'P1')
    p2 = next(p for p in data if p['pid'] == 'P2')
    passed = (p1['completion'] == 8 and p2['completion'] == 5)
    runner.log_result(category, "Round Robin baseline oracle", passed, "P1=8, P2=5", f"P1={p1['completion']}, P2={p2['completion']}")
    os.remove(path)

def test_tie_breaking(runner):
    category = "Tie-breaking"
    # Equal arrivals, bursts, and priorities
    workload = "pid,arrival,burst,priority\nP1,0,3,1\nP2,0,3,1\n"
    path = create_temp_workload(workload)
    runner.run_command("fcfs", path)
    data = runner.read_output_csv()
    # Preserves input FIFO order: P1 starts at 0, P2 starts after P1
    passed = (data[0]['pid'] == 'P1' and data[0]['firststart'] == 0)
    runner.log_result(category, "Equal arrival/burst/priority tie break", passed, "P1 served first", f"First PID={data[0]['pid']}")
    os.remove(path)

def test_preemption(runner):
    category = "Preemption"
    # SRTF: P1 arrives at 0 (burst 5). P2 arrives at 1 (burst 1). P2 preempts P1.
    workload = "pid,arrival,burst,priority\nP1,0,5,4\nP2,1,1,2\n"
    path = create_temp_workload(workload)
    runner.run_command("srtf", path, cs_cost=0)
    data = runner.read_output_csv()
    p2 = next(p for p in data if p['pid'] == 'P2')
    passed = (p2['firststart'] == 1 and p2['completion'] == 2)
    runner.log_result(category, "Arrival causes preemption (SRTF)", passed, "P2 start=1, comp=2", f"P2 start={p2['firststart']}, comp={p2['completion']}")
    os.remove(path)

def test_accounting_invariants(runner):
    category = "Accounting"
    workload = "pid,arrival,burst,priority\nP1,0,4,3\nP2,2,3,1\nP3,4,1,2\n"
    path = create_temp_workload(workload)
    runner.run_command("rr", path, quantum=2, cs_cost=1)
    data = runner.read_output_csv()
    os.remove(path)

    all_invariants_pass = True
    for p in data:
        # Invariant 1: completion >= firststart >= arrival
        if not (p['completion'] >= p['firststart'] >= p['arrival']):
            all_invariants_pass = False
        # Invariant 2: turnaround == waiting + burst
        if p['turnaround'] != (p['waiting'] + p['burst']):
            all_invariants_pass = False
        # Invariant 3: response == firststart - arrival
        if p['response'] != (p['firststart'] - p['arrival']):
            all_invariants_pass = False

    runner.log_result(category, "Part 9 Invariants Validation", all_invariants_pass, "All Part 9 math constraints hold", "Passed" if all_invariants_pass else "Invariant violation")

def test_metamorphic(runner):
    category = "Metamorphic"
    base_workload = "pid,arrival,burst,priority\nP1,0,4,2\nP2,2,3,1\n"
    shift_workload = "pid,arrival,burst,priority\nP1,10,4,1\nP2,12,3,2\n"
    
    path1 = create_temp_workload(base_workload)
    runner.run_command("fcfs", path1, cs_cost=0)
    base_data = {p['pid']: p for p in runner.read_output_csv()}
    os.remove(path1)

    path2 = create_temp_workload(shift_workload)
    runner.run_command("fcfs", path2, cs_cost=0)
    shift_data = {p['pid']: p for p in runner.read_output_csv()}
    os.remove(path2)

    # Shift constant K = 10
    passed = True
    for pid in ['P1', 'P2']:
        if shift_data[pid]['completion'] != base_data[pid]['completion'] + 10:
            passed = False
        if shift_data[pid]['waiting'] != base_data[pid]['waiting']:
            passed = False
        if shift_data[pid]['response'] != base_data[pid]['response']:
            passed = False

    runner.log_result(category, "Arrival shift preserves waiting/response", passed, "Completions +10, Wait/Resp identical", f"Passed={passed}")

def test_robustness(runner):
    category = "Robustness"
    # 100-process valid workload
    lines = ["pid,arrival,burst,priority"]
    for i in range(100):
        lines.append(f"P{i},{i*2},5,{i}")
    content = "\n".join(lines) + "\n"
    
    path = create_temp_workload(content)
    ok, code, _ = runner.run_command("rr", path, quantum=2, cs_cost=1)
    data = runner.read_output_csv()
    os.remove(path)

    passed = ok and code == 0 and len(data) == 100
    runner.log_result(category, "100-process stress test", passed, "100 processes finished under timeout without memory errors", f"Finished {len(data) if data else 0} processes")

# --- MAIN EXECUTABLE & FAULT INJECTION ---

def run_all_tests():
    print(f"\n{Colors.BOLD}=== RUNNING AUTOMATED CPU SCHEDULER TEST SUITE ==={Colors.RESET}\n")
    runner = TestRunner()

    test_parser_validation(runner)
    test_boundary_conditions(runner)
    test_algorithm_oracle(runner)
    test_tie_breaking(runner)
    test_preemption(runner)
    test_accounting_invariants(runner)
    test_metamorphic(runner)
    test_robustness(runner)

    print(f"\n{Colors.BOLD}=== SUMMARY ==={Colors.RESET}")
    print(f"Passed: {runner.passed}")
    print(f"Failed: {runner.failed}")

    return runner.failed

if __name__ == "__main__":
    # Check if user requested fault injection demonstration mode
    if len(sys.argv) > 1 and sys.argv[1] == "--fault-injection-demo":
        print(f"\n{Colors.BOLD}=== DEMONSTRATING FAULT INJECTION DETECTION ==={Colors.RESET}")
        print("Injecting intentional fault into test output: Simulating off-by-one turnaround calculation...")
        
        # Mocking corrupt CSV output
        os.makedirs("outputs", exist_ok=True)
        with open(OUTPUT_CSV, "w") as f:
            f.write("pid,arrival,burst,firststart,completion,turnaround,waiting,response\n")
            f.write("P1,0,4,0,4,99,0,0\n")  # Turnaround corrupted to 99

        runner = TestRunner()
        test_accounting_invariants(runner)
        
        if runner.failed > 0:
            print(f"\n{Colors.GREEN}[SUCCESS] Test suite correctly detected the injected fault!{Colors.RESET}\n")
            sys.exit(0)
        else:
            print(f"\n{Colors.RED}[FAILURE] Test suite failed to detect injected fault!{Colors.RESET}\n")
            sys.exit(1)

    # Standard execution
    failed_count = run_all_tests()
    sys.exit(0 if failed_count == 0 else 1)
