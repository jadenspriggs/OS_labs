#ifndef POLICIES_H
#define POLICIES_H

#include "scheduler.h"
#include "queue.h"

int select_fcfs(const Process processes[],
                const ReadyQueue *queue);

int select_sjf(const Process processes[],
               const ReadyQueue *queue);

int select_srtf(const Process processes[],
                const ReadyQueue *queue);

int select_rr(const ReadyQueue *queue);

int select_priority_np(const Process processes[],
                        const ReadyQueue *queue);

int select_priority_p(const Process processes[],
                       const ReadyQueue *queue);
#endif
