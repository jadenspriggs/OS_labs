#ifndef TIMELINE_H
#define TIMELINE_H

#include "scheduler.h"

/* Initialize an empty timeline */
void timeline_init(Slice slices[], int *count);

/* Add a timeline slice, merging adjacent slices with the same label */
int timeline_add_slice(Slice slices[],
                       int *count,
                       int start,
                       int end,
                       const char *label);

/* Print the timeline in Gantt-chart style */
void timeline_print(const Slice slices[], int count);

#endif
