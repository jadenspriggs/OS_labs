#ifndef QUEUE_H
#define QUEUE_H

#include "scheduler.h"

typedef struct {
    int items[MAX_PROCESSES];
    int count;
} ReadyQueue;

/* Initialize an empty ready queue */
void queue_init(ReadyQueue *queue);

/* Add a process index to the ready queue */
int queue_push(ReadyQueue *queue, int process_index);

/* Remove a specific process index from the queue */
int queue_remove(ReadyQueue *queue, int position);

/* Check whether the queue is empty */
int queue_is_empty(const ReadyQueue *queue);

/* Return the number of processes currently ready */
int queue_size(const ReadyQueue *queue);

#endif
