#ifndef SCHEDULER_H
#define SCHEDULER_H

#define MAX_PROCESSES 100
#define MAX_PID 32

typedef struct {
    char pid[MAX_PID];
    int arrival;
    int burst;
    int priority;
    int input_order;

    int remaining;
    int first_start;
    int completion;
} Process;

typedef struct {
    int start;
    int end;
    char label[MAX_PID];
} Slice;

int load_workload(const char *filename,
                  Process processes[],
                  int *count);

#endif
