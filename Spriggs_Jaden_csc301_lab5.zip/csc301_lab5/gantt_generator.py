import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import sys
import os

def generate_gantt_chart(timeline_file, algorithm, quantum, cs_cost, workload_name, output_image_path):
    # 1. Read the timeline CSV
    if not os.path.exists(timeline_file):
        print(f"Error: {timeline_file} does not exist.")
        sys.exit(1)

    df = pd.read_csv(timeline_file, skipinitialspace=True)
    df.columns = df.columns.str.strip().str.lower()

    # Required columns: algorithm, start, end, label
    required_cols = {'algorithm', 'start', 'end', 'label'}
    if not required_cols.issubset(df.columns):
        print(f"Error: {timeline_file} must contain columns: algorithm, start, end, label")
        sys.exit(1)

    # Filter for the target algorithm if multiple exist in timeline.csv
    df_algo = df[df['algorithm'].str.lower() == algorithm.lower()]
    if df_algo.empty:
        df_algo = df  # Fallback to all rows if algorithm column is uniform

    # 2. Color Mapping Setup
    unique_labels = sorted(df_algo['label'].unique())
    color_map = {}
    
    # Standardize distinct colors for IDLE and CS
    for label in unique_labels:
        if label.upper() == 'IDLE':
            color_map[label] = '#d9d9d9'  # Light Gray
        elif label.upper() == 'CS':
            color_map[label] = '#e41a1c'  # Bright Red
        else:
            # Assign consistent colors to PIDs using a colormap
            color_map[label] = plt.cm.tab10(hash(label) % 10)

    # 3. Create the Gantt Chart
    fig, ax = plt.subplots(figsize=(12, 4))
    
    # Plot horizontal bars
    for idx, row in df_algo.iterrows():
        start = row['start']
        duration = row['end'] - row['start']
        label = row['label']
        
        ax.barh(y=1, width=duration, left=start, height=0.5, 
                color=color_map[label], edgecolor='black', align='center')
        
        # Add interval boundary label text centered inside or above short slices
        if duration >= 1:
            ax.text(start + duration / 2, 1, label, ha='center', va='center', 
                    color='white' if label.upper() == 'CS' else 'black', 
                    fontsize=8, fontweight='bold')

    # Set timeline axis properties
    max_time = df_algo['end'].max()
    ax.set_xlim(0, max_time + 1)
    ax.set_xticks(range(0, max_time + 2, 1 if max_time <= 30 else 2))
    ax.set_yticks([])  # Hide Y-axis ticks

    # 1. Set label padding on the X-axis to keep it compact
    ax.set_xlabel("Time Units", fontsize=10, fontweight='bold', labelpad=6)
    
    # 2. Caption & Title setup
    caption = (f"Workload: {workload_name} | Algorithm: {algorithm.upper()} | "
               f"Quantum: {quantum} | CS Cost: {cs_cost}\n"
               f"Conclusion: Makespan = {max_time} units. CS Overhead shown in RED, IDLE in GRAY.")
    
    plt.title(f"Gantt Chart: {algorithm.upper()}", fontsize=12, fontweight='bold', pad=15)

    # 3. Use rect in tight_layout to leave bottom room for figtext (0.12 leaves 12% space at the bottom)
    plt.tight_layout(rect=[0, 0.10, 1, 1])

    # 4. Position figtext safely at y=0.02 (inside the reserved bottom area)
    plt.figtext(0.5, 0.02, caption, wrap=True, horizontalalignment='center', fontsize=8, style='italic')

    # Build Legend
    legend_patches = [mpatches.Patch(color=color_map[lbl], label=lbl) for lbl in unique_labels]
    ax.legend(handles=legend_patches, bbox_to_anchor=(1.02, 1), loc='upper left', borderaxespad=0.)

    # 5. Save figure with tight bounding box
    plt.savefig(output_image_path, bbox_inches='tight', dpi=300)
    plt.close()

    print(f"[SUCCESS] Gantt chart saved to {output_image_path}")

    # 4. Append run metadata to master summary ledger
    summary_file = "output/timeline_summary.csv"
    os.makedirs(os.path.dirname(summary_file), exist_ok=True)
    
    summary_data = {
        'workload': [workload_name],
        'algorithm': [algorithm],
        'quantum': [quantum],
        'cs_cost': [cs_cost],
        'makespan': [max_time],
        'image_file': [output_image_path]
    }
    
    summary_df = pd.DataFrame(summary_data)
    if not os.path.exists(summary_file):
        summary_df.to_csv(summary_file, index=False)
    else:
        summary_df.to_csv(summary_file, mode='a', header=False, index=False)
        
    print(f"[INFO] Appended run details to {summary_file}")

if __name__ == "__main__":
    if len(sys.argv) < 7:
        print("Usage: python generate_gantt.py <timeline.csv> <algorithm> <quantum> <cs_cost> <workload_name> <output_image.png>")
        sys.exit(1)

    timeline_csv = sys.argv[1]
    algo = sys.argv[2]
    q = sys.argv[3]
    cs = sys.argv[4]
    workload = sys.argv[5]
    out_img = sys.argv[6]

    generate_gantt_chart(timeline_csv, algo, q, cs, workload, out_img)
