#include <stdio.h>
#include <string.h>

#include "timeline.h"

#define MAX_SLICES 1000

void timeline_init(Slice slices[], int *count)
{
    (void)slices;

    if (count != NULL) {
        *count = 0;
    }
}

int timeline_add_slice(Slice slices[],
                       int *count,
                       int start,
                       int end,
                       const char *label)
{
    Slice *last;

    if (slices == NULL || count == NULL || label == NULL) {
        return -1;
    }

    if (start < 0 || end <= start) {
        fprintf(stderr, "Error: invalid timeline interval %d-%d\n",
                start, end);
        return -1;
    }

    if (*count >= MAX_SLICES) {
        fprintf(stderr, "Error: timeline is full\n");
        return -1;
    }

    /*
     * If the new slice begins exactly when the previous slice ends
     * and has the same label, merge them.
     */
    if (*count > 0) {
        last = &slices[*count - 1];

        if (last->end == start &&
            strcmp(last->label, label) == 0) {

            last->end = end;
            return 0;
        }
    }

    slices[*count].start = start;
    slices[*count].end = end;

    snprintf(slices[*count].label,
             sizeof(slices[*count].label),
             "%s",
             label);

    (*count)++;

    return 0;
}

void timeline_print(const Slice slices[], int count)
{
    int i;

    if (slices == NULL || count <= 0) {
        printf("Timeline: empty\n");
        return;
    }

    printf("Timeline:\n");

    for (i = 0; i < count; i++) {
        printf("%d-%d\t%s\n",
               slices[i].start,
               slices[i].end,
               slices[i].label);
    }
}
