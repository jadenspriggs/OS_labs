#include <stddef.h>

#include "policies.h"

/*
 * Return 1 if process a should come before process b
 * according to FCFS tie-breaking rules.
 *
 * FCFS:
 *   1. Earlier arrival time
 *   2. Lower input order
 */
static int comes_before_fcfs(const Process processes[],
                             int a,
                             int b)
{
    if (processes[a].arrival < processes[b].arrival) {
        return 1;
    }

    if (processes[a].arrival > processes[b].arrival) {
        return 0;
    }

    return processes[a].input_order < processes[b].input_order;
}

/*
 * Return 1 if process a should come before process b
 * according to SJF tie-breaking rules.
 *
 * SJF:
 *   1. Shorter burst
 *   2. Earlier arrival
 *   3. Lower input order
 */
static int comes_before_sjf(const Process processes[],
                            int a,
                            int b)
{
    if (processes[a].burst < processes[b].burst) {
        return 1;
    }

    if (processes[a].burst > processes[b].burst) {
        return 0;
    }

    if (processes[a].arrival < processes[b].arrival) {
        return 1;
    }

    if (processes[a].arrival > processes[b].arrival) {
        return 0;
    }

    return processes[a].input_order < processes[b].input_order;
}

int select_fcfs(const Process processes[],
                const ReadyQueue *queue)
{
    int best_position = -1;
    int i;

    if (processes == NULL || queue == NULL || queue->count == 0) {
        return -1;
    }

    for (i = 0; i < queue->count; i++) {
        int current = queue->items[i];

        if (best_position == -1) {
            best_position = i;
            continue;
        }

        if (comes_before_fcfs(processes,
                              current,
                              queue->items[best_position])) {
            best_position = i;
        }
    }

    /*
     * Return the position inside the queue.
     * The scheduler can then call queue_remove().
     */
    return best_position;
}

int select_sjf(const Process processes[],
               const ReadyQueue *queue)
{
    int best_position = -1;
    int i;

    if (processes == NULL || queue == NULL || queue->count == 0) {
        return -1;
    }

    for (i = 0; i < queue->count; i++) {
        int current = queue->items[i];

        if (best_position == -1) {
            best_position = i;
            continue;
        }

        if (comes_before_sjf(processes,
                             current,
                             queue->items[best_position])) {
            best_position = i;
        }
    }

    /*
     * Return the position inside the queue.
     * The scheduler can then call queue_remove().
     */
    return best_position;
}

int select_srtf(const Process processes[],
                const ReadyQueue *queue)
{
    int best_position = -1;
    int i;

    if (processes == NULL || queue == NULL || queue->count == 0) {
        return -1;
    }

    for (i = 0; i < queue->count; i++) {
        int current = queue->items[i];

        if (best_position == -1) {
            best_position = i;
            continue;
        }

        /*
         * SRTF:
         * 1. Shorter remaining time
         * 2. Earlier arrival
         * 3. Lower input order
         */
        if (processes[current].remaining <
            processes[queue->items[best_position]].remaining) {

            best_position = i;

        } else if (processes[current].remaining ==
                   processes[queue->items[best_position]].remaining) {

            if (processes[current].arrival <
                processes[queue->items[best_position]].arrival) {

                best_position = i;

            } else if (processes[current].arrival ==
                       processes[queue->items[best_position]].arrival) {

                if (processes[current].input_order <
                    processes[queue->items[best_position]].input_order) {

                    best_position = i;
                }
            }
        }
    }

    return best_position;
}

int select_rr(const ReadyQueue *queue)
{
    if (queue == NULL || queue->count == 0) {
        return -1;
    }

    return 0;
}

static int comes_before_priority(const Process processes[],
                                 int a,
                                 int b)
{
    if (processes[a].priority < processes[b].priority) {
        return 1;
    }

    if (processes[a].priority > processes[b].priority) {
        return 0;
    }

    if (processes[a].arrival < processes[b].arrival) {
        return 1;
    }

    if (processes[a].arrival > processes[b].arrival) {
        return 0;
    }

    return processes[a].input_order < processes[b].input_order;
}

int select_priority_np(const Process processes[],
                       const ReadyQueue *queue)
{
    int best_position = -1;
    int i;

    if (processes == NULL ||
        queue == NULL ||
        queue->count == 0) {
        return -1;
    }

    for (i = 0; i < queue->count; i++) {
        int current = queue->items[i];

        if (best_position == -1) {
            best_position = i;
            continue;
        }

        if (comes_before_priority(
                processes,
                current,
                queue->items[best_position])) {
            best_position = i;
        }
    }

    return best_position;
}

int select_priority_p(const Process processes[],
                      const ReadyQueue *queue)
{
    return select_priority_np(processes, queue);
}
