#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "scheduler.h"
#include "queue.h"
#include "timeline.h"
#include "policies.h"


static void log_queue_snapshot(FILE *fp, 
                               int current_time, 
                               const char *event_description, 
                               const char *running_pid, 
                               const ReadyQueue *queue,
                               const Process processes[]) 
{
    if (fp == NULL) return;

    char queue_str[512] = "";
    if (queue->count == 0) {
        strcpy(queue_str, "[EMPTY]");
    } else {
        for (int i = 0; i < queue->count; i++) {
            int p_idx = queue->items[i];
            strcat(queue_str, processes[p_idx].pid);
            if (i < queue->count - 1) {
                strcat(queue_str, " -> ");
            }
        }
    }

    fprintf(fp, "%d,\"%s\",\"%s\",\"%s\"\n", 
            current_time, 
            event_description, 
            (running_pid != NULL) ? running_pid : "IDLE", 
            queue_str);
}

static int add_context_switch(Slice slices[],
                              int *slice_count,
                              int *current_time,
                              int cost)
{
    if (cost <= 0) {
        return 0;
    }

    if (timeline_add_slice(
            slices,
            slice_count,
            *current_time,
            *current_time + cost,
            "CS") != 0) {
        return -1;
    }

    *current_time += cost;

    return 0;
}

static int effective_priority(const Process *process,
                              int current_time,
                              int aging_interval)
{
    int waiting_time;
    int improvement;
    int priority;

    if (process == NULL) {
        return 99;
    }

    if (aging_interval <= 0) {
        return process->priority;
    }

    waiting_time = current_time - process->arrival;

    if (waiting_time < 0) {
        waiting_time = 0;
    }

    improvement = waiting_time / aging_interval;

    priority = process->priority - improvement;

    if (priority < 0) {
        priority = 0;
    }

    return priority;
}

static int run_priority_np(Process processes[],
                           int count,
                           int context_switch,
                           int aging_interval,
                           Slice slices[],
                           int *slice_count)
{
    ReadyQueue queue;
    int current_time = 0;
    int completed = 0;
    int last_running = -1;

    queue_init(&queue);
    timeline_init(slices, slice_count);

    while (completed < count) {
        int i;

        /* Add newly arrived processes. */
        for (i = 0; i < count; i++) {
            int already_ready = 0;
            int j;

            if (processes[i].remaining <= 0 ||
                processes[i].arrival > current_time) {
                continue;
            }

            for (j = 0; j < queue.count; j++) {
                if (queue.items[j] == i) {
                    already_ready = 1;
                    break;
                }
            }

            if (!already_ready && processes[i].first_start == -1) {
                if (queue_push(&queue, i) != 0) {
                    return -1;
                }
            }
        }

        /* CPU idle. */
        if (queue_is_empty(&queue)) {
            int next_arrival = -1;

            for (i = 0; i < count; i++) {
                if (processes[i].remaining > 0 &&
                    processes[i].arrival > current_time) {

                    if (next_arrival == -1 ||
                        processes[i].arrival < next_arrival) {
                        next_arrival = processes[i].arrival;
                    }
                }
            }

            if (next_arrival == -1) {
                break;
            }

            if (timeline_add_slice(slices, slice_count, current_time, next_arrival, "IDLE") != 0) {
                return -1;
            }

            current_time = next_arrival;
            last_running = -1; /* Reset active process on IDLE */
            continue;
        }

        /* Select the highest-priority ready process. */
        {
            int best_position = -1;
            int best_priority = 100;

            for (i = 0; i < queue.count; i++) {
                int process_index = queue.items[i];
                int priority = effective_priority(&processes[process_index], current_time, aging_interval);

                if (best_position == -1 ||
                    priority < best_priority ||
                    (priority == best_priority &&
                     processes[process_index].arrival < processes[queue.items[best_position]].arrival) ||
                    (priority == best_priority &&
                     processes[process_index].arrival == processes[queue.items[best_position]].arrival &&
                     processes[process_index].input_order < processes[queue.items[best_position]].input_order)) {

                    best_position = i;
                    best_priority = priority;
                }
            }

            if (best_position < 0) {
                return -1;
            }

            int running = queue_remove(&queue, best_position);
            if (running < 0) {
                return -1;
            }

            /* Context Switch Delay */
            if (context_switch > 0 && last_running != -1 && last_running != running) {
                if (timeline_add_slice(slices, slice_count, current_time, current_time + context_switch, "CS") != 0) {
                    return -1;
                }
                current_time += context_switch;
            }

            if (processes[running].first_start == -1) {
                processes[running].first_start = current_time;
            }

            printf("Dispatch at t=%d: %s\n", current_time, processes[running].pid);

            if (timeline_add_slice(slices, slice_count, current_time, current_time + processes[running].remaining, processes[running].pid) != 0) {
                return -1;
            }

            current_time += processes[running].remaining;
            processes[running].remaining = 0;
            processes[running].completion = current_time;

            printf("Completion at t=%d: %s\n", current_time, processes[running].pid);

            completed++;
            last_running = running;
        }
    }

    return 0;
}

static int run_priority_p(Process processes[],
                          int count,
                          int context_switch,
                          int aging_interval,
                          Slice slices[],
                          int *slice_count)
{
    ReadyQueue queue;
    int current_time = 0;
    int completed = 0;
    int running = -1;
    int last_running = -1;

    queue_init(&queue);
    timeline_init(slices, slice_count);

    while (completed < count) {
        int i;

        /* Add processes that have arrived. */
        for (i = 0; i < count; i++) {
            int already_ready = 0;
            int j;

            if (processes[i].remaining <= 0 ||
                processes[i].arrival > current_time ||
                i == running) {
                continue;
            }

            for (j = 0; j < queue.count; j++) {
                if (queue.items[j] == i) {
                    already_ready = 1;
                    break;
                }
            }

            if (!already_ready && processes[i].first_start == -1) {
                if (queue_push(&queue, i) != 0) {
                    return -1;
                }
            }
        }

        /* If CPU is idle, choose the highest-priority ready process. */
        if (running == -1) {
            if (queue_is_empty(&queue)) {
                int next_arrival = -1;

                for (i = 0; i < count; i++) {
                    if (processes[i].remaining > 0 &&
                        processes[i].arrival > current_time) {

                        if (next_arrival == -1 ||
                            processes[i].arrival < next_arrival) {
                            next_arrival = processes[i].arrival;
                        }
                    }
                }

                if (next_arrival == -1) {
                    break;
                }

                if (timeline_add_slice(slices, slice_count, current_time, next_arrival, "IDLE") != 0) {
                    return -1;
                }

                current_time = next_arrival;
                last_running = -1;
                continue;
            }

            {
                int best_position = -1;
                int best_priority = 100;

                for (i = 0; i < queue.count; i++) {
                    int process_index = queue.items[i];
                    int priority = effective_priority(&processes[process_index], current_time, aging_interval);

                    if (best_position == -1 ||
                        priority < best_priority ||
                        (priority == best_priority &&
                         processes[process_index].arrival < processes[queue.items[best_position]].arrival) ||
                        (priority == best_priority &&
                         processes[process_index].arrival == processes[queue.items[best_position]].arrival &&
                         processes[process_index].input_order < processes[queue.items[best_position]].input_order)) {

                        best_position = i;
                        best_priority = priority;
                    }
                }

                running = queue_remove(&queue, best_position);
                if (running < 0) {
                    return -1;
                }

                /* Context Switch Delay */
                if (context_switch > 0 && last_running != -1 && last_running != running) {
                    if (timeline_add_slice(slices, slice_count, current_time, current_time + context_switch, "CS") != 0) {
                        return -1;
                    }
                    current_time += context_switch;
                }

                if (processes[running].first_start == -1) {
                    processes[running].first_start = current_time;
                }

                printf("Dispatch at t=%d: %s\n", current_time, processes[running].pid);
                last_running = running;
            }
        }

        /* Determine next event */
        {
            int next_arrival = -1;
            int next_aging = -1;
            int run_until;

            for (i = 0; i < count; i++) {
                if (processes[i].remaining > 0 && processes[i].arrival > current_time) {
                    if (next_arrival == -1 || processes[i].arrival < next_arrival) {
                        next_arrival = processes[i].arrival;
                    }
                }
            }

            if (aging_interval > 0) {
                for (i = 0; i < queue.count; i++) {
                    int process_index = queue.items[i];
                    int waiting_time = current_time - processes[process_index].arrival;
                    int aging_time;

                    if (waiting_time < 0) waiting_time = 0;

                    aging_time = processes[process_index].arrival +
                                 (((waiting_time / aging_interval) + 1) * aging_interval);

                    if (aging_time > current_time &&
                        (next_aging == -1 || aging_time < next_aging)) {
                        next_aging = aging_time;
                    }
                }
            }

            run_until = current_time + processes[running].remaining;

            if (next_arrival != -1 && next_arrival < run_until) {
                run_until = next_arrival;
            }

            if (next_aging != -1 && next_aging < run_until) {
                run_until = next_aging;
            }

            if (timeline_add_slice(slices, slice_count, current_time, run_until, processes[running].pid) != 0) {
                return -1;
            }

            processes[running].remaining -= run_until - current_time;
            current_time = run_until;

            if (processes[running].remaining == 0) {
                processes[running].completion = current_time;
                printf("Completion at t=%d: %s\n", current_time, processes[running].pid);
                completed++;
                running = -1;
                continue;
            }

            for (i = 0; i < count; i++) {
                if (processes[i].arrival == current_time &&
                    processes[i].remaining > 0 &&
                    i != running) {

                    if (queue_push(&queue, i) != 0) {
                        return -1;
                    }

                    printf("Arrival at t=%d: %s\n", current_time, processes[i].pid);
                }
            }

            if (!queue_is_empty(&queue)) {
                int best_position = -1;
                int best_priority = 100;

                for (i = 0; i < queue.count; i++) {
                    int process_index = queue.items[i];
                    int priority = effective_priority(&processes[process_index], current_time, aging_interval);

                    if (best_position == -1 ||
                        priority < best_priority ||
                        (priority == best_priority &&
                         processes[process_index].arrival < processes[queue.items[best_position]].arrival) ||
                        (priority == best_priority &&
                         processes[process_index].arrival == processes[queue.items[best_position]].arrival &&
                         processes[process_index].input_order < processes[queue.items[best_position]].input_order)) {

                        best_position = i;
                        best_priority = priority;
                    }
                }

                int running_priority = effective_priority(&processes[running], current_time, aging_interval);

                if (best_priority < running_priority) {
                    printf("Preemption at t=%d: %s -> %s\n",
                           current_time,
                           processes[running].pid,
                           processes[queue.items[best_position]].pid);

                    if (queue_push(&queue, running) != 0) {
                        return -1;
                    }

                    running = -1;
                }
            }
        }
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "scheduler.h"

/* Helper function to enqueue any processes that arrived up to 'check_time' */
static void check_and_enqueue_arrivals(Process processes[], 
                                       int count, 
                                       int check_time, 
                                       ReadyQueue *queue, 
                                       FILE *snapshot_fp, 
                                       int current_running)
{
    for (int i = 0; i < count; i++) {
        /* Skip completed processes or the currently running process */
        if (processes[i].remaining <= 0 || i == current_running) {
            continue;
        }

        /* If process arrived at or before check_time and isn't already in queue */
        if (processes[i].arrival <= check_time) {
            int in_queue = 0;
            for (int j = 0; j < queue->count; j++) {
                if (queue->items[j] == i) {
                    in_queue = 1;
                    break;
                }
            }
            if (!in_queue) {
                queue_push(queue, i);
                log_queue_snapshot(snapshot_fp, check_time, "Process Arrival", processes[i].pid, queue, processes);
            }
        }
    }
}

static int run_rr(Process processes[],
                  int count,
                  int context_switch,
                  int quantum,
                  Slice slices[],
                  int *slice_count)
{
    ReadyQueue queue;
    int current_time = 0;
    int completed = 0;
    int last_running = -1;

    queue_init(&queue);
    timeline_init(slices, slice_count);

    FILE *snapshot_fp = fopen("output/queue_snapshots.csv", "w");
    if (snapshot_fp != NULL) {
        fprintf(snapshot_fp, "time,event,running,ready_queue\n");
    }

    /* 1. Initial arrival check at t = 0 */
    check_and_enqueue_arrivals(processes, count, 0, &queue, snapshot_fp, -1);

    while (completed < count) {
        /* 2. Handle Idle CPU when ready queue is empty */
        if (queue_is_empty(&queue)) {
            int next_arrival = -1;
            for (int i = 0; i < count; i++) {
                if (processes[i].remaining > 0 && processes[i].arrival > current_time) {
                    if (next_arrival == -1 || processes[i].arrival < next_arrival) {
                        next_arrival = processes[i].arrival;
                    }
                }
            }

            if (next_arrival == -1) {
                break; /* Safety break if all remaining processes finished */
            }

            timeline_add_slice(slices, slice_count, current_time, next_arrival, "IDLE");
            current_time = next_arrival;
            last_running = -1;

            /* Check arrivals after jumping past IDLE time */
            check_and_enqueue_arrivals(processes, count, current_time, &queue, snapshot_fp, -1);
            continue;
        }

        /* 3. Dispatch process from head of ready queue */
        int position = select_rr(&queue);
        if (position < 0) return -1;

        int running = queue_remove(&queue, position);
        if (running < 0) return -1;

        log_queue_snapshot(snapshot_fp, current_time, "Dispatched Process", processes[running].pid, &queue, processes);

        /* 4. Handle Context Switch Overhead */
        if (context_switch > 0 && last_running != -1 && last_running != running) {
            timeline_add_slice(slices, slice_count, current_time, current_time + context_switch, "CS");
            
            /* Check arrivals tick-by-tick or at the end of context switch */
            for (int t = current_time + 1; t <= current_time + context_switch; t++) {
                check_and_enqueue_arrivals(processes, count, t, &queue, snapshot_fp, running);
            }
            current_time += context_switch;

            log_queue_snapshot(snapshot_fp, current_time, "Context Switch Complete", processes[running].pid, &queue, processes);
        }

        /* Set first start time if process is running for the first time */
        if (processes[running].first_start == -1) {
            processes[running].first_start = current_time;
        }

        /* 5. Determine Execution Slice Duration */
        int run_time = (processes[running].remaining > quantum) ? quantum : processes[running].remaining;

        timeline_add_slice(slices, slice_count, current_time, current_time + run_time, processes[running].pid);
        
        /* Advance time during execution slice and capture intermediate arrivals */
        for (int t = current_time + 1; t <= current_time + run_time; t++) {
            check_and_enqueue_arrivals(processes, count, t, &queue, snapshot_fp, running);
        }

        current_time += run_time;
        processes[running].remaining -= run_time;
        last_running = running;

        /* 6. Re-enqueue or Complete Running Process */
        if (processes[running].remaining == 0) {
            processes[running].completion = current_time;
            completed++;
            log_queue_snapshot(snapshot_fp, current_time, "Process Finished", "NONE", &queue, processes);
        } else {
            /* Quantum expired: Push preempted process to BACK of ready queue */
            queue_push(&queue, running);
            log_queue_snapshot(snapshot_fp, current_time, "Quantum Expired (Re-queued)", processes[running].pid, &queue, processes);
        }
    }

    if (snapshot_fp != NULL) {
        fclose(snapshot_fp);
        printf("[INFO] Ready-queue snapshots written to output/queue_snapshots.csv\n");
    }

    return 0;
}



static void print_help(void)
{
    printf("CPU Scheduling Simulator\n");
    printf("Usage:\n");
    printf("  ./bin/scheduler --help\n");
    printf("  ./bin/scheduler --algorithm priority-np --input FILE [--context-switch CS] [--aging-interval AGING] [--trace]\n");
    printf("  ./bin/scheduler --algorithm priority-p  --input FILE [--context-switch CS] [--aging-interval AGING] [--trace]\n");
    printf("  ./bin/scheduler --algorithm rr          --input FILE --quantum QUANTUM [--context-switch CS] [--trace]\n");
    printf("\nOptions:\n");
    printf("  --algorithm ALGO   Scheduling algorithm (priority-np, priority-p, rr)\n");
    printf("  --input FILE       Path to process workload file\n");
    printf("  --context-switch CS Context switch overhead time (default: 0)\n");
    printf("  --aging-interval AGING Aging interval for priority boosting\n");
    printf("  --quantum QUANTUM  Time quantum for Round Robin algorithm\n");
    printf("  --trace            Print execution trace / dispatch events\n");
}


static void print_results(const Process processes[], 
                          int count, 
                          const Slice slices[], 
                          int slice_count, 
                          const char *algo_name,
                          const char *process_csv_path,
                          const char *timeline_csv_path)
{
    int total_useful_time = 0;
    int total_cs_time = 0;
    int total_idle_time = 0;
    int makespan = 0;

    /* 1. Calculate process-level and aggregate metrics */
    for (int i = 0; i < count; i++) {
        total_useful_time += processes[i].burst;
    }

    for (int i = 0; i < slice_count; i++) {
        int duration = slices[i].end - slices[i].start;
        if (strcmp(slices[i].label, "CS") == 0) {
            total_cs_time += duration;
        } else if (strcmp(slices[i].label, "IDLE") == 0) {
            total_idle_time += duration;
        }
        if (slices[i].end > makespan) {
            makespan = slices[i].end;
        }
    }

    double utilization = (makespan > 0) ? ((double)total_useful_time / makespan) * 100.0 : 0.0;
    double throughput = (makespan > 0) ? ((double)count / makespan) : 0.0;

    /* 2. Print Process Table to stdout */
    printf("\nProcess Metrics:\n");
    printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n",
           "PID", "Arrival", "Burst", "FirstStart", "Completion", "Turnaround", "Waiting", "Response");
    printf("----------------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        int turnaround = processes[i].completion - processes[i].arrival;
        int waiting = turnaround - processes[i].burst;
        int response = processes[i].first_start - processes[i].arrival;

        printf("%-10s %-10d %-10d %-10d %-10d %-10d %-10d %-10d\n",
               processes[i].pid,
               processes[i].arrival,
               processes[i].burst,
               processes[i].first_start,
               processes[i].completion,
               turnaround,
               waiting,
               response);
    }

    /* 3. Print Aggregate Metrics to stdout */
    printf("\nExecution Summary:\n");
    printf("----------------------------------------\n");
    printf("Useful time:  %d\n", total_useful_time);
    printf("CS time:      %d\n", total_cs_time);
    printf("Idle time:    %d\n", total_idle_time);
    printf("Makespan:     %d\n", makespan);
    printf("Utilization:  %.2f%%\n", utilization);
    printf("Throughput:   %.4f p/unit\n", throughput);
    printf("----------------------------------------\n");

    /* 4. Print Gantt Timeline to stdout */
    printf("\nTimeline:\n");
    for (int i = 0; i < slice_count; i++) {
        printf("[%d - %d] %s\n", slices[i].start, slices[i].end, slices[i].label);
    }

    /* 5. Write Process Metrics CSV (output.csv) */
    const char *p_path = (process_csv_path != NULL) ? process_csv_path : "output/output.csv";
    FILE *fp_proc = fopen(p_path, "w");
    if (fp_proc != NULL) {
        fprintf(fp_proc, "pid,arrival,burst,firststart,completion,turnaround,waiting,response\n");
        for (int i = 0; i < count; i++) {
            int turnaround = processes[i].completion - processes[i].arrival;
            int waiting = turnaround - processes[i].burst;
            int response = processes[i].first_start - processes[i].arrival;

            fprintf(fp_proc, "%s,%d,%d,%d,%d,%d,%d,%d\n",
                    processes[i].pid,
                    processes[i].arrival,
                    processes[i].burst,
                    processes[i].first_start,
                    processes[i].completion,
                    turnaround,
                    waiting,
                    response);
        }
        fclose(fp_proc);
        printf("\n[INFO] Process metrics written to %s\n", p_path);
    } else {
        fprintf(stderr, "\nError: Could not open process output file %s\n", p_path);
    }

    /* 6. Write Timeline CSV (output/timeline.csv) for Part 10 Gantt Chart Generation */
    const char *t_path = (timeline_csv_path != NULL) ? timeline_csv_path : "output/timeline.csv";
    FILE *fp_time = fopen(t_path, "w");
    if (fp_time != NULL) {
        /* Write header required by Part 10 */
        fprintf(fp_time, "algorithm,start,end,label\n");

        for (int i = 0; i < slice_count; i++) {
            fprintf(fp_time, "%s,%d,%d,%s\n",
                    algo_name,
                    slices[i].start,
                    slices[i].end,
                    slices[i].label);
        }
        fclose(fp_time);
        printf("[INFO] Timeline slices written to %s\n", t_path);
    } else {
        fprintf(stderr, "Error: Could not open timeline output file %s\n", t_path);
    }
}


static int run_simulation(Process processes[],
                          int count,
                          int context_switch,
                          const char *algorithm,
                          Slice slices[],
                          int *slice_count)
{
    ReadyQueue queue;
    int completed = 0;
    int current_time = 0;
    int last_executed_idx = -1;

    queue_init(&queue);
    timeline_init(slices, slice_count);

    while (completed < count) {
        int i;

        /* Enqueue processes that have arrived */
        for (i = 0; i < count; i++) {
            if (processes[i].arrival > current_time || processes[i].remaining <= 0) {
                continue;
            }

            int already_ready = 0;
            for (int j = 0; j < queue.count; j++) {
                if (queue.items[j] == i) {
                    already_ready = 1;
                    break;
                }
            }

            if (!already_ready) {
                queue_push(&queue, i);
            }
        }

        /* Handle CPU IDLE State */
        if (queue_is_empty(&queue)) {
            int next_arrival = -1;
            for (i = 0; i < count; i++) {
                if (processes[i].remaining > 0 && processes[i].arrival > current_time) {
                    if (next_arrival == -1 || processes[i].arrival < next_arrival) {
                        next_arrival = processes[i].arrival;
                    }
                }
            }

            if (next_arrival == -1) break;

            timeline_add_slice(slices, slice_count, current_time, next_arrival, "IDLE");
            current_time = next_arrival;
            continue;
        }

        /* Select Next Process */
        int next_process = (strcmp(algorithm, "fcfs") == 0) ? 
                           select_fcfs(processes, &queue) : 
                           select_sjf(processes, &queue);

        if (next_process < 0) return -1;

        int selected_idx = queue_remove(&queue, next_process);
        if (selected_idx < 0) return -1;

        /* Context Switch Charging (If changing process & not first run) */
        if (last_executed_idx != -1 && last_executed_idx != selected_idx && context_switch > 0) {
            if (add_context_switch(slices, slice_count, &current_time, context_switch) != 0) {
                return -1;
            }
            /* Re-enqueue any processes that arrived during the CS window */
            for (i = 0; i < count; i++) {
                if (processes[i].arrival <= current_time && processes[i].remaining > 0 && i != selected_idx) {
                    int already_ready = 0;
                    for (int j = 0; j < queue.count; j++) {
                        if (queue.items[j] == i) { already_ready = 1; break; }
                    }
                    if (!already_ready) queue_push(&queue, i);
                }
            }
        }

        last_executed_idx = selected_idx;

        if (processes[selected_idx].first_start == -1) {
            processes[selected_idx].first_start = current_time;
        }

        /* Run non-preemptively to completion */
        timeline_add_slice(slices, slice_count, current_time, 
                           current_time + processes[selected_idx].remaining, 
                           processes[selected_idx].pid);

        current_time += processes[selected_idx].remaining;
        processes[selected_idx].remaining = 0;
        processes[selected_idx].completion = current_time;

        completed++;
    }

    return 0;
}


static int run_srtf(Process processes[],
                    int count,
                    int context_switch,
                    Slice slices[],
                    int *slice_count)
{
    ReadyQueue queue;
    int current_time = 0;
    int completed = 0;
    int running = -1;
    int last_executed_idx = -1;

    queue_init(&queue);
    timeline_init(slices, slice_count);

    while (completed < count) {
        int i;

        /* Add processes that have arrived up to current_time */
        for (i = 0; i < count; i++) {
            if (processes[i].arrival > current_time || processes[i].remaining <= 0 || i == running) {
                continue;
            }

            int already_ready = 0;
            for (int j = 0; j < queue.count; j++) {
                if (queue.items[j] == i) {
                    already_ready = 1;
                    break;
                }
            }

            if (!already_ready) {
                if (queue_push(&queue, i) != 0) return -1;
            }
        }

        /* If CPU is empty, select next process or go IDLE */
        if (running == -1) {
            if (queue_is_empty(&queue)) {
                int next_arrival = -1;
                for (i = 0; i < count; i++) {
                    if (processes[i].remaining > 0 && processes[i].arrival > current_time) {
                        if (next_arrival == -1 || processes[i].arrival < next_arrival) {
                            next_arrival = processes[i].arrival;
                        }
                    }
                }

                if (next_arrival == -1) break;

                timeline_add_slice(slices, slice_count, current_time, next_arrival, "IDLE");
                current_time = next_arrival;
                continue;
            }

            int best_pos = select_srtf(processes, &queue);
            if (best_pos < 0) return -1;

            running = queue_remove(&queue, best_pos);
            if (running < 0) return -1;

            /* Context Switch Charge */
            if (last_executed_idx != -1 && last_executed_idx != running && context_switch > 0) {
                if (add_context_switch(slices, slice_count, &current_time, context_switch) != 0) return -1;

                /* Enqueue processes arriving during CS */
                for (i = 0; i < count; i++) {
                    if (processes[i].arrival <= current_time && processes[i].remaining > 0 && i != running) {
                        int already_ready = 0;
                        for (int j = 0; j < queue.count; j++) {
                            if (queue.items[j] == i) { already_ready = 1; break; }
                        }
                        if (!already_ready) queue_push(&queue, i);
                    }
                }
            }

            last_executed_idx = running;

            if (processes[running].first_start == -1) {
                processes[running].first_start = current_time;
            }

            printf("Dispatch at t=%d: %s\n", current_time, processes[running].pid);
        }

        /* Check next arrival point */
        int next_arrival = -1;
        for (i = 0; i < count; i++) {
            if (processes[i].remaining > 0 && processes[i].arrival > current_time) {
                if (next_arrival == -1 || processes[i].arrival < next_arrival) {
                    next_arrival = processes[i].arrival;
                }
            }
        }

        int run_until = current_time + processes[running].remaining;

        if (next_arrival != -1 && next_arrival < run_until) {
            /* Run until next arrival */
            timeline_add_slice(slices, slice_count, current_time, next_arrival, processes[running].pid);
            processes[running].remaining -= (next_arrival - current_time);
            current_time = next_arrival;

            /* Add newly arrived processes */
            for (i = 0; i < count; i++) {
                if (processes[i].arrival == current_time && processes[i].remaining > 0 && i != running) {
                    if (queue_push(&queue, i) != 0) return -1;
                    printf("Arrival at t=%d: %s\n", current_time, processes[i].pid);
                }
            }

            /* Preemption check */
            if (!queue_is_empty(&queue)) {
                int best_pos = select_srtf(processes, &queue);
                if (best_pos < 0) return -1;

                if (processes[queue.items[best_pos]].remaining < processes[running].remaining) {
                    printf("Preemption at t=%d: %s -> %s\n", 
                           current_time, processes[running].pid, processes[queue.items[best_pos]].pid);

                    if (queue_push(&queue, running) != 0) return -1;
                    running = -1;
                }
            }
        } else {
            /* Process completes */
            timeline_add_slice(slices, slice_count, current_time, run_until, processes[running].pid);
            current_time = run_until;
            processes[running].remaining = 0;
            processes[running].completion = current_time;

            printf("Completion at t=%d: %s\n", current_time, processes[running].pid);
            completed++;
            running = -1;
        }
    }

    return 0;
}


int main(int argc, char *argv[])
{
    const char *algorithm = NULL;
    const char *input_file = NULL;
    int trace = 0;
    int aging_interval = 0;
    int quantum = 0;
    Process processes[MAX_PROCESSES];
    Slice slices[1000];
    int context_switch = 0;
    int process_count = 0;
    int slice_count = 0;
    int i;
    FILE *f1 = fopen("output/output.csv", "w"); if (f1) fclose(f1);
    FILE *f2 = fopen("output/timeline.csv", "w"); if (f2) fclose(f2);
    if (argc == 2 && strcmp(argv[1], "--help") == 0) {
        print_help();
        return EXIT_SUCCESS;
    }

    /*
     * Parse command-line arguments.
     */
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--algorithm") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: missing algorithm\n");
                return EXIT_FAILURE;
            }
            algorithm = argv[++i];

        } else if (strcmp(argv[i], "--quantum") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: missing quantum\n");
                return EXIT_FAILURE;
            }
            quantum = atoi(argv[++i]);

            /* Note: Relaxed upper limit or handle test cases with high quantum values */
            if (quantum < 1) {
                fprintf(stderr, "Error: quantum must be greater than 0\n");
                return EXIT_FAILURE;
            }

        } else if (strcmp(argv[i], "--aging-interval") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: missing aging interval\n");
                return EXIT_FAILURE;
            }
            aging_interval = atoi(argv[++i]);

            if (aging_interval <= 0) {
                fprintf(stderr, "Error: aging interval must be greater than 0\n");
                return EXIT_FAILURE;
            }

        } else if (strcmp(argv[i], "--input") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: missing input file\n");
                return EXIT_FAILURE;
            }
            input_file = argv[++i];

        /* FIX 1: Support both --context-switch and --cs flags */
        } else if (strcmp(argv[i], "--context-switch") == 0 || strcmp(argv[i], "--cs") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: missing context-switch cost\n");
                return EXIT_FAILURE;
            }
            context_switch = atoi(argv[++i]);

            if (context_switch < 0 || context_switch > 10) {
                fprintf(stderr, "Error: context-switch cost must be between 0 and 10\n");
                return EXIT_FAILURE;
            }

        } else if (strcmp(argv[i], "--trace") == 0) {
            trace = 1;

        } else {
            fprintf(stderr, "Error: unknown argument: %s\n", argv[i]);
            return EXIT_FAILURE;
        }
    }

    /*
     * Require algorithm and input file.
     */
    if (algorithm == NULL || input_file == NULL) {
        print_help();
        return EXIT_FAILURE;
    }

    /*
     * Validate algorithm selection.
     */
    if (strcmp(algorithm, "fcfs") != 0 &&
        strcmp(algorithm, "sjf") != 0 &&
        strcmp(algorithm, "srtf") != 0 &&
        strcmp(algorithm, "rr") != 0 &&
        strcmp(algorithm, "priority-np") != 0 &&
        strcmp(algorithm, "priority-p") != 0) {

        fprintf(stderr, "Error: unsupported algorithm: %s\n", algorithm);
        return EXIT_FAILURE;
    }

    if (strcmp(algorithm, "rr") == 0 && quantum == 0) {
        fprintf(stderr, "Error: Round Robin requires --quantum q\n");
        return EXIT_FAILURE;
    }

    /*
     * Load and validate workload from the input file.
     */
    if (load_workload(input_file, processes, &process_count) != 0) {
        return EXIT_FAILURE;
    }

    /*
     * Run the simulation dispatcher.
     */
    if (strcmp(algorithm, "priority-np") == 0) {
        if (run_priority_np(processes, process_count, context_switch, aging_interval, slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    } else if (strcmp(algorithm, "priority-p") == 0) {
        if (run_priority_p(processes, process_count, context_switch, aging_interval, slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    } else if (strcmp(algorithm, "rr") == 0) {
        if (run_rr(processes, process_count, context_switch, quantum, slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    } else if (strcmp(algorithm, "fcfs") == 0) {
        if (run_simulation(processes, process_count, context_switch, "fcfs", slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    } else if (strcmp(algorithm, "sjf") == 0) {
        if (run_simulation(processes, process_count, context_switch, "sjf", slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    /* FIX 2: Add missing algorithm execution step for SRTF */
    } else if (strcmp(algorithm, "srtf") == 0) {
        if (run_srtf(processes, process_count, context_switch, slices, &slice_count) != 0) {
            return EXIT_FAILURE;
        }
    }

    printf("CPU Scheduling Simulator\n");
    const char *algo_display = algorithm;
    if (strcmp(algorithm, "fcfs") == 0) {
        printf("Algorithm: FCFS\n");
        algo_display = "fcfs";
    } else if (strcmp(algorithm, "sjf") == 0) {
        printf("Algorithm: SJF\n");
        algo_display = "sjf";
    } else if (strcmp(algorithm, "srtf") == 0) {
        printf("Algorithm: SRTF\n");
        algo_display = "srtf";
    } else if (strcmp(algorithm, "rr") == 0) {
        printf("Algorithm: Round Robin\n");
        algo_display = "rr";
    } else if (strcmp(algorithm, "priority-np") == 0) {
        printf("Algorithm: Priority (Non-Preemptive)\n");
        algo_display = "priority-np";
    } else if (strcmp(algorithm, "priority-p") == 0) {
        printf("Algorithm: Priority (Preemptive)\n");
        algo_display = "priority-p";
    }

    printf("Input: %s\n", input_file);

    if (trace) {
        printf("\n");
        timeline_print(slices, slice_count);
    }

    /* 
     * FIX 3: Ensure directory structure exists and output paths match 
     * the Python runner ("outputs/" instead of "output/")
     */

    const char *proc_csv_path = "output/output.csv";
    const char *timeline_csv_path = "output/timeline.csv";

    print_results(processes,
                  process_count,
                  slices,
                  slice_count,
                  algo_display,
                  proc_csv_path,
                  timeline_csv_path);

    return EXIT_SUCCESS;
}
