#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "scheduler.h"

static int is_valid_pid(const char *pid)
{
    size_t i;

    if (pid == NULL || pid[0] == '\0') {
        return 0;
    }

    for (i = 0; pid[i] != '\0'; i++) {
        if (!isalnum((unsigned char)pid[i]) &&
            pid[i] != '_' &&
            pid[i] != '-') {
            return 0;
        }
    }

    return 1;
}

static int is_duplicate_pid(const Process processes[],
                            int count,
                            const char *pid)
{
    int i;

    for (i = 0; i < count; i++) {
        if (strcmp(processes[i].pid, pid) == 0) {
            return 1;
        }
    }

    return 0;
}


/* Case-insensitive string comparison helper */
static int strcasecmp_custom(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        if (tolower((unsigned char)*s1) != tolower((unsigned char)*s2)) {
            return tolower((unsigned char)*s1) - tolower((unsigned char)*s2);
        }
        s1++;
        s2++;
    }
    return tolower((unsigned char)*s1) - tolower((unsigned char)*s2);
}

int load_workload(const char *filename, Process processes[], int *count)
{
    FILE *file;
    char line[256];
    int line_number = 0;
    int process_count = 0;

    if (filename == NULL || processes == NULL || count == NULL) {
        fprintf(stderr, "Error: invalid parser arguments\n");
        return -1;
    }

    file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error: cannot open input file: %s\n", filename);
        return -1;
    }

    /* Read and verify header */
    if (fgets(line, sizeof(line), file) == NULL) {
        fprintf(stderr, "Error: input file is empty\n");
        fclose(file);
        return -1;
    }

    line_number++;
    line[strcspn(line, "\r\n")] = '\0';

    /* Flexible header validation (case-insensitive) */
    if (strcasecmp_custom(line, "pid,arrival,burst,priority") != 0 &&
        strcasecmp_custom(line, "pid,arrival,burst") != 0) {
        fprintf(stderr, "Error: invalid CSV header on line %d: '%s'\n", line_number, line);
        fclose(file);
        return -1;
    }

    while (fgets(line, sizeof(line), file) != NULL) {
        char pid[MAX_PID];
        int arrival = 0;
        int burst = 0;
        int priority = 0;
        char extra;

        line_number++;

        /* Strip trailing newlines */
        line[strcspn(line, "\r\n")] = '\0';

        /* Ignore blank lines */
        if (line[0] == '\0') {
            continue;
        }

        if (process_count >= MAX_PROCESSES) {
            fprintf(stderr, "Error: too many processes; maximum is %d\n", MAX_PROCESSES);
            fclose(file);
            return -1;
        }

        /* 
         * Parse line without leading space in format string.
         * %c checks for trailing extra fields.
         */
	int scanned = sscanf(line, "%31[^,],%d,%d,%d %c", pid, &arrival, &burst, &priority, &extra);

	/* If 4 fields are required, 'scanned' MUST equal 4 */
	if (scanned != 4) {
    		fprintf(stderr, "Error: invalid CSV format on line %d (expected 4 fields, got %d)\n", line_number, scanned);
    		fclose(file);
    		return -1;
	}

        /* Validate PID */
        if (!is_valid_pid(pid)) {
            fprintf(stderr, "Error: invalid PID '%s' on line %d\n", pid, line_number);
            fclose(file);
            return -1;
        }

        /* Validate duplicate PID */
        if (is_duplicate_pid(processes, process_count, pid)) {
            fprintf(stderr, "Error: duplicate PID '%s' on line %d\n", pid, line_number);
            fclose(file);
            return -1;
        }

        /* Validate arrival (allow up to stress-test limits) */
        if (arrival < 0 || arrival > 100000) {
            fprintf(stderr, "Error: arrival time out of range on line %d\n", line_number);
            fclose(file);
            return -1;
        }

        /* Validate burst */
        if (burst < 1 || burst > 10000) {
            fprintf(stderr, "Error: burst out of range on line %d\n", line_number);
            fclose(file);
            return -1;
        }

        /* Validate priority */
        if (priority < 0 || priority > 1000) {
            fprintf(stderr, "Error: priority out of range on line %d\n", line_number);
            fclose(file);
            return -1;
        }

        /* Store process */
        strcpy(processes[process_count].pid, pid);
        processes[process_count].arrival = arrival;
        processes[process_count].burst = burst;
        processes[process_count].priority = priority;
        processes[process_count].input_order = process_count;

        /* Initialize simulation fields */
        processes[process_count].remaining = burst;
        processes[process_count].first_start = -1;
        processes[process_count].completion = -1;

        process_count++;
    }

    fclose(file);

    if (process_count == 0) {
        fprintf(stderr, "Error: no processes found in input file\n");
        return -1;
    }

    *count = process_count;
    return 0;
}
