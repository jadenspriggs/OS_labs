#include <stdio.h>

#include "queue.h"

void queue_init(ReadyQueue *queue)
{
    if (queue == NULL) {
        return;
    }

    queue->count = 0;
}

int queue_push(ReadyQueue *queue, int process_index)
{
    if (queue == NULL) {
        return -1;
    }

    if (queue->count >= MAX_PROCESSES) {
        fprintf(stderr, "Error: ready queue is full\n");
        return -1;
    }

    if (process_index < 0 || process_index >= MAX_PROCESSES) {
        fprintf(stderr, "Error: invalid process index\n");
        return -1;
    }

    queue->items[queue->count] = process_index;
    queue->count++;

    return 0;
}

int queue_remove(ReadyQueue *queue, int position)
{
    int i;
    int removed;

    if (queue == NULL) {
        return -1;
    }

    if (position < 0 || position >= queue->count) {
        fprintf(stderr, "Error: invalid queue position\n");
        return -1;
    }

    removed = queue->items[position];

    /*
     * Shift everything after the removed item
     * one position to the left.
     */
    for (i = position; i < queue->count - 1; i++) {
        queue->items[i] = queue->items[i + 1];
    }

    queue->count--;

    return removed;
}

int queue_is_empty(const ReadyQueue *queue)
{
    if (queue == NULL) {
        return 1;
    }

    return queue->count == 0;
}

int queue_size(const ReadyQueue *queue)
{
    if (queue == NULL) {
        return 0;
    }

    return queue->count;
}
