import csv
import math
import sys

def verify_scheduler_output(workload_file, output_file):
    print("--- Running Independent Verification ---")
    print(f"Workload File: {workload_file}")
    print(f"Output CSV File: {output_file}\n")

    # Read workload CSV
    workload_pids = set()
    total_burst_demand = 0
    with open(workload_file, mode='r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip().lower(): v.strip() for k, v in row.items()}
            workload_pids.add(cleaned['pid'])
            total_burst_demand += int(cleaned['burst'])

    # Read scheduler output CSV
    output_data = []
    with open(output_file, mode='r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip().lower(): v.strip() for k, v in row.items()}
            output_data.append({
                'pid': cleaned['pid'],
                'arrival': int(cleaned['arrival']),
                'burst': int(cleaned['burst']),
                'firststart': int(cleaned['firststart']),
                'completion': int(cleaned['completion']),
                'turnaround': int(cleaned['turnaround']),
                'waiting': int(cleaned['waiting']),
                'response': int(cleaned['response']),
            })

    num_processes = len(output_data)
    invariants_passed = True

    # 1. Invariant: Ordering (completion >= firststart >= arrival)
    for p in output_data:
        if not (p['completion'] >= p['firststart'] >= p['arrival']):
            print(f"[FAIL] Invariant 1 Violated for PID {p['pid']}: completion >= firststart >= arrival check failed.")
            invariants_passed = False
    if invariants_passed:
        print("[PASS] Invariant 1: Ordering (completion >= firststart >= arrival)")

    # 2. Invariant: Turnaround Consistency (turnaround == waiting + burst)
    for p in output_data:
        if p['turnaround'] != p['waiting'] + p['burst']:
            print(f"[FAIL] Invariant 2 Violated for PID {p['pid']}: turnaround != waiting + burst")
            invariants_passed = False
    if invariants_passed:
        print("[PASS] Invariant 2: Formula Consistency (turnaround = waiting + burst)")

    # 3. Invariant: Single Completion & Execution Conservation
    output_burst = sum(p['burst'] for p in output_data)
    if num_processes != len(workload_pids):
        print(f"[FAIL] Invariant 3 Violated: Count mismatch (Expected {len(workload_pids)}, got {num_processes})")
        invariants_passed = False
    elif output_burst != total_burst_demand:
        print(f"[FAIL] Invariant 3 Violated: Executed burst ({output_burst}) != workload demand ({total_burst_demand})")
        invariants_passed = False
    else:
        print("[PASS] Invariant 3: Single Completion & Execution Conservation")

    # Metrics calculation
    makespan = max(p['completion'] for p in output_data) if output_data else 0
    useful_execution = total_burst_demand
    cpu_utilization = (useful_execution / makespan) * 100.0 if makespan > 0 else 0.0
    throughput = num_processes / makespan if makespan > 0 else 0.0

    wait_times = [p['waiting'] for p in output_data]
    avg_waiting = sum(wait_times) / num_processes if num_processes > 0 else 0.0
    max_waiting = max(wait_times) if wait_times else 0
    min_waiting = min(wait_times) if wait_times else 0
    waiting_range = max_waiting - min_waiting

    # Population Standard Deviation
    variance = sum((w - avg_waiting) ** 2 for w in wait_times) / num_processes if num_processes > 0 else 0.0
    waiting_std = math.sqrt(variance)

    print("\n" + "="*40)
    print(" INDEPENDENTLY VERIFIED METRICS SUMMARY")
    print("="*40)
    print(f"Total Processes:      {num_processes}")
    print(f"Makespan:             {makespan} time units")
    print(f"Useful Execution:     {useful_execution} time units")
    print(f"CPU Utilization:      {cpu_utilization:.2f}%")
    print(f"Throughput:           {throughput:.4f} processes/unit")
    print("-" * 40)
    print("FAIRNESS MEASURES (WAITING TIME)")
    print(f"Average Waiting Time: {avg_waiting:.2f}")
    print(f"Max Waiting Time:     {max_waiting}")
    print(f"Min Waiting Time:     {min_waiting}")
    print(f"Waiting-Time Range:   {waiting_range}")
    print(f"Standard Deviation:   {waiting_std:.2f}")
    print("="*40)

    if invariants_passed:
        print("\nSUCCESS: All invariants hold and data is verified!")
    else:
        print("\nWARNING: Verification failed due to invariant violations.")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python verify_metrics.py <input_workload.csv> <scheduler_output.csv>")
        sys.exit(1)

    verify_scheduler_output(sys.argv[1], sys.argv[2])
