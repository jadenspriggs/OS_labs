# Part 3: Simulator Architecture and Event Engine

## 1. Architecture Overview

The simulator will use a shared event engine so that all scheduling algorithms operate on the same workload, process representation, timeline, and metric calculations. The scheduling policy will determine which ready process is selected, while the event engine controls simulation time, arrivals, completions, preemptions, and context-switch events.

## 2. Module Responsibilities

### Parser

The parser reads the workload CSV and creates an array of `Process` structures. It validates the header, PID format, duplicate PIDs, field count, integer values, and required ranges.

The parser accepts 1 through 100 processes. Arrival times must be 0 through 1000, burst times must be 1 through 100, and priorities must be 0 through 99. Invalid input is rejected before simulation begins.

### Ready Queue

The ready queue stores processes that have arrived but have not completed. The queue does not decide the scheduling policy itself. Instead, the active scheduling policy determines which ready process should be selected.

The selection rules will use the required deterministic tie-breaking rules: earlier arrival time followed by lower input order unless the scheduling policy specifies another comparison.

### Simulation Clock

The simulation clock represents simulated CPU time rather than real wall-clock time. The simulator does not use `sleep()` to represent CPU execution.

The clock advances directly to the next relevant event, such as:

* A process arrival
* CPU burst completion
* Round-Robin quantum expiration
* Context-switch completion
* The end of an idle period

This makes the simulator fast and reproducible.

### Scheduler Policy

The scheduler policy chooses the next process from the ready queue. The event engine remains shared among all algorithms.

The simulator will support FCFS, non-preemptive SJF, SRTF, Round Robin, non-preemptive priority, and preemptive priority.

Each policy will implement selection and, where required, preemption behavior without duplicating the main simulation loop.

### Timeline

The timeline records every CPU interval using half-open intervals `[start,end)`.

Each interval contains:

* Start time
* End time
* Label

The label identifies the running process or special activity such as `IDLE` or `CS`.

Using half-open intervals means an interval such as `[0,8)` represents time 0 through just before time 8, while the next interval can begin exactly at time 8.

### Metrics

Metrics are calculated from recorded process times rather than maintained independently by each scheduling algorithm.

For each process:

* Completion time = time the process finishes
* Turnaround time = completion time − arrival time
* Waiting time = turnaround time − original burst time
* Response time = first start time − arrival time

The simulator will also calculate aggregate averages from the per-process values.

### Reporter

The reporter produces a human-readable scheduling summary and machine-readable CSV files.

The output will include the selected algorithm, workload information, per-process metrics, average metrics, and the recorded timeline.

The timeline CSV will contain the start time, end time, and interval label.

## 3. Core Structures

The process structure will store both immutable workload information and simulation state:

```c
typedef struct {
    char pid[32];
    int arrival;
    int burst;
    int priority;
    int input_order;

    int remaining;
    int first_start;
    int completion;
} Process;
```

The timeline structure will represent each interval:

```c
typedef struct {
    int start;
    int end;
    char label[32];
} Slice;
```

Additional simulator state may track the current simulation time, the currently running process, the ready queue, the active algorithm, and the context-switch cost.

## 4. Event Flow

The simulator follows this general event flow:

1. Parse and validate the workload.
2. Initialize every process's remaining burst time.
3. Set the simulation clock to the first relevant arrival.
4. Add every process that has arrived to the ready queue.
5. Ask the active scheduling policy to select the next process.
6. If no process is ready, record an `IDLE` interval and advance the clock to the next arrival.
7. If a process is selected, record start time if this is its first execution.
8. Determine the next event affecting the running process.
9. Advance the simulation clock to that event.
10. Update the process's remaining burst time.
11. Process arrivals and completions at the event boundary according to the required ordering rule.
12. If the process completes, record its completion time.
13. If the policy is preemptive and another process should run, return the current process to the ready queue.
14. Repeat until every process has completed.
15. Calculate metrics from the recorded process times.
16. Generate CSV output.

## 5. Event Priority

When multiple events occur at the same simulation time, process completions will be handled before making the next scheduling decision, as required by the assignment.

All algorithms will use the same event ordering and tie-breaking rules so that their results remain deterministic and comparable.

## 6. Separation of Responsibilities

The parser will only handle workload input and validation. The event engine will control simulation time and process state changes. Scheduling policies will make scheduling decisions. The timeline will record what happened, while the metrics module will calculate performance measurements from the recorded results.

This separation prevents each scheduling algorithm from implementing its own version of the simulation engine and ensures that all algorithms are evaluated using the same workload and metric definitions.
